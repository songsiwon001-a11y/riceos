#!/bin/bash
# RICEOS 디스크 이미지 만들기 (Debian 12 bookworm 최소 설치 + RICEOS UI)
# 실행 환경: Debian/Ubuntu 리눅스 또는 Windows의 WSL2 (root 권한, 인터넷 필요)
# 결과: riceos.img  (GPT: EFI 512MB FAT32 + 나머지 ext4)
# 사용: sudo ./make_image.sh [크기, 기본 6G]
set -euo pipefail

SIZE="${1:-6G}"
IMG="$(pwd)/riceos.img"
MNT="$(mktemp -d /tmp/riceos-root.XXXXXX)"
HERE="$(cd "$(dirname "$0")" && pwd)"
MIRROR="http://deb.debian.org/debian"
# 커널 명령줄: 콘솔 글자(도스 같은 부팅 메시지)를 숨기고 Plymouth 부팅 화면을 쓴다
KCMD="ro quiet splash loglevel=3 udev.log_level=3 rd.udev.log_level=3 systemd.show_status=false vt.global_cursor_default=0"

[ "$(id -u)" = 0 ] || { echo "root 권한이 필요합니다: sudo $0"; exit 1; }
for t in debootstrap parted losetup mkfs.vfat mkfs.ext4 blkid chroot mksquashfs; do
  command -v "$t" >/dev/null || { echo "필요한 도구가 없습니다: $t"
    echo "설치: apt install debootstrap parted dosfstools e2fsprogs util-linux squashfs-tools"; exit 1; }
done
[ -f "$HERE/riceos-ui.py" ] || { echo "riceos-ui.py 가 없습니다"; exit 1; }
[ -f "$HERE/riceos-sysinfo" ] || { echo "riceos-sysinfo 가 없습니다"; exit 1; }
[ -f "$HERE/riceos-auth" ] || { echo "riceos-auth 가 없습니다"; exit 1; }
[ -f "$HERE/riceos-audio-init" ] || { echo "riceos-audio-init 가 없습니다"; exit 1; }
[ -f "$HERE/riceos-install" ] || { echo "riceos-install 가 없습니다"; exit 1; }
[ -f "$HERE/wireplumber/51-riceos-sound.lua" ] || { echo "51-riceos-sound.lua 가 없습니다"; exit 1; }

LOOP1=""; LOOP2=""
cleanup() {
  set +e
  for m in dev/pts dev proc sys boot/efi; do umount "$MNT/$m" 2>/dev/null; done
  umount "$MNT" 2>/dev/null
  [ -n "$LOOP1" ] && losetup -d "$LOOP1" 2>/dev/null
  [ -n "$LOOP2" ] && losetup -d "$LOOP2" 2>/dev/null
  rmdir "$MNT" 2>/dev/null
}
trap cleanup EXIT

echo "[1/7] 빈 이미지와 파티션 만들기 ($SIZE)"
rm -f "$IMG"
truncate -s "$SIZE" "$IMG"
parted -s "$IMG" mklabel gpt \
  mkpart ESP fat32 1MiB 513MiB set 1 esp on \
  mkpart riceos-root ext4 513MiB 100%
TOTAL=$(stat -c %s "$IMG")
# 파티션 노드(loopNp1)가 없는 환경(WSL2 등)을 위해 오프셋으로 각각 연결
LOOP1=$(losetup --find --show -o $((1*1024*1024)) --sizelimit $((512*1024*1024)) "$IMG")
LOOP2=$(losetup --find --show -o $((513*1024*1024)) --sizelimit $((TOTAL - 513*1024*1024 - 1024*1024)) "$IMG")

echo "[2/7] 파일 시스템 만들기"
mkfs.vfat -F32 -n RICEOS-EFI "$LOOP1" >/dev/null
mkfs.ext4 -q -L riceos-root "$LOOP2"
mount "$LOOP2" "$MNT"
mkdir -p "$MNT/boot/efi"
mount "$LOOP1" "$MNT/boot/efi"

echo "[3/7] Debian 기본 시스템 설치 (몇 분 걸립니다)"
debootstrap --arch=amd64 --components=main,contrib,non-free,non-free-firmware \
  --include=linux-image-amd64,grub-efi-amd64,sudo,shim-signed,grub-efi-amd64-signed,systemd-sysv,udev,kmod,locales,tzdata,fonts-nanum,fonts-dejavu-core,exfatprogs,ntfs-3g,dosfstools,e2fsprogs,parted,pciutils,usbutils,iproute2,iputils-ping,less,nano,procps,rfkill,wpasupplicant,iw,firmware-linux,firmware-linux-nonfree,firmware-misc-nonfree,firmware-realtek,firmware-iwlwifi,firmware-atheros,firmware-brcm80211,firmware-amd-graphics,firmware-sof-signed,intel-microcode,amd64-microcode,libgl1-mesa-dri,mesa-vulkan-drivers,vulkan-tools,vainfo,alsa-utils,plymouth,curl,ca-certificates,xserver-xorg-core,xserver-xorg-input-libinput,xinit,xauth,x11-xserver-utils,openbox,fonts-noto-cjk \
  bookworm "$MNT" "$MIRROR"

echo "[4/7] 기본 설정"
ROOT_UUID=$(blkid -s UUID -o value "$LOOP2")
EFI_UUID=$(blkid -s UUID -o value "$LOOP1")
cat > "$MNT/etc/fstab" <<FSTAB
UUID=$ROOT_UUID / ext4 defaults,noatime 0 1
UUID=$EFI_UUID /boot/efi vfat umask=0077 0 2
FSTAB
echo riceos > "$MNT/etc/hostname"
echo "Asia/Seoul" > "$MNT/etc/timezone"
ln -sf /usr/share/zoneinfo/Asia/Seoul "$MNT/etc/localtime"
# 지원 언어: 한국어(기본), English, 日本語, 中文(简体), Français, Español. 모두 UTF-8
cat > "$MNT/etc/locale.gen" <<LOCALES
ko_KR.UTF-8 UTF-8
en_US.UTF-8 UTF-8
ja_JP.UTF-8 UTF-8
zh_CN.UTF-8 UTF-8
fr_FR.UTF-8 UTF-8
es_ES.UTF-8 UTF-8
LOCALES
echo "LANG=ko_KR.UTF-8" > "$MNT/etc/default/locale"
mkdir -p "$MNT/etc/systemd/network"
cat > "$MNT/etc/systemd/network/20-wired.network" <<NET
[Match]
Name=en*
[Network]
DHCP=yes
NET

# 네트워크 관리는 NetworkManager 가 맡는다 (유선·무선·연결 목록은 트레이 아이콘에서)
mkdir -p "$MNT/etc/NetworkManager/conf.d"
cat > "$MNT/etc/NetworkManager/conf.d/10-riceos.conf" <<NMCONF
[main]
dns=systemd-resolved
NMCONF

# apt 저장소: 펌웨어와 non-free 드라이버를 나중에 인터넷에서 받을 수 있도록 설정
cat > "$MNT/etc/apt/sources.list" <<APT
deb http://deb.debian.org/debian bookworm main contrib non-free non-free-firmware
deb http://deb.debian.org/debian bookworm-updates main contrib non-free non-free-firmware
deb http://security.debian.org/debian-security bookworm-security main contrib non-free non-free-firmware
APT

echo "[5/7] RICEOS UI 설치와 자동 실행 설정"
install -m 755 "$HERE/riceos-ui.py" "$MNT/usr/local/bin/riceos-ui"
# 시스템 일(네트워크, 소리, 장치)은 리눅스 도구가 하고, riceos-ui 는 화면만 담당한다
# 시스템 정보 수집도 리눅스 도구 스크립트가 맡고, riceos-ui 는 그 결과를 보여 준다
install -m 755 "$HERE/riceos-sysinfo" "$MNT/usr/local/bin/riceos-sysinfo"
# 로그인 비밀번호 헬퍼 (root 전용). riceos 계정은 sudo 로 이 한 가지만 NOPASSWD 로 부를 수 있다
install -m 755 "$HERE/riceos-auth" "$MNT/usr/local/sbin/riceos-auth"
# 소리: 세션 시작 때 음소거 해제와 볼륨 70%, 모니터 스피커(HDMI·DP)는 우선순위를 낮춘다
install -m 755 "$HERE/riceos-audio-init" "$MNT/usr/local/bin/riceos-audio-init"
# 설치 프로그램 (USB 임시 모드에서 하드디스크로 설치). 설명은 linux/README.md
install -m 755 "$HERE/riceos-install" "$MNT/usr/local/sbin/riceos-install"
mkdir -p "$MNT/etc/wireplumber/main.lua.d"
install -m 644 "$HERE/wireplumber/51-riceos-sound.lua" "$MNT/etc/wireplumber/main.lua.d/51-riceos-sound.lua"
mkdir -p "$MNT/etc/sudoers.d"
cat > "$MNT/etc/sudoers.d/riceos-auth" <<'SUDO'
riceos ALL=(root) NOPASSWD: /usr/local/sbin/riceos-auth
riceos ALL=(root) PASSWD: /usr/local/sbin/riceos-install
SUDO
chmod 440 "$MNT/etc/sudoers.d/riceos-auth"
# 부팅 시 소리 켜기: 많은 마더보드가 음소거 상태로 시작한다
cat > "$MNT/etc/systemd/system/riceos-sound.service" <<'UNIT'
[Unit]
Description=RICEOS 기본 소리 설정
After=alsa-restore.service sound.target
Wants=alsa-restore.service

[Service]
Type=oneshot
RemainAfterExit=yes
ExecStart=/bin/sh -c 'for c in Master PCM Headphone Speaker; do amixer -q sset "$c" unmute 70% >/dev/null 2>&1; done; exit 0'

[Install]
WantedBy=multi-user.target
UNIT

cat > "$MNT/etc/systemd/system/riceos-ui.service" <<UNIT
[Unit]
Description=RICEOS 데스크톱 (X: Openbox, Mesa, libinput)
After=systemd-user-sessions.service systemd-udev-settle.service riceos-sound.service plymouth-start.service
# 부팅 화면(Plymouth)은 데스크톱 세션이 시작된 뒤에 내린다. 그래야 로딩바가 중간에 끊기지 않는다
Before=plymouth-quit.service plymouth-quit-wait.service
Wants=riceos-sound.service
Conflicts=getty@tty1.service
After=getty@tty1.service

[Service]
Environment=TZ=Asia/Seoul
ExecStart=/usr/bin/xinit /usr/local/bin/riceos-chrome-session -- :1 vt8 -nolisten tcp
Restart=always
RestartSec=1
StandardInput=null
StandardOutput=journal
StandardError=journal

[Install]
WantedBy=multi-user.target
UNIT

# 데스크톱 세션: 일반 사용자(riceos)로 창 관리자와 바탕화면을 X 화면에서 띄운다 (앱은 자동으로 켜지지 않는다)
cat > "$MNT/usr/local/bin/riceos-chrome" <<'SH'
#!/bin/sh
# RICEOS 데스크톱(X)을 연다. 나가면 RICEOS 화면으로 돌아온다. 앱은 자동으로 켜지지 않는다.
if systemctl is-active --quiet riceos-x.service; then
  echo "데스크톱이 이미 실행 중입니다."
  exit 0
fi
systemd-run --unit=riceos-x --collect --description="RICEOS 데스크톱" \
  /bin/sh -c 'systemctl stop riceos-ui.service; xinit /usr/local/bin/riceos-chrome-session -- :1 vt8 -nolisten tcp >/var/log/riceos-x.log 2>&1; systemctl start riceos-ui.service'
SH
chmod 755 "$MNT/usr/local/bin/riceos-chrome"

cat > "$MNT/usr/local/bin/riceos-chrome-session" <<'SH'
#!/bin/sh
# X 세션 안에서 xinit이 실행한다. 창 관리자와 바탕화면 아이콘 관리를 riceos 사용자로 띄운다.
# 창 관리자(Openbox)를 끝내면 이 스크립트가 끝나고, xinit이 X 서버를 내린다.
xhost +SI:localuser:riceos >/dev/null 2>&1
# 바탕화면 색 (pcmanfm 이 그리기 전에도 같은 색이 보이게)
xsetroot -solid "#F5B52E" 2>/dev/null || true

# 모든 연결된 모니터를 켠다. 각 모니터는 자기 해상도에서 가장 높은 주사율로 돌고,
# 첫 번째 모니터를 기준(주 모니터)으로 나머지를 오른쪽에 가로로 배치한다.
riceos_layout() {
  prev=""
  # 해상도 고르기: 모니터가 알려 준 권장(+) 해상도 → 현재(*) 해상도 → 첫 줄 순서.
  # xrandr 의 첫 줄은 가장 큰 해상도라서 작은 모니터가 신호를 못 받아 검게 될 수 있다.
  xrandr -q | awk '
    function emit(   c) {
      if (out == "") return
      c = pref != "" ? pref : (cur != "" ? cur : first)
      if (c != "") print out, c
    }
    /^[^ ]/ {
      emit(); out = ""; pref = ""; cur = ""; first = ""
      if ($0 ~ / connected/ && $0 !~ / disconnected/) out = $1
      next
    }
    out != "" && /^ +[0-9]+x[0-9]+/ {
      # 주사율 칸 중 * (현재)와 + (권장) 이 붙은 칸의 값을 쓴다
      p = ""; c = ""; r = ""
      for (i = 2; i <= NF; i++) {
        v = $i; if (r == "") { r = v; gsub(/[*+]/, "", r) }
        if (v ~ /\+/ && p == "") { p = v; gsub(/[*+]/, "", p) }
        if (v ~ /\*/ && c == "") { c = v; gsub(/[*+]/, "", c) }
      }
      if (first == "") first = $1 " " r
      if (p != "" && pref == "") pref = $1 " " p
      if (c != "" && cur == "") cur = $1 " " c
    }
    END { emit() }
  ' | while read out res rate; do
    if [ -z "$prev" ]; then pos="--pos 0x0 --primary"; else pos="--right-of $prev"; fi
    xrandr --output "$out" --mode "$res" --rate "$rate" $pos
    prev="$out"
  done
}
# 디스플레이 설정(arandr)에서 저장한 배치가 있으면 그것을 쓰고, 없으면 위의 자동 배치를 쓴다
SAVED=$(ls -t /home/riceos/.screenlayout/*.sh 2>/dev/null | head -1)
if [ -n "$SAVED" ] && sh "$SAVED"; then :; else riceos_layout; fi
/usr/local/bin/riceos-sync-desktop
# 로그인 세션이 없으므로 앱들이 쓰는 런타임 폴더를 직접 만든다 (소리, 크롬 등에 필요)
RT=/run/user/$(id -u riceos)
mkdir -p "$RT"; chown riceos:riceos "$RT"; chmod 700 "$RT"
exec runuser -u riceos -- env DISPLAY="$DISPLAY" HOME=/home/riceos XDG_RUNTIME_DIR="$RT" dbus-run-session -- openbox --startup 'sh -c "pipewire & sleep 1; wireplumber & pipewire-pulse & nm-applet & sleep 2; riceos-audio-init & riceos-ui --login &"'
SH
chmod 755 "$MNT/usr/local/bin/riceos-chrome-session"

# 부팅 화면 (Plymouth): 제조사 로고(ACPI BGRT) 위에 바 형태 로딩바. 테마 파일은 linux/plymouth/ 에 있다
mkdir -p "$MNT/usr/share/plymouth/themes/riceos" "$MNT/etc/plymouth"
install -m 644 "$HERE"/plymouth/riceos/* "$MNT/usr/share/plymouth/themes/riceos/"
install -m 644 "$HERE/plymouth/plymouthd.conf" "$MNT/etc/plymouth/plymouthd.conf"

# 배경화면 그림 폴더: linux/wallpapers/ 에 넣은 PNG/BMP 파일이 'riceos wallpaper next' 순환에 들어간다
mkdir -p "$MNT/usr/share/riceos/wallpapers"
if [ -d "$HERE/wallpapers" ]; then
  cp "$HERE"/wallpapers/*.png "$HERE"/wallpapers/*.bmp "$MNT/usr/share/riceos/wallpapers/" 2>/dev/null || true
fi

echo "[6/7] 부트로더(GRUB)와 서비스 활성화"
mount --bind /dev "$MNT/dev"
mount --bind /dev/pts "$MNT/dev/pts"
mount -t proc proc "$MNT/proc"
mount -t sysfs sys "$MNT/sys"

echo "bluez 설치 (서비스 자동 시작은 막음)"
# 빌드 중 DNS: 호스트의 127.0.0.53 같은 로컬 스텁은 chroot 안에서 못 쓴다. 공용 DNS를 직접 적는다
printf 'nameserver 8.8.8.8\nnameserver 1.1.1.1\n' > "$MNT/etc/resolv.conf"
printf '#!/bin/sh\nexit 101\n' > "$MNT/usr/sbin/policy-rc.d"
chmod +x "$MNT/usr/sbin/policy-rc.d"
# 로그인 비밀번호 바꾸기 (아이디는 Admin). 처음 비밀번호는 부팅 때 화면에서 정한다
cat > "$MNT/usr/local/bin/riceos-setpw" <<'SH'
#!/bin/sh
# RICEOS 로그인 비밀번호 바꾸기 (아이디 riceos). 사용법: sudo riceos-setpw
[ "$(id -u)" = 0 ] || { echo "root 권한으로 실행하세요: sudo riceos-setpw"; exit 1; }
printf '새 비밀번호: '; stty -echo; read -r PW1; stty echo; echo
printf '비밀번호 확인: '; stty -echo; read -r PW2; stty echo; echo
[ -n "$PW1" ] || { echo "비어 있으면 안 됩니다"; exit 1; }
[ "$PW1" = "$PW2" ] || { echo "두 비밀번호가 서로 다릅니다"; exit 1; }
printf '%s\n' "$PW1" | /usr/local/sbin/riceos-auth set && echo "비밀번호를 바꿨습니다. 로그인과 콘솔(riceos)에 같은 비밀번호가 쓰입니다."
SH
chmod +x "$MNT/usr/local/bin/riceos-setpw"

chroot "$MNT" apt-get update -qq
chroot "$MNT" env DEBIAN_FRONTEND=noninteractive apt-get install -y -qq live-boot squashfs-tools plymouth plymouth-themes bluez systemd-resolved chromium mpv zathura gthumb gdebi pavucontrol lxappearance cups system-config-printer printer-driver-gutenprint python3-gi gir1.2-gtk-4.0 pipewire pipewire-pulse wireplumber pcmanfm arandr mousepad feh xarchiver lxterminal network-manager network-manager-gnome tint2 sudo man-db manpages bash-completion htop unzip zip p7zip-full git wget file tree udisks2 gvfs gvfs-backends xdg-utils xdg-user-dirs fonts-noto-color-emoji
rm -f "$MNT/usr/sbin/policy-rc.d"

# grub-probe 가 루트 장치를 못 찾는 문제 방지: mtab 연결 + 루트 UUID 직접 지정
ln -sf /proc/self/mounts "$MNT/etc/mtab"
echo "GRUB_DEVICE_UUID=$ROOT_UUID" >> "$MNT/etc/default/grub"

# 우클릭 메뉴에 설정 도구 항목 추가 (Openbox 루트 메뉴)
MENU="$MNT/etc/xdg/openbox/menu.xml"
if grep -q 'id="root-menu"' "$MENU" 2>/dev/null; then
  # 항목들을 한 덩어리로 모아 한 번에 넣는다 (한 줄씩 넣으면 순서가 거꾸로 된다)
  SNIP="$(mktemp)"
  for item in \
    '디스플레이 설정|riceos-ui --display' \
    '소리 설정|pavucontrol' \
    '개인 설정 (테마)|lxappearance' \
    '프린터 설정|system-config-printer' \
    '파일 관리자|pcmanfm' \
    '문서 보기|zathura' \
    '이미지 보기|gthumb' \
    '동영상 재생|mpv' \
    'RICEOS 설정|riceos-ui' \
    '빠른 설정|riceos-ui --quick' \
    'RICEOS 설치|riceos-ui --install' \
    '앱 목록|riceos-ui --menu'; do
    label="${item%%|*}"; cmd="${item##*|}"
    printf '    <item label="%s"><action name="Execute"><command>%s</command></action></item>\n' "$label" "$cmd" >> "$SNIP"
  done
  sed -i "/<menu id=\"root-menu\"/r $SNIP" "$MENU"
  rm -f "$SNIP"
else
  echo "참고: 우클릭 메뉴(root-menu)를 찾지 못해 설정 항목을 건너뜁니다"
fi

# 설치한 앱의 바로가기를 바탕화면에 자동으로 만든다 (apt 설치/삭제 뒤, 그리고 세션 시작 때)
cat > "$MNT/usr/local/bin/riceos-sync-desktop" <<'SYNC'
#!/bin/sh
D=/home/riceos/Desktop
mkdir -p "$D"
for f in /usr/share/applications/*.desktop; do
  [ -f "$f" ] || continue
  grep -qi '^NoDisplay=true' "$f" && continue
  ln -sf "$f" "$D/$(basename "$f")"
done
for l in "$D"/*.desktop; do [ -L "$l" ] && [ ! -e "$l" ] && rm -f "$l"; done
chown -R riceos:riceos "$D" 2>/dev/null || true
exit 0
SYNC
chmod 755 "$MNT/usr/local/bin/riceos-sync-desktop"
mkdir -p "$MNT/etc/apt/apt.conf.d"
cat > "$MNT/etc/apt/apt.conf.d/99riceos-desktop" <<'HOOK'
DPkg::Post-Invoke { "/usr/local/bin/riceos-sync-desktop || true"; };
HOOK

# 표준 X 설정: 커널 DRM(modesetting) 과 libinput 사용, 커서는 그래픽 카드 하드웨어 커서
mkdir -p "$MNT/etc/X11/xorg.conf.d"
cat > "$MNT/etc/X11/xorg.conf.d/10-riceos.conf" <<'XCONF'
Section "Device"
    Identifier "riceos-gpu"
    Driver "modesetting"
    Option "AccelMethod" "glamor"
    Option "SWcursor" "off"
EndSection

Section "InputClass"
    Identifier "riceos-input"
    MatchIsPointer "on"
    Driver "libinput"
EndSection
XCONF

# Chromium 기본 플래그: GPU 가속을 끈다. X(fbdev/모드세팅) 환경에서 GPU 렌더링이 실패하면 창이 검게 나온다.
# Debian 의 chromium 실행기는 /etc/chromium.d/ 를 읽어 CHROMIUM_FLAGS 를 붙인다 (메뉴와 바로가기 모두 적용).
mkdir -p "$MNT/etc/chromium.d"
cat > "$MNT/etc/chromium.d/riceos" <<'CHFLAGS'
# RICEOS: 검은 창을 막기 위해 GPU 가속을 끈다 (소프트웨어 렌더링)
CHROMIUM_FLAGS="$CHROMIUM_FLAGS --disable-gpu --disable-gpu-compositing"
CHFLAGS
# Chromium 이 화면을 검게 만들 때 쓰는 안전 모드 실행 항목 (GPU 가속 끔)
mkdir -p "$MNT/usr/local/share/applications"
cat > "$MNT/usr/local/share/applications/riceos-chromium-safe.desktop" <<'DESK'
[Desktop Entry]
Type=Application
Name=Chromium (안전 모드)
Name[ko]=Chromium (안전 모드)
Comment=GPU 가속을 끄고 실행 (화면이 검게 나올 때)
Exec=dbus-run-session -- chromium --disable-gpu --disable-gpu-compositing %U
Icon=chromium
Terminal=false
Categories=Network;WebBrowser;
DESK

# RICEOS 설정 / 앱 목록 바로가기
mkdir -p "$MNT/usr/share/applications"
cat > "$MNT/usr/share/applications/riceos-settings.desktop" <<'DESK'
[Desktop Entry]
Type=Application
Name=RICEOS Settings
Name[ko]=RICEOS 설정
Name[ja]=RICEOS 設定
Name[zh]=RICEOS 设置
Name[fr]=Réglages RICEOS
Name[es]=Ajustes de RICEOS
Comment=네트워크, 소리, 디스플레이, 프린터 설정
Exec=riceos-ui
Icon=preferences-system
Terminal=false
Categories=Settings;
DESK
cat > "$MNT/usr/share/applications/riceos-quick.desktop" <<'DESK'
[Desktop Entry]
Type=Application
Name=Quick Settings
Name[ko]=빠른 설정
Name[ja]=クイック設定
Name[zh]=快速设置
Name[fr]=Réglages rapides
Name[es]=Ajustes rápidos
Comment=무선과 소리를 빠르게 조절
Exec=riceos-ui --quick
Icon=preferences-system
Terminal=false
Categories=Settings;
DESK
cat > "$MNT/usr/share/applications/riceos-install.desktop" <<'DESK'
[Desktop Entry]
Type=Application
Name=Install RICEOS
Name[ko]=RICEOS 설치
Name[ja]=RICEOS のインストール
Name[zh]=安装 RICEOS
Name[fr]=Installer RICEOS
Name[es]=Instalar RICEOS
Comment=USB 임시 모드에서 하드디스크에 설치
Exec=riceos-ui --install
Icon=system-software-install
Terminal=false
Categories=System;
DESK
cat > "$MNT/usr/share/applications/riceos-apps.desktop" <<'DESK'
[Desktop Entry]
Type=Application
Name=Apps
Name[ko]=앱 목록
Name[ja]=アプリ一覧
Name[zh]=应用列表
Name[fr]=Applications
Name[es]=Aplicaciones
Comment=설치된 앱 보기
Exec=riceos-ui --menu
Icon=view-app-grid-symbolic
Terminal=false
Categories=Utility;
DESK

# riceos 사용자는 관리자(root 권한)다. 대부분의 명령은 묻지 않고 실행한다.
# 하드디스크 설치(riceos-install)만 riceos 비밀번호를 다시 묻는다 (riceos-auth 파일의 PASSWD 규칙).
# sudoers.d 는 이름 순서대로 읽고 뒤의 규칙이 이기므로, 이 파일 이름은 riceos-auth 보다 앞이어야 한다.
cat > "$MNT/etc/sudoers.d/riceos-admin" <<'ADMIN'
riceos ALL=(ALL:ALL) NOPASSWD: ALL
ADMIN
chmod 440 "$MNT/etc/sudoers.d/riceos-admin"

# 와이파이 연결 권한: 화면은 로그인 세션 없이 riceos 사용자로 뜨므로, NetworkManager 가 연결 추가를 막는다
# ("Not authorized to control networking"). riceos 사용자에게만 네트워크 설정 권한을 준다.
mkdir -p "$MNT/etc/polkit-1/rules.d"
cat > "$MNT/etc/polkit-1/rules.d/49-riceos-network.rules" <<'POLKIT'
polkit.addRule(function(action, subject) {
    if (subject.user == "riceos" && (
        action.id == "org.freedesktop.NetworkManager.network-control" ||
        action.id == "org.freedesktop.NetworkManager.settings.modify.system" ||
        action.id == "org.freedesktop.NetworkManager.settings.modify.own" ||
        action.id == "org.freedesktop.NetworkManager.wifi.share.protected" ||
        action.id == "org.freedesktop.NetworkManager.wifi.share.open")) {
        return polkit.Result.YES;
    }
});
POLKIT

# 리눅스 실행 파일(ELF)을 더블클릭하면 텍스트로 열지 않고 바로 실행한다
cat > "$MNT/usr/local/bin/riceos-run" <<'RUN'
#!/bin/sh
# RICEOS: 실행 파일을 연다. 실행 권한이 없으면 먼저 준다 (USB 같은 곳의 파일 대비)
f="$1"
[ -f "$f" ] || exit 1
[ -x "$f" ] || chmod +x "$f" 2>/dev/null
exec "$f"
RUN
chmod 755 "$MNT/usr/local/bin/riceos-run"
cat > "$MNT/usr/share/applications/riceos-run.desktop" <<'DESK'
[Desktop Entry]
Type=Application
Name=RICEOS 실행
Exec=/usr/local/bin/riceos-run %f
MimeType=application/x-executable;application/x-pie-executable;application/x-sharedlib;
NoDisplay=true
DESK
mkdir -p "$MNT/etc/xdg"
cat > "$MNT/etc/xdg/mimeapps.list" <<'MIME'
[Default Applications]
application/x-executable=riceos-run.desktop
application/x-pie-executable=riceos-run.desktop
application/x-sharedlib=riceos-run.desktop
MIME

chroot "$MNT" /bin/bash -e <<'CHROOT'
locale-gen
id riceos >/dev/null 2>&1 || useradd -m -s /bin/bash -G audio,video,input,sudo,lpadmin riceos
# 기본 비밀번호는 두지 않는다: root 는 잠그고, riceos 는 처음 설정(로그인 화면)에서 정한 비밀번호로 열린다
passwd -l root || true
passwd -l riceos || true
sed -i 's/^GRUB_TIMEOUT=.*/GRUB_TIMEOUT=0/' /etc/default/grub
sed -i 's/^GRUB_CMDLINE_LINUX_DEFAULT=.*/GRUB_CMDLINE_LINUX_DEFAULT="quiet splash loglevel=3 udev.log_level=3 rd.udev.log_level=3 systemd.show_status=false vt.global_cursor_default=0"/' /etc/default/grub
grep -q GRUB_TIMEOUT_STYLE /etc/default/grub || echo 'GRUB_TIMEOUT_STYLE=hidden' >> /etc/default/grub
# --removable: EFI/BOOT/BOOTX64.EFI 로 설치 (어느 PC에서든 USB로 부팅)
grub-install --target=x86_64-efi --efi-directory=/boot/efi --removable --no-nvram
systemctl disable systemd-networkd.service systemd-networkd.socket 2>/dev/null || true
systemctl enable riceos-ui.service NetworkManager.service systemd-resolved.service riceos-sound.service
systemctl enable alsa-restore.service 2>/dev/null || true
systemctl mask getty@tty1.service
# 부팅 화면 테마를 기본으로 정하고 initramfs에 넣는다 (부팅 초기부터 로고와 바가 보이게)
# 부팅 화면 기본값 지정. 실패해도 이미지 만들기는 계속한다 (부팅 화면은 꾸밈이라서)
# two-step 플러그인이 어느 패키지에 있는지 빌드 로그에 남긴다 (진단용)
echo "[진단] plymouth 플러그인:"; ls /usr/lib/x86_64-linux-gnu/plymouth/ 2>/dev/null | head -40 || true
echo "[진단] plymouth 패키지 안의 two-step:"; dpkg -L plymouth plymouth-themes 2>/dev/null | grep -i "two-step" || echo "[진단] 두 패키지 어디에도 two-step 없음"
dpkg -S two-step.so 2>/dev/null || echo "[진단] two-step.so 를 가진 설치된 패키지 없음"
# two-step 플러그인이 있으면 riceos 화면을 쓰고, 없으면 plymouth 기본 text 화면으로 바꾼다.
# (플러그인이 없는 채로 두면 부팅 화면이 떴다가 바로 사라진다)
TWO=$(ls /usr/lib/x86_64-linux-gnu/plymouth/two-step.so 2>/dev/null || true)
if [ -n "$TWO" ] && plymouth-set-default-theme riceos; then
  echo "[부팅 화면] riceos 테마 사용"
else
  echo "경고: two-step 플러그인이 없어 기본 text 부팅 화면을 씁니다"
  plymouth-set-default-theme text || echo "경고: text 부팅 화면도 설정하지 못했습니다"
  sed -i 's/^Theme=.*/Theme=text/' /etc/plymouth/plymouthd.conf 2>/dev/null || true
fi
# USB 무선랜 드라이버 (커널에 없는 Realtek 계열). 각 드라이버는 이 이미지 커널에 맞춰 따로 빌드한다.
# 한 개가 실패해도 나머지와 이미지 생성은 계속한다 (경고만 남김).
apt-get update -qq || echo "경고: apt 목록 갱신 실패"
apt-get install -y -qq build-essential git dkms linux-headers-amd64 || echo "경고: 빌드 도구 설치 실패 (무선랜 드라이버 빌드 생략)"
KV=$(ls /lib/modules | sort -V | tail -1)
for repo in \
    https://github.com/morrownr/88x2bu-20210702 \
    https://github.com/morrownr/8812au \
    https://github.com/morrownr/8821au \
    https://github.com/morrownr/8821cu \
    https://github.com/morrownr/rtl8852bu; do
  name=$(basename "$repo")
  src="/usr/src/$name-src"
  rm -rf "$src"
  if ! git clone --depth 1 "$repo" "$src"; then
    echo "경고: $name 소스를 받지 못했습니다. 이 칩의 USB 무선랜은 동작하지 않을 수 있습니다"
    continue
  fi
  # 빌드 오류는 워크플로 로그에 그대로 남긴다 (실패 원인 확인용)
  LOG="/var/log/riceos-build-$name.log"
  if make -C "$src" KVER="$KV" KSRC="/lib/modules/$KV/build" -j"$(nproc)" >"$LOG" 2>&1; then
    for ko in $(find "$src" -name "*.ko"); do
      install -D -m 644 "$ko" "/lib/modules/$KV/kernel/drivers/net/wireless/$(basename "$ko")"
    done
    echo "[무선랜] $name 빌드 완료 ($KV)"
  else
    echo "경고: $name 빌드 실패 (커널 $KV). 마지막 줄: $(tail -n 3 "$LOG" | tr '\n' ' ')"
  fi
done
depmod "$KV" || true
# 설치된 시스템은 systemd-resolved 를 쓴다 (빌드가 끝난 뒤에 연결)
ln -sf /run/systemd/resolve/stub-resolv.conf /etc/resolv.conf
update-initramfs -u -k all
apt-get clean
CHROOT

# 바탕화면: 단색 계란 노른자색 (노란색과 주황색 사이). pcmanfm 설정 + 세션 시작 때 X 루트 창 색
YOLK="#F5B52E"
PCM="$MNT/home/riceos/.config/pcmanfm/default"
mkdir -p "$PCM"
cat > "$PCM/desktop-items-0.conf" <<PCMDESK
[*]
wallpaper_common=1
wallpaper=
wallpaper_mode=color
desktop_bg=$YOLK
desktop_fg=#000000
desktop_shadow=#000000
PCMDESK
cat > "$PCM/pcmanfm.conf" <<PCMCONF
[desktop]
wallpaper_mode=color
bg_color=$YOLK
PCMCONF
chroot "$MNT" chown -R riceos:riceos /home/riceos/.config

# update-grub 대신 grub.cfg 직접 작성 (chroot 안 grub-probe 가 loop 장치를 찾지 못함)
mkdir -p "$MNT/boot/grub"
cat > "$MNT/boot/grub/grub.cfg" <<GRUBCFG
set timeout=0
set default=0
insmod part_gpt
insmod ext2
# 글 모드(DOS 같은 텍스트 화면) 대신 그래픽 화면을 쓴다: 검은 바탕
insmod all_video
insmod gfxterm
insmod png
set gfxmode=auto
set gfxpayload=keep
terminal_output gfxterm
set color_normal=white/black
set color_highlight=white/black
search --no-floppy --fs-uuid --set=root $ROOT_UUID
menuentry "RICEOS (임시 모드: 저장되지 않음)" {
    linux /live/vmlinuz boot=live live-media-path=/live $KCMD
    initrd /live/initrd.img
}
GRUBCFG
test -e "$MNT/vmlinuz" && test -e "$MNT/initrd.img" || { echo "커널 또는 initrd 심볼릭 링크가 없습니다"; exit 1; }

echo "[7/7] 정리 (USB 임시 모드 자료 만들기)"
# 임시 모드: 루트 파일 시스템은 squashfs 로 읽기 전용이고, 부팅 때 RAM 오버레이를 씌운다.
# 그래서 USB 에서 바꾼 내용은 재부팅하면 사라진다. 저장하려면 설치 프로그램(riceos-install)을 쓴다.
for m in sys proc dev/pts dev; do umount "$MNT/$m" 2>/dev/null || true; done
WORK="$(mktemp -d /tmp/riceos-sq.XXXXXX)"
# 마운트 지점 폴더(proc, sys, dev, run, tmp, boot/efi)는 남기고 안의 내용만 뺀다.
# (-e proc 처럼 쓰면 폴더까지 빠져서, 부팅 때 /dev, /proc 이 없어 커널 패닉이 난다)
for d in proc sys dev run tmp boot/efi; do mkdir -p "$MNT/$d"; done
mksquashfs "$MNT" "$WORK/filesystem.squashfs" -noappend -comp xz -no-progress -wildcards \
  -e 'proc/*' -e 'sys/*' -e 'dev/*' -e 'run/*' -e 'tmp/*' -e 'boot/efi/*'
mkdir -p "$MNT/live"
mv "$WORK/filesystem.squashfs" "$MNT/live/filesystem.squashfs"
rmdir "$WORK" 2>/dev/null || true
# 커널과 initrd 를 USB 의 /live 로 복사한다 (심볼릭 링크를 실제 파일로)
cp -L "$(ls -v "$MNT"/boot/vmlinuz-* | tail -1)" "$MNT/live/vmlinuz"
cp -L "$(ls -v "$MNT"/boot/initrd.img-* | tail -1)" "$MNT/live/initrd.img"
# USB 에는 부트 자료와 squashfs 만 남기고 나머지 루트 파일 시스템은 지운다
for d in "$MNT"/*; do
  case "$(basename "$d")" in live|boot|lost+found) continue ;; esac
  rm -rf "$d"
done
for d in "$MNT"/boot/*; do
  case "$(basename "$d")" in grub|efi) continue ;; esac
  rm -rf "$d"
done
test -s "$MNT/live/filesystem.squashfs" && test -s "$MNT/live/vmlinuz" && test -s "$MNT/live/initrd.img" \
  || { echo "임시 모드 자료를 만들지 못했습니다"; exit 1; }
sync
echo
echo "완료: $IMG"
echo "USB에 쓰기: Rufus에서 이 .img 를 선택 (DD 이미지 모드) — USB 전체가 지워집니다."
echo "USB 부팅은 임시 모드입니다: 바꾼 내용은 재부팅하면 사라집니다. 저장하려면 바탕화면의 '설치'를 쓰세요."
echo "비상용 콘솔: 처음 설정 뒤에 Ctrl+Alt+F2 → riceos / 설정한 비밀번호 (root 는 잠겨 있습니다)"

#ifndef RICEOS_FS_H
#define RICEOS_FS_H
#include "device.h"

typedef enum { FS_UNKNOWN, FS_FAT12, FS_FAT16, FS_FAT32, FS_EXFAT, FS_NTFS } fs_type;

const char *fs_name(fs_type t);
/* 부트 섹터(최소 512바이트)로 파일 시스템 종류 판별 */
fs_type fs_identify(const UINT8 *sector);
/* UTF-16 -> UTF-8 변환. 결과 길이를 돌려준다. */
UINT32 utf16_to_utf8(const CHAR16 *src, char *dst, UINT32 max);

void fs_init(EFI_BOOT_SERVICES *bs);
/* 파티션 목록과 파일 시스템 종류 출력 */
void fs_volumes(out_fn out);
/* N번 파티션 루트 디렉터리 목록 출력 (FAT 계열만) */
void fs_ls(UINT32 index, out_fn out);

#endif

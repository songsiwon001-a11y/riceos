/* 파일 시스템 드라이버 공용 정의: 볼륨 읽기, 디렉터리 항목, 바이트 도우미 */
#ifndef RICEOS_FS_COMMON_H
#define RICEOS_FS_COMMON_H
#include "efi.h"

/* 볼륨 읽기 함수: 볼륨 시작 기준 바이트 오프셋. 0 = 성공 */
typedef struct {
    int (*read)(void *ctx, UINT64 off, void *buf, UINT32 len);
    void *ctx;
} volume_t;

typedef struct {
    CHAR16 name[256];
    UINT8  is_dir;
    UINT64 size;
    UINT64 ref;   /* exFAT: 첫 클러스터 | (NoFatChain << 32), NTFS: MFT 번호 */
} dirent_t;

typedef void (*dir_cb)(void *ctx, const dirent_t *e);

static inline int vol_read(const volume_t *v, UINT64 off, void *buf, UINT32 len)
{
    return v->read(v->ctx, off, buf, len);
}
static inline UINT16 rd16(const UINT8 *p) { return (UINT16)(p[0] | (p[1] << 8)); }
static inline UINT32 rd32(const UINT8 *p)
{
    return (UINT32)p[0] | ((UINT32)p[1] << 8) | ((UINT32)p[2] << 16) | ((UINT32)p[3] << 24);
}
static inline UINT64 rd64(const UINT8 *p) { return (UINT64)rd32(p) | ((UINT64)rd32(p + 4) << 32); }
static inline int memeq_n(const UINT8 *a, const char *b, UINT32 n)
{
    for (UINT32 i = 0; i < n; i++) if (a[i] != (UINT8)b[i]) return 0;
    return 1;
}
static inline CHAR16 up_ascii(CHAR16 c) { return (c >= 'a' && c <= 'z') ? (CHAR16)(c - 32) : c; }
static inline int name_ieq(const CHAR16 *a, const CHAR16 *b)
{
    while (*a && *b) {
        if (up_ascii(*a) != up_ascii(*b)) return 0;
        a++; b++;
    }
    return *a == *b;
}
static inline void dirent_copy(dirent_t *d, const dirent_t *s)
{
    for (UINT32 i = 0; i < 256; i++) d->name[i] = s->name[i];
    d->is_dir = s->is_dir;
    d->size = s->size;
    d->ref = s->ref;
}
#endif

/* 최소 사양 검사: 2코어 2스레드 미만이면 USB 임시 부팅만 허용 */
#ifndef RICEOS_SYSREQ_H
#define RICEOS_SYSREQ_H
#include "efi.h"

#define REQ_CORES   2
#define REQ_THREADS 2

typedef struct {
    UINT32 cores;
    UINT32 threads;
    int    exact;       /* 1 = 펌웨어 MP Services로 측정, 0 = CPUID 추정 */
} cpu_info_t;

void cpu_detect(EFI_BOOT_SERVICES *bs, cpu_info_t *ci);
int  cpu_meets_req(const cpu_info_t *ci);
/* 이 로더가 USB 장치에서 시작됐으면 1 */
int  boot_from_usb(EFI_BOOT_SERVICES *bs, EFI_HANDLE image);

#endif

/* RICEOS 로더 v0.4 - 윈도우 7 스타일 바탕화면
 * 저장 장치 자동 감지, FAT/exFAT/NTFS 목록, 한글 폰트, 블루스크린
 */
#include "efi.h"
#include "gfx.h"
#include "device.h"
#include "fs.h"
#include "ui.h"
#include "net.h"
#include "boot.h"
#include "sysreq.h"

static EFI_GUID gop_guid = {
    0x9042a9de, 0x23dc, 0x4a38, { 0x96, 0xfb, 0x7a, 0xde, 0xd0, 0x80, 0x51, 0x6a }
};

static EFI_SYSTEM_TABLE *g_st;

static void wait_key(void)
{
    EFI_INPUT_KEY key;
    while (g_st->ConIn->ReadKeyStroke(g_st->ConIn, &key) != EFI_SUCCESS)
        ;
}

static void put2(char *d, UINT32 v)
{
    d[0] = (char)('0' + v / 10 % 10);
    d[1] = (char)('0' + v % 10);
}

/* 펌웨어 시계 -> 화면 문자열 */
static void update_clock(void)
{
    EFI_TIME t;
    char hm[8], ymd[12];
    if (g_st->RuntimeServices->GetTime(&t, 0) != EFI_SUCCESS) return;
    put2(hm, t.Hour); hm[2] = ':'; put2(hm + 3, t.Minute); hm[5] = 0;
    ymd[0] = (char)('0' + t.Year / 1000 % 10);
    ymd[1] = (char)('0' + t.Year / 100 % 10);
    put2(ymd + 2, t.Year % 100);
    ymd[4] = '-'; put2(ymd + 5, t.Month); ymd[7] = '-'; put2(ymd + 8, t.Day); ymd[10] = 0;
    ui_set_clock(hm, ymd);
}

EFI_STATUS efi_main(EFI_HANDLE image, EFI_SYSTEM_TABLE *st)
{
    EFI_GRAPHICS_OUTPUT_PROTOCOL *gop = 0;
    gfx_t g;
    EFI_INPUT_KEY key;
    UINT32 tick = 0;
    cpu_info_t cpu;
    int temp_mode = 0;

    g_st = st;
    /* 감시 타이머 해제: 켜 두면 5분 뒤 펌웨어가 강제로 재시작한다 */
    st->BootServices->SetWatchdogTimer(0, 0, 0, 0);
    if (st->BootServices->LocateProtocol(&gop_guid, 0, (void **)&gop) != EFI_SUCCESS || !gop)
        return 1;

    g.px     = (UINT32 *)(UINTN)gop->Mode->FrameBufferBase;
    g.stride = gop->Mode->Info->PixelsPerScanLine;
    g.w      = gop->Mode->Info->HorizontalResolution;
    g.h      = gop->Mode->Info->VerticalResolution;
    g.bgr    = (gop->Mode->Info->PixelFormat == 1);

    {
        UINT32 lx = 0, ly = 0;
        const UINT8 *bmp = boot_find_bgrt(st, &lx, &ly);
        boot_set_logo(bmp, lx, ly, bmp != 0);
    }
    boot_draw(&g, 0);
    st->BootServices->Stall(300000);
    cpu_detect(st->BootServices, &cpu);
    if (!cpu_meets_req(&cpu)) {
        if (!boot_from_usb(st->BootServices, image)) {
            gfx_text(&g, "이 컴퓨터는 최소 사양(2코어 2스레드)에 못 미칩니다.", 80, 80, 1, 0xFFFFFF, 0);
            gfx_text(&g, "USB 임시 부팅으로만 사용할 수 있습니다.", 80, 110, 1, 0xFFFFFF, 0);
            gfx_text(&g, "아무 키나 누르면 종료합니다.", 80, 160, 1, 0xBBBBBB, 0);
            wait_key();
            return 1;
        }
        temp_mode = 1;
    }
    boot_draw(&g, 20);
    device_init(st->BootServices);
    boot_draw(&g, 45);
    fs_init(st->BootServices);
    boot_draw(&g, 70);
    net_init(st->BootServices);
    boot_draw(&g, 90);
    ui_init(&g, wait_key);
    if (temp_mode) ui_print("[임시 부팅] 최소 사양 미만이라 USB 임시 부팅 모드로 동작합니다.\n");
    for (UINT32 p = 90; p <= 100; p += 2) {
        boot_draw(&g, p);
        st->BootServices->Stall(60000);
    }
    st->BootServices->Stall(300000);
    update_clock();
    ui_render();

    for (;;) {
        if (st->ConIn->ReadKeyStroke(st->ConIn, &key) == EFI_SUCCESS) {
            if (ui_handle_key(key.ScanCode, key.UnicodeChar))
                break;
            ui_render();
            continue;
        }
        /* 입력이 없을 때: 약 1초마다 장치 변화와 시계 확인 */
        st->BootServices->Stall(100000);
        if (++tick >= 10) {
            tick = 0;
            device_poll(ui_print);
            update_clock();
        }
        if (ui_dirty()) ui_render();
    }
    return EFI_SUCCESS;
}

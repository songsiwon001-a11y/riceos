#!/bin/sh
# clang + lld 로 빌드 (리눅스/맥 등). 결과: BOOTX64.EFI
# 필요: RICEOS_FONT.BIN, startup.pcm (같은 폴더)
set -e
T=x86_64-pc-windows-msvc
CF="-ffreestanding -fno-stack-protector -fno-builtin -nostdlib -Wall -Wextra -mno-red-zone -fshort-wchar -mno-stack-arg-probe"
OBJS=""
for s in riceos_font sound_data; do clang --target=$T -c $s.S -o $s.o; OBJS="$OBJS $s.o"; done
for m in main boot sysreq device fs fs_exfat fs_ntfs gfx ui pci net; do
  clang --target=$T $CF -c $m.c -o $m.o; OBJS="$OBJS $m.o"
done
lld-link /subsystem:efi_application /entry:efi_main /nodefaultlib /out:BOOTX64.EFI $OBJS
echo "built BOOTX64.EFI"

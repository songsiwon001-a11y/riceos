/* RICEOS 부팅 화면: 제조사 로고(ACPI BGRT) + 바 형 로딩 */
#ifndef RICEOS_BOOT_H
#define RICEOS_BOOT_H
#include "efi.h"
#include "gfx.h"

/* 펌웨어가 넘겨주는 BGRT 테이블에서 제조사 로고를 찾는다. 없으면 0을 돌려준다. */
const UINT8 *boot_find_bgrt(const EFI_SYSTEM_TABLE *st, UINT32 *x, UINT32 *y);
/* 로고 BMP 지정 (24/32비트 비압축). NULL이면 "RICEOS" 글자로 대체. */
void boot_set_logo(const UINT8 *bmp, UINT32 x, UINT32 y, int has_pos);
/* percent: 0~100. 첫 호출에 화면 전체를 그리고, 이후에는 바만 갱신한다. */
void boot_draw(gfx_t *g, UINT32 percent);

#endif

#include "gfx.h"

extern const UINT8 riceos_font[];
#define FONT_HDR   8
#define FONT_GLYPH 32

static void split(const gfx_t *g, UINT32 v, UINT32 *r, UINT32 *gg, UINT32 *b)
{
    if (g->bgr) { *r = (v >> 16) & 0xFF; *gg = (v >> 8) & 0xFF; *b = v & 0xFF; }
    else        { *b = (v >> 16) & 0xFF; *gg = (v >> 8) & 0xFF; *r = v & 0xFF; }
}

static UINT32 pack(const gfx_t *g, UINT32 rgb)
{
    UINT32 r = (rgb >> 16) & 0xFF, gg = (rgb >> 8) & 0xFF, b = rgb & 0xFF;
    return g->bgr ? (r << 16 | gg << 8 | b) : (b << 16 | gg << 8 | r);
}

static UINT32 clampu(UINT32 x, UINT32 max) { return x > max ? max : x; }

void gfx_rect(gfx_t *g, UINT32 x, UINT32 y, UINT32 w, UINT32 h, UINT32 rgb)
{
    UINT32 v = pack(g, rgb);
    UINT32 x1 = clampu(x + w, g->w), y1 = clampu(y + h, g->h);
    for (UINT32 yy = y; yy < y1; yy++)
        for (UINT32 xx = x; xx < x1; xx++)
            g->px[yy * g->stride + xx] = v;
}

void gfx_blend(gfx_t *g, UINT32 x, UINT32 y, UINT32 w, UINT32 h, UINT32 rgb, UINT32 a)
{
    UINT32 nr = (rgb >> 16) & 0xFF, ng = (rgb >> 8) & 0xFF, nb = rgb & 0xFF;
    UINT32 x1 = clampu(x + w, g->w), y1 = clampu(y + h, g->h);
    for (UINT32 yy = y; yy < y1; yy++)
        for (UINT32 xx = x; xx < x1; xx++) {
            UINT32 *p = &g->px[yy * g->stride + xx];
            UINT32 cr, cg, cb;
            split(g, *p, &cr, &cg, &cb);
            cr = (nr * a + cr * (255 - a)) / 255;
            cg = (ng * a + cg * (255 - a)) / 255;
            cb = (nb * a + cb * (255 - a)) / 255;
            *p = pack(g, (cr << 16) | (cg << 8) | cb);
        }
}

static UINT32 lerp(UINT32 a, UINT32 b, UINT32 t) { return (a * (255 - t) + b * t) / 255; }

void gfx_vgrad(gfx_t *g, UINT32 x, UINT32 y, UINT32 w, UINT32 h, UINT32 top, UINT32 bottom)
{
    UINT32 tr = (top >> 16) & 0xFF, tg = (top >> 8) & 0xFF, tb = top & 0xFF;
    UINT32 br = (bottom >> 16) & 0xFF, bg = (bottom >> 8) & 0xFF, bb = bottom & 0xFF;
    for (UINT32 i = 0; i < h; i++) {
        UINT32 t = h > 1 ? (i * 255) / (h - 1) : 0;
        UINT32 rgb = (lerp(tr, br, t) << 16) | (lerp(tg, bg, t) << 8) | lerp(tb, bb, t);
        gfx_rect(g, x, y + i, w, 1, rgb);
    }
}

/* 둥근 모서리 사각형: 각 행마다 모서리를 잘라낸다 */
void gfx_round_rect(gfx_t *g, UINT32 x, UINT32 y, UINT32 w, UINT32 h, UINT32 r, UINT32 rgb)
{
    if (r * 2 > h) r = h / 2;
    if (r * 2 > w) r = w / 2;
    for (UINT32 k = 0; k < h; k++) {
        UINT32 inset = 0;
        if (k < r) {
            /* 행 k의 중심 높이 dy = r - k - 0.5 (2배로 계산) */
            UINT32 dy2 = 2 * (r - k) - 1;
            for (inset = 0; inset < r; inset++) {
                UINT32 dx2 = 2 * (r - inset) - 1;
                if (dx2 * dx2 + dy2 * dy2 <= 4 * r * r) break;
            }
        } else if (k >= h - r) {
            UINT32 kk = h - 1 - k;
            UINT32 dy2 = 2 * (r - kk) - 1;
            for (inset = 0; inset < r; inset++) {
                UINT32 dx2 = 2 * (r - inset) - 1;
                if (dx2 * dx2 + dy2 * dy2 <= 4 * r * r) break;
            }
        }
        gfx_rect(g, x + inset, y + k, w - 2 * inset, 1, rgb);
    }
}

void gfx_circle(gfx_t *g, UINT32 cx, UINT32 cy, UINT32 r, UINT32 rgb)
{
    for (UINT32 dy = 0; dy <= 2 * r; dy++) {
        for (UINT32 dx = 0; dx <= 2 * r; dx++) {
            INT64 ex = (INT64)dx - (INT64)r, ey = (INT64)dy - (INT64)r;
            if (ex * ex + ey * ey > (INT64)r * r) continue;
            UINT32 px = cx - r + dx, py = cy - r + dy;
            if (px < g->w && py < g->h) g->px[py * g->stride + px] = pack(g, rgb);
        }
    }
}

static const UINT8 *glyph(UINT32 cp)
{
    UINT32 idx;
    if (cp >= 0x20 && cp <= 0x7E) idx = cp - 0x20;
    else if (cp >= 0xAC00 && cp <= 0xD7A3) idx = 95 + (cp - 0xAC00);
    else return 0;
    return riceos_font + FONT_HDR + idx * FONT_GLYPH;
}

UINT32 gfx_char(gfx_t *g, UINT32 cp, UINT32 x, UINT32 y, UINT32 scale, UINT32 rgb, const rect_t *clip)
{
    const UINT8 *gl = glyph(cp);
    UINT32 cell = 16 * scale;
    UINT32 v = pack(g, rgb);
    if (!gl || cp == 0x20) return x + cell;   /* 공백은 그리지 않음 */
    for (UINT32 row = 0; row < 16; row++) {
        UINT16 bits = (UINT16)(gl[row * 2] | (gl[row * 2 + 1] << 8));
        for (UINT32 col = 0; col < 16; col++) {
            if (!(bits & (0x8000 >> col))) continue;
            for (UINT32 sy = 0; sy < scale; sy++)
                for (UINT32 sx = 0; sx < scale; sx++) {
                    UINT32 px = x + col * scale + sx, py = y + row * scale + sy;
                    if (clip && (px < clip->x0 || px >= clip->x1 || py < clip->y0 || py >= clip->y1))
                        continue;
                    if (px < g->w && py < g->h) g->px[py * g->stride + px] = v;
                }
        }
    }
    return x + cell;
}

/* 반칸(8px) 글자: 16px 글자의 실제 내용(2~13열)을 8열로 줄여 그린다. 터미널의 영문과 숫자용 */
void gfx_char_half(gfx_t *g, UINT32 cp, UINT32 x, UINT32 y, UINT32 rgb, const rect_t *clip)
{
    const UINT8 *gl = glyph(cp);
    UINT32 v = pack(g, rgb);
    if (!gl || cp == 0x20) return;
    for (UINT32 row = 0; row < 16; row++) {
        UINT16 bits = (UINT16)(gl[row * 2] | (gl[row * 2 + 1] << 8));
        for (UINT32 oc = 0; oc < 8; oc++) {
            UINT32 src = 2 + oc * 12 / 8;
            UINT32 px = x + oc, py = y + row;
            if (!(bits & (0x8000 >> src))) continue;
            if (clip && (px < clip->x0 || px >= clip->x1 || py < clip->y0 || py >= clip->y1))
                continue;
            if (px < g->w && py < g->h) g->px[py * g->stride + px] = v;
        }
    }
}

UINT32 utf8_next(const char **p)
{
    const UINT8 *s = (const UINT8 *)*p;
    UINT32 cp;
    if (s[0] < 0x80)                { cp = s[0]; *p += 1; }
    else if ((s[0] & 0xE0) == 0xC0) { cp = ((s[0] & 0x1F) << 6) | (s[1] & 0x3F); *p += 2; }
    else if ((s[0] & 0xF0) == 0xE0) { cp = ((s[0] & 0x0F) << 12) | ((s[1] & 0x3F) << 6) | (s[2] & 0x3F); *p += 3; }
    else if (s[0] == 0)             { cp = 0; }
    else                            { cp = '?'; *p += 1; }
    return cp;
}

UINT32 gfx_text(gfx_t *g, const char *s, UINT32 x, UINT32 y, UINT32 scale, UINT32 rgb, const rect_t *clip)
{
    while (*s) {
        UINT32 cp = utf8_next(&s);
        x = gfx_char(g, cp, x, y, scale, rgb, clip);
    }
    return x;
}

UINT32 gfx_text_width(const char *s, UINT32 scale)
{
    UINT32 n = 0;
    while (*s) { utf8_next(&s); n++; }
    return n * 16 * scale;
}

/* exFAT 읽기 전용 드라이버
 * - 부트 섹터 -> FAT -> 클러스터 힙 -> 디렉터리 엔트리 세트(0x85/0xC0/0xC1)
 * - NoFatChain(연속 클러스터)과 FAT 체인 모두 지원
 */
#include "fs_exfat.h"

typedef struct {
    UINT32 bps;       /* 섹터 크기 */
    UINT32 cbytes;    /* 클러스터 크기 */
    UINT32 heap_sec;  /* 클러스터 힙 시작 (섹터) */
    UINT32 fat_sec;   /* FAT 시작 (섹터) */
    UINT32 root;      /* 루트 디렉터리 첫 클러스터 */
    UINT32 count;     /* 클러스터 개수 */
} geo_t;

static int load_geo(const volume_t *v, geo_t *g)
{
    UINT8 b[512];
    if (vol_read(v, 0, b, sizeof(b))) return 1;
    if (!memeq_n(b + 3, "EXFAT   ", 8)) return 1;
    UINT8 bsh = b[108], csh = b[109];
    if (bsh < 9 || bsh > 12 || csh > 25) return 1;
    g->bps = 1u << bsh;
    g->cbytes = g->bps << csh;
    g->fat_sec = rd32(b + 80);
    g->heap_sec = rd32(b + 88);
    g->count = rd32(b + 92);
    g->root = rd32(b + 96);
    if (g->root < 2 || g->root - 2 >= g->count) return 1;
    return 0;
}

static int is_end(UINT32 c) { return c < 2 || c >= 0xFFFFFFF0u; }

static int clus_off(const geo_t *g, UINT32 c, UINT64 *off)
{
    if (c < 2 || c - 2 >= g->count) return 1;
    *off = (UINT64)g->heap_sec * g->bps + (UINT64)(c - 2) * g->cbytes;
    return 0;
}

static UINT32 fat_next(const volume_t *v, const geo_t *g, UINT32 c)
{
    UINT8 b[4];
    if (vol_read(v, (UINT64)g->fat_sec * g->bps + (UINT64)c * 4, b, 4)) return 0xFFFFFFFFu;
    return rd32(b);
}

/* 스트림의 pos 위치부터 len 바이트 읽기 */
static int stream_read(const volume_t *v, const geo_t *g, UINT32 first, int nofat,
                       UINT64 pos, UINT8 *out, UINT32 len)
{
    while (len) {
        UINT64 idx = pos / g->cbytes;
        UINT32 in = (UINT32)(pos % g->cbytes);
        UINT32 c = first;
        if (nofat) {
            c = first + (UINT32)idx;
        } else {
            for (UINT64 k = 0; k < idx; k++) {
                c = fat_next(v, g, c);
                if (is_end(c)) return 1;
            }
        }
        UINT64 base;
        if (clus_off(g, c, &base)) return 1;
        UINT32 chunk = g->cbytes - in;
        if (chunk > len) chunk = len;
        if (vol_read(v, base + in, out, chunk)) return 1;
        out += chunk;
        pos += chunk;
        len -= chunk;
    }
    return 0;
}

/* FAT 체인을 따라가며 디렉터리 전체 크기 계산 (루트용) */
static UINT64 chain_bytes(const volume_t *v, const geo_t *g, UINT32 first)
{
    UINT64 n = 0;
    UINT32 c = first;
    while (!is_end(c) && c - 2 < g->count && n < g->count) {
        n++;
        c = fat_next(v, g, c);
    }
    return n * g->cbytes;
}

/* 디렉터리 엔트리 세트를 순회 */
static int scan_dir(const volume_t *v, const geo_t *g, UINT32 first, int nofat,
                    UINT64 size, dir_cb cb, void *ctx)
{
    UINT8 e[32], e2[32], e3[32];
    dirent_t de;
    UINT64 pos = 0;

    while (pos + 32 <= size) {
        if (stream_read(v, g, first, nofat, pos, e, 32)) return 1;
        if (e[0] == 0x00) break;                       /* 디렉터리 끝 */
        if (e[0] != 0x85 || e[1] < 2) { pos += 32; continue; }

        UINT32 sec = e[1];                             /* 보조 엔트리 개수 */
        UINT16 attr = rd16(e + 4);
        if (pos + 32 * (1 + (UINT64)sec) > size) break;

        if (stream_read(v, g, first, nofat, pos + 32, e2, 32)) return 1;
        if (e2[0] != 0xC0) { pos += 32 * (1 + (UINT64)sec); continue; }

        UINT32 nlen = e2[3];
        int snofat = (e2[1] & 0x02) != 0;
        UINT32 sfirst = rd32(e2 + 20);
        UINT64 dlen = rd64(e2 + 24);

        UINT32 n = 0;
        for (UINT32 i = 0; i + 1 < sec && n < nlen && n < 255; i++) {
            if (stream_read(v, g, first, nofat, pos + 32 * (2 + (UINT64)i), e3, 32)) return 1;
            if (e3[0] != 0xC1) break;
            for (UINT32 k = 0; k < 15 && n < nlen && n < 255; k++)
                de.name[n++] = rd16(e3 + 2 + 2 * k);
        }
        de.name[n] = 0;

        if (n > 0) {
            de.is_dir = (attr & 0x10) != 0;
            de.size = dlen;
            de.ref = (UINT64)sfirst | ((UINT64)snofat << 32);
            cb(ctx, &de);
        }
        pos += 32 * (1 + (UINT64)sec);
    }
    return 0;
}

int exfat_probe(const volume_t *v)
{
    geo_t g;
    return load_geo(v, &g);
}

int exfat_list_root(const volume_t *v, dir_cb cb, void *ctx)
{
    geo_t g;
    if (load_geo(v, &g)) return 1;
    UINT64 size = chain_bytes(v, &g, g.root);
    return scan_dir(v, &g, g.root, 0, size, cb, ctx);
}

struct finder {
    const CHAR16 *want;
    dirent_t got;
    int found;
};

static void find_cb(void *c, const dirent_t *e)
{
    struct finder *f = (struct finder *)c;
    if (!f->found && name_ieq(e->name, f->want)) {
        dirent_copy(&f->got, e);
        f->found = 1;
    }
}

int exfat_read_root_file(const volume_t *v, const CHAR16 *name, UINT8 *out, UINT32 cap, UINT32 *len)
{
    geo_t g;
    struct finder f;
    if (load_geo(v, &g)) return 1;
    f.want = name;
    f.found = 0;
    if (exfat_list_root(v, find_cb, &f)) return 1;
    if (!f.found || f.got.is_dir) return 1;
    if (f.got.size > cap) return 1;
    UINT32 first = (UINT32)(f.got.ref & 0xFFFFFFFFu);
    int nofat = (int)((f.got.ref >> 32) & 1);
    if (f.got.size && stream_read(v, &g, first, nofat, 0, out, (UINT32)f.got.size)) return 1;
    *len = (UINT32)f.got.size;
    return 0;
}

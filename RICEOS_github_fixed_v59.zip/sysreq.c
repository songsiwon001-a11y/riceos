#include "sysreq.h"

static EFI_GUID mp_guid = {
    0x3fdda605, 0xa76e, 0x4f46, { 0xad, 0x29, 0x12, 0xf4, 0x53, 0x1b, 0x3d, 0x08 }
};
static EFI_GUID loaded_image_guid = {
    0x5B1B31A1, 0x9562, 0x11d2, { 0x8E, 0x3F, 0x00, 0xA0, 0xC9, 0x69, 0x72, 0x3B }
};
static EFI_GUID devpath_guid = {
    0x09576e91, 0x6d3f, 0x11d2, { 0x8e, 0x39, 0x00, 0xa0, 0xc9, 0x69, 0x72, 0x3b }
};

#define MAX_CPU 256

static void cpuid(UINT32 leaf, UINT32 *a, UINT32 *b, UINT32 *c, UINT32 *d)
{
    __asm__ volatile ("cpuid" : "=a"(*a), "=b"(*b), "=c"(*c), "=d"(*d) : "a"(leaf), "c"(0));
}

/* MP Services가 없을 때: CPUID로 논리 프로세서 수만 추정 (코어 수는 알 수 없어 같은 값 사용) */
static void detect_cpuid(cpu_info_t *ci)
{
    UINT32 a, b, c, d, n = 1;
    cpuid(1, &a, &b, &c, &d);
    if (d & (1u << 28)) {
        n = (b >> 16) & 0xFF;
        if (n == 0) n = 1;
    }
    ci->threads = n;
    ci->cores = n;
    ci->exact = 0;
}

void cpu_detect(EFI_BOOT_SERVICES *bs, cpu_info_t *ci)
{
    EFI_MP_SERVICES *mp = 0;
    static UINT32 pkg[MAX_CPU], core[MAX_CPU];
    UINTN total = 0, enabled = 0;
    UINT32 threads = 0, cores = 0;

    if (bs->LocateProtocol(&mp_guid, 0, (void **)&mp) != EFI_SUCCESS || !mp ||
        mp->GetNumberOfProcessors(mp, &total, &enabled) != EFI_SUCCESS || total == 0) {
        detect_cpuid(ci);
        return;
    }
    if (total > MAX_CPU) total = MAX_CPU;

    for (UINTN i = 0; i < total; i++) {
        EFI_PROCESSOR_INFORMATION pi;
        int seen = 0;
        if (mp->GetProcessorInfo(mp, i, &pi) != EFI_SUCCESS) continue;
        if (!(pi.StatusFlag & 0x2)) continue;            /* 비활성 프로세서는 제외 */
        threads++;
        for (UINT32 k = 0; k < cores; k++)
            if (pkg[k] == pi.Package && core[k] == pi.Core) { seen = 1; break; }
        if (!seen) { pkg[cores] = pi.Package; core[cores] = pi.Core; cores++; }
    }
    if (threads == 0) { detect_cpuid(ci); return; }
    ci->threads = threads;
    ci->cores = cores;
    ci->exact = 1;
}

int cpu_meets_req(const cpu_info_t *ci)
{
    return ci->cores >= REQ_CORES && ci->threads >= REQ_THREADS;
}

int boot_from_usb(EFI_BOOT_SERVICES *bs, EFI_HANDLE image)
{
    EFI_LOADED_IMAGE *li = 0;
    UINT8 *p = 0;

    if (bs->HandleProtocol(image, &loaded_image_guid, (void **)&li) != EFI_SUCCESS || !li || !li->DeviceHandle)
        return 0;
    if (bs->HandleProtocol(li->DeviceHandle, &devpath_guid, (void **)&p) != EFI_SUCCESS || !p)
        return 0;
    for (;;) {
        UINT8 type = p[0], sub = p[1];
        UINT16 len = (UINT16)(p[2] | (p[3] << 8));
        if (type == 0x7F) break;
        if (type == 3 && (sub == 0x05 || sub == 0x0F)) return 1;   /* USB / USB 클래스 */
        if (len < 4) break;
        p += len;
    }
    return 0;
}

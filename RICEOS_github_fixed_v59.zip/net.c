/* 유선 랜: 펌웨어의 Simple Network 프로토콜을 사용 (직접 드라이버 없음) */
#include "net.h"

static EFI_GUID snp_guid = {
    0xA19832B9, 0xAC25, 0x11D3, { 0x9A, 0x2D, 0x00, 0x90, 0x27, 0x3F, 0xC1, 0x4D }
};

static EFI_BOOT_SERVICES *bs;
static EFI_SIMPLE_NETWORK_PROTOCOL *snp;

void net_init(EFI_BOOT_SERVICES *boot)
{
    bs = boot;
    snp = 0;
    if (bs->LocateProtocol(&snp_guid, 0, (void **)&snp) != EFI_SUCCESS)
        snp = 0;
}

static void put_mac(char *d, const UINT8 *m, UINT32 n)
{
    static const char hex[] = "0123456789ABCDEF";
    UINT32 k = 0;
    for (UINT32 i = 0; i < n; i++) {
        if (i) d[k++] = ':';
        d[k++] = hex[m[i] >> 4];
        d[k++] = hex[m[i] & 0xF];
    }
    d[k] = 0;
}

void net_info(net_out_fn out)
{
    char line[120];
    char mac[40];
    EFI_SNP_MODE *m;
    const char *state;

    if (!snp || !snp->Mode) {
        out("네트워크: 펌웨어 랜 드라이버가 없습니다.\n");
        return;
    }
    m = snp->Mode;
    /* 상태 1 = 정지됨: 시작하고 초기화한다 */
    if (m->State == 1) {
        if (snp->Start(snp) == EFI_SUCCESS)
            snp->Initialize(snp, 0, 0);
    }
    switch (m->State) {
    case 1: state = "정지"; break;
    case 2: state = "시작됨"; break;
    case 3: state = "초기화됨"; break;
    default: state = "알 수 없음"; break;
    }
    put_mac(mac, m->CurrentAddress, m->HwAddressSize ? m->HwAddressSize : 6);
    out("네트워크(유선):\n");
    {
        char *p = line; const char *s = "  상태: "; while (*s) *p++ = *s++;
        s = state; while (*s) *p++ = *s++;
        *p++ = '\n'; *p = 0;
        out(line);
    }
    {
        char *p = line; const char *s = "  MAC 주소: "; while (*s) *p++ = *s++;
        s = mac; while (*s) *p++ = *s++;
        *p++ = '\n'; *p = 0;
        out(line);
    }
    out(m->MediaPresent ? "  케이블: 연결됨\n" : "  케이블: 연결 안 됨\n");
}

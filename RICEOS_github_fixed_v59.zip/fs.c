/* RICEOS 파일 시스템 계층
 * - 판별: 부트 섹터 기준 (FAT12/16/32, exFAT, NTFS)
 * - FAT: 펌웨어의 Simple File System 프로토콜 사용
 * - exFAT/NTFS: 자체 읽기 드라이버 (fs_exfat.c, fs_ntfs.c)
 */
#include "fs.h"
#include "fs_common.h"
#include "fs_exfat.h"
#include "fs_ntfs.h"

static EFI_GUID blockio_guid = {
    0x964e5b21, 0x6459, 0x11d2, { 0x8e, 0x39, 0x00, 0xa0, 0xc9, 0x69, 0x72, 0x3b }
};
static EFI_GUID sfs_guid = {
    0x964e5b22, 0x6459, 0x11d2, { 0x8e, 0x39, 0x00, 0xa0, 0xc9, 0x69, 0x72, 0x3b }
};

#define MAX_VOL     32
#define SECTOR_MAX  4096
#define SCRATCH_MAX 16384

static EFI_BOOT_SERVICES *bs;
static EFI_HANDLE vol_handle[MAX_VOL];
static UINT32 nvol;
static EFI_HANDLE raw[MAX_VOL];

/* ---------- 순수 계산 (호스트 테스트 가능) ---------- */
static int memeq(const UINT8 *a, const char *b, UINT32 n)
{
    for (UINT32 i = 0; i < n; i++)
        if (a[i] != (UINT8)b[i]) return 0;
    return 1;
}

const char *fs_name(fs_type t)
{
    switch (t) {
    case FS_FAT12: return "FAT12";
    case FS_FAT16: return "FAT16";
    case FS_FAT32: return "FAT32";
    case FS_EXFAT: return "exFAT";
    case FS_NTFS:  return "NTFS";
    default:       return "알 수 없음";
    }
}

fs_type fs_identify(const UINT8 *s)
{
    if (s[510] != 0x55 || s[511] != 0xAA) return FS_UNKNOWN;
    if (memeq(s + 3, "EXFAT   ", 8)) return FS_EXFAT;
    if (memeq(s + 3, "NTFS    ", 8)) return FS_NTFS;
    if (memeq(s + 82, "FAT32   ", 8)) return FS_FAT32;
    if (memeq(s + 54, "FAT16   ", 8)) return FS_FAT16;
    if (memeq(s + 54, "FAT12   ", 8)) return FS_FAT12;
    return FS_UNKNOWN;
}

UINT32 utf16_to_utf8(const CHAR16 *src, char *dst, UINT32 max)
{
    UINT32 n = 0;
    while (*src) {
        UINT32 c = *src++;
        if (c < 0x80) {
            if (n + 2 > max) break;
            dst[n++] = (char)c;
        } else if (c < 0x800) {
            if (n + 3 > max) break;
            dst[n++] = (char)(0xC0 | (c >> 6));
            dst[n++] = (char)(0x80 | (c & 0x3F));
        } else {
            if (n + 4 > max) break;
            dst[n++] = (char)(0xE0 | (c >> 12));
            dst[n++] = (char)(0x80 | ((c >> 6) & 0x3F));
            dst[n++] = (char)(0x80 | (c & 0x3F));
        }
    }
    dst[n] = 0;
    return n;
}

/* ---------- 펌웨어 블록 장치 -> 볼륨 읽기 ---------- */
/* 블록 단위로 정렬해서 읽고, 필요한 부분만 복사 */
static int fw_read(void *ctx, UINT64 off, void *buf, UINT32 len)
{
    EFI_BLOCK_IO *bio = (EFI_BLOCK_IO *)ctx;
    static UINT8 scratch[SCRATCH_MAX];
    UINT32 bsz = bio->Media->BlockSize;
    UINT8 *dst = (UINT8 *)buf;

    if (bsz < 512 || bsz > 4096) return 1;
    while (len) {
        UINT32 head = (UINT32)(off % bsz);
        UINT32 want = len > 8192 ? 8192 : len;
        UINT32 nbytes = ((head + want + bsz - 1) / bsz) * bsz;
        if (bio->ReadBlocks(bio, bio->Media->MediaId, off / bsz, nbytes, scratch) != EFI_SUCCESS)
            return 1;
        for (UINT32 i = 0; i < want; i++) dst[i] = scratch[head + i];
        dst += want;
        off += want;
        len -= want;
    }
    return 0;
}

static volume_t make_vol(EFI_BLOCK_IO *bio)
{
    volume_t v;
    v.read = fw_read;
    v.ctx = bio;
    return v;
}

/* ---------- 파티션 수집과 조회 ---------- */
static EFI_BLOCK_IO *bio_of(EFI_HANDLE h)
{
    EFI_BLOCK_IO *bio = 0;
    bs->HandleProtocol(h, &blockio_guid, (void **)&bio);
    return bio;
}

static void scan(void)
{
    UINTN size = sizeof(raw);
    nvol = 0;
    if (bs->LocateHandle(EFI_LOCATE_BY_PROTOCOL, &blockio_guid, 0, &size, raw) != EFI_SUCCESS)
        return;
    for (UINT32 i = 0; i < size / sizeof(EFI_HANDLE) && nvol < MAX_VOL; i++) {
        EFI_BLOCK_IO *bio = bio_of(raw[i]);
        if (!bio || !bio->Media->LogicalPartition) continue;
        vol_handle[nvol++] = raw[i];
    }
}

/* 첫 섹터로 종류 판별. 미디어가 없으면 has_media = 0 */
static fs_type probe(EFI_HANDLE h, BOOLEAN *has_fs, BOOLEAN *has_media)
{
    static UINT8 buf[SECTOR_MAX];
    EFI_BLOCK_IO *bio = bio_of(h);
    void *sfs = 0;
    *has_fs = 0;
    *has_media = 0;
    if (!bio || !bio->Media->MediaPresent) return FS_UNKNOWN;
    *has_media = 1;
    if (bio->Media->BlockSize < 512 || bio->Media->BlockSize > SECTOR_MAX) return FS_UNKNOWN;
    if (bio->ReadBlocks(bio, bio->Media->MediaId, 0, bio->Media->BlockSize, buf) != EFI_SUCCESS)
        return FS_UNKNOWN;
    *has_fs = (bs->HandleProtocol(h, &sfs_guid, &sfs) == EFI_SUCCESS && sfs != 0);
    return fs_identify(buf);
}

void fs_init(EFI_BOOT_SERVICES *boot)
{
    bs = boot;
    scan();
}

void fs_volumes(out_fn out)
{
    char line[200];
    char *p;
    scan();
    if (nvol == 0) { out("파티션이 없습니다.\n"); return; }
    out("파티션 목록:\n");
    for (UINT32 i = 0; i < nvol; i++) {
        BOOLEAN has_fs, has_media;
        fs_type t = probe(vol_handle[i], &has_fs, &has_media);
        volume_t v = make_vol(bio_of(vol_handle[i]));
        p = line;
        p += 0;
        const char *s = "  [";
        while (*s) *p++ = *s++;
        UINT32 num = i + 1;
        char tmp[12]; int nt = 0;
        do { tmp[nt++] = (char)('0' + num % 10); num /= 10; } while (num);
        while (nt) *p++ = tmp[--nt];
        s = "] ";
        while (*s) *p++ = *s++;
        s = fs_name(t);
        while (*s) *p++ = *s++;
        s = "  ";
        while (*s) *p++ = *s++;

        if (!has_media)                          s = "(미디어 없음)";
        else if (has_fs)                         s = "(읽기 가능)";
        else if (t == FS_EXFAT && exfat_probe(&v) == 0) s = "(읽기 가능)";
        else if (t == FS_NTFS && ntfs_probe(&v) == 0)   s = "(읽기 가능)";
        else if (t == FS_EXFAT || t == FS_NTFS)  s = "(읽기 실패)";
        else                                     s = "(지원하지 않음)";
        while (*s) *p++ = *s++;
        *p++ = '\n';
        *p = 0;
        out(line);
    }
}

/* ---------- 디렉터리 출력 ---------- */
struct printer { out_fn out; };

static void print_entry(void *ctx, const dirent_t *e)
{
    static char nbuf[800];
    static char line[900];
    struct printer *pr = (struct printer *)ctx;
    char *p = line;
    const char *s;
    utf16_to_utf8(e->name, nbuf, sizeof(nbuf));
    s = "  ";
    while (*s) *p++ = *s++;
    s = e->is_dir ? "[DIR] " : "      ";
    while (*s) *p++ = *s++;
    s = nbuf;
    while (*s) *p++ = *s++;
    if (!e->is_dir) {
        char tmp[24]; int nt = 0;
        UINT64 v = e->size;
        do { tmp[nt++] = (char)('0' + v % 10); v /= 10; } while (v);
        *p++ = ' '; *p++ = ' ';
        while (nt) *p++ = tmp[--nt];
        s = " B";
        while (*s) *p++ = *s++;
    }
    *p++ = '\n';
    *p = 0;
    pr->out(line);
}

/* FAT: 펌웨어 파일 프로토콜로 루트 목록 */
static int list_fat(EFI_HANDLE h, EFI_SIMPLE_FILE_SYSTEM *sfs, struct printer *pr)
{
    static UINT8 info[512];
    EFI_FILE *root = 0;
    dirent_t de;
    (void)h;
    if (sfs->OpenVolume(sfs, &root) != EFI_SUCCESS || !root) return 1;
    for (;;) {
        UINTN size = sizeof(info);
        if (root->Read(root, &size, info) != EFI_SUCCESS || size == 0) break;
        UINT64 attr = (UINT64)rd64(info + 72);
        CHAR16 *name = (CHAR16 *)(info + 80);
        if (name[0] == '.' && (name[1] == 0 || (name[1] == '.' && name[2] == 0))) continue;
        UINT32 n = 0;
        while (n < 255 && name[n]) { de.name[n] = name[n]; n++; }
        de.name[n] = 0;
        de.is_dir = (attr & 0x10) != 0;
        de.size = rd64(info + 8);
        de.ref = 0;
        print_entry(pr, &de);
    }
    root->Close(root);
    return 0;
}

void fs_ls(UINT32 index, out_fn out)
{
    struct printer pr;
    EFI_SIMPLE_FILE_SYSTEM *sfs = 0;
    EFI_BLOCK_IO *bio;
    BOOLEAN has_fs, has_media;
    fs_type t;
    int rc;

    pr.out = out;
    scan();
    if (index < 1 || index > nvol) { out("잘못된 파티션 번호입니다.\n"); return; }

    bio = bio_of(vol_handle[index - 1]);
    t = probe(vol_handle[index - 1], &has_fs, &has_media);
    if (!has_media) { out("미디어가 없습니다.\n"); return; }

    out("루트 디렉터리:\n");
    if (has_fs && bs->HandleProtocol(vol_handle[index - 1], &sfs_guid, (void **)&sfs) == EFI_SUCCESS && sfs) {
        rc = list_fat(vol_handle[index - 1], sfs, &pr);
    } else {
        volume_t v = make_vol(bio);
        if (t == FS_EXFAT)      rc = exfat_list_root(&v, print_entry, &pr);
        else if (t == FS_NTFS)  rc = ntfs_list_root(&v, print_entry, &pr);
        else { out("이 파일 시스템은 목록을 읽을 수 없습니다.\n"); return; }
    }
    if (rc) out("디렉터리를 읽을 수 없습니다.\n");
}

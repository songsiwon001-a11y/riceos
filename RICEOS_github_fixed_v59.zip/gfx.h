/* 프레임버퍼 그리기 도구 (픽셀 쓰기, 사각형, 그라데이션, 알파 블렌딩, 한글 글자) */
#ifndef RICEOS_GFX_H
#define RICEOS_GFX_H
#include "efi.h"

typedef struct {
    UINT32 *px;       /* 프레임버퍼 */
    UINT32 stride;    /* 한 줄의 픽셀 수 */
    UINT32 w, h;
    int bgr;          /* 1 = BGR 순서 */
} gfx_t;

typedef struct { UINT32 x0, y0, x1, y1; } rect_t;   /* x1,y1은 제외 */

void gfx_rect(gfx_t *g, UINT32 x, UINT32 y, UINT32 w, UINT32 h, UINT32 rgb);
void gfx_blend(gfx_t *g, UINT32 x, UINT32 y, UINT32 w, UINT32 h, UINT32 rgb, UINT32 alpha);
void gfx_vgrad(gfx_t *g, UINT32 x, UINT32 y, UINT32 w, UINT32 h, UINT32 top, UINT32 bottom);
void gfx_round_rect(gfx_t *g, UINT32 x, UINT32 y, UINT32 w, UINT32 h, UINT32 r, UINT32 rgb);
void gfx_circle(gfx_t *g, UINT32 cx, UINT32 cy, UINT32 r, UINT32 rgb);
/* 글자 하나 (16x16 폰트를 scale배로 확대). 다음 x 좌표를 돌려준다. */
UINT32 gfx_char(gfx_t *g, UINT32 cp, UINT32 x, UINT32 y, UINT32 scale, UINT32 rgb, const rect_t *clip);
/* UTF-8 문자열. 끝 x 좌표를 돌려준다. */
UINT32 gfx_text(gfx_t *g, const char *s, UINT32 x, UINT32 y, UINT32 scale, UINT32 rgb, const rect_t *clip);
UINT32 gfx_text_width(const char *s, UINT32 scale);
/* 반칸(8px) 영문/숫자 글자 (터미널용) */
void gfx_char_half(gfx_t *g, UINT32 cp, UINT32 x, UINT32 y, UINT32 rgb, const rect_t *clip);
/* UTF-8 한 글자 디코딩. p는 다음 글자를 가리키도록 갱신된다. */
UINT32 utf8_next(const char **p);

#endif

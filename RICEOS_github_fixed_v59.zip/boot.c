#include "boot.h"

static const UINT8 *logo;
static UINT32 logo_x, logo_y;
static int logo_pos, drawn;
static UINT32 bar_y;

static EFI_GUID acpi2_guid = {
    0x8868e871, 0xe4f1, 0x11d3, { 0xbc, 0x22, 0x00, 0x80, 0xc7, 0x3c, 0x20, 0x81 }
};
static EFI_GUID acpi1_guid = {
    0xeb9d2d30, 0x2d88, 0x11d3, { 0x9a, 0x16, 0x00, 0x90, 0x27, 0x3f, 0xc1, 0x4d }
};

typedef struct { EFI_GUID guid; void *table; } cfg_entry_t;

static int guid_eq(const EFI_GUID *a, const EFI_GUID *b)
{
    const UINT8 *p = (const UINT8 *)a, *q = (const UINT8 *)b;
    for (UINT32 i = 0; i < sizeof(EFI_GUID); i++) if (p[i] != q[i]) return 0;
    return 1;
}
static UINT32 r32(const UINT8 *p)
{
    return (UINT32)p[0] | ((UINT32)p[1] << 8) | ((UINT32)p[2] << 16) | ((UINT32)p[3] << 24);
}
static UINT64 r64(const UINT8 *p) { return (UINT64)r32(p) | ((UINT64)r32(p + 4) << 32); }
static int sig_eq(const UINT8 *p, const char *s)
{
    for (int i = 0; i < 4; i++) if (p[i] != (UINT8)s[i]) return 0;
    return 1;
}

const UINT8 *boot_find_bgrt(const EFI_SYSTEM_TABLE *st, UINT32 *x, UINT32 *y)
{
    const cfg_entry_t *ct = (const cfg_entry_t *)st->ConfigurationTable;
    const UINT8 *rsdp = 0;

    for (UINTN i = 0; i < st->NumberOfTableEntries && ct; i++)
        if (guid_eq(&ct[i].guid, &acpi2_guid)) { rsdp = (const UINT8 *)ct[i].table; break; }
    if (!rsdp)
        for (UINTN i = 0; i < st->NumberOfTableEntries && ct; i++)
            if (guid_eq(&ct[i].guid, &acpi1_guid)) { rsdp = (const UINT8 *)ct[i].table; break; }
    if (!rsdp) return 0;
    for (int i = 0; i < 8; i++) if (rsdp[i] != (UINT8)"RSD PTR "[i]) return 0;

    {
        UINT64 xsdt = rsdp[15] >= 2 ? r64(rsdp + 24) : 0;
        const UINT8 *root = xsdt ? (const UINT8 *)(UINTN)xsdt : (const UINT8 *)(UINTN)r32(rsdp + 16);
        UINT32 esz = xsdt ? 8 : 4, n;
        if (!root) return 0;
        n = (r32(root + 4) - 36) / esz;
        if (n > 256) return 0;
        for (UINT32 i = 0; i < n; i++) {
            UINT64 a = esz == 8 ? r64(root + 36 + 8 * i) : r32(root + 36 + 4 * i);
            const UINT8 *t = (const UINT8 *)(UINTN)a;
            if (!t || !sig_eq(t, "BGRT")) continue;
            if (t[39] != 0) return 0;                     /* 이미지 형식 0 = BMP */
            *x = r32(t + 48);
            *y = r32(t + 52);
            {
                const UINT8 *bmp = (const UINT8 *)(UINTN)r64(t + 40);
                if (bmp && bmp[0] == 'B' && bmp[1] == 'M') return bmp;
            }
            return 0;
        }
    }
    return 0;
}

void boot_set_logo(const UINT8 *bmp, UINT32 x, UINT32 y, int has_pos)
{
    logo = bmp;
    logo_x = x;
    logo_y = y;
    logo_pos = has_pos;
    drawn = 0;
}

/* BMP 한 장을 (ox,oy)에 그린다. 24/32비트 비압축만 지원. 높이 크기를 돌려준다. */
static UINT32 draw_bmp(gfx_t *g, const UINT8 *b, UINT32 ox, UINT32 oy, UINT32 *out_w)
{
    UINT32 off = r32(b + 10);
    INT64 w = (INT64)(int)r32(b + 18), h = (INT64)(int)r32(b + 22);
    UINT32 bpp = (UINT32)(b[28] | (b[29] << 8)), comp = r32(b + 30);
    int up = h > 0;
    UINT32 stride;
    if (h < 0) h = -h;
    if (w <= 0 || h <= 0 || w > 2048 || h > 1024 || comp != 0 || (bpp != 24 && bpp != 32)) return 0;
    stride = (((UINT32)w * bpp + 31) / 32) * 4;
    for (UINT32 row = 0; row < (UINT32)h; row++) {
        const UINT8 *s = b + off + (UINT64)(up ? (UINT32)h - 1 - row : row) * stride;
        for (UINT32 col = 0; col < (UINT32)w; col++) {
            const UINT8 *p = s + col * (bpp / 8);
            gfx_rect(g, ox + col, oy + row, 1, 1, ((UINT32)p[2] << 16) | ((UINT32)p[1] << 8) | p[0]);
        }
    }
    *out_w = (UINT32)w;
    return (UINT32)h;
}

static void draw_bar(gfx_t *g, UINT32 x, UINT32 y, UINT32 w, UINT32 pct)
{
    UINT32 h = 8, fill;
    if (pct > 100) pct = 100;
    gfx_round_rect(g, x - 2, y - 2, w + 4, h + 4, 6, 0x6E6E6E);
    gfx_round_rect(g, x, y, w, h, 4, 0x000000);
    fill = w * pct / 100;
    if (fill >= 8) gfx_round_rect(g, x, y, fill, h, 4, 0xFFFFFF);
}

void boot_draw(gfx_t *g, UINT32 percent)
{
    const UINT32 bw = 240;
    if (!drawn) {
        UINT32 lw = 0, lh = 0, x, y;
        gfx_rect(g, 0, 0, g->w, g->h, 0x000000);
        if (logo) {
            if (logo_pos) { x = logo_x; y = logo_y; }
            else {
                x = g->w / 2; y = g->h / 2;   /* 크기를 알아야 가운데 정렬 가능: 아래서 보정 */
                lw = (UINT32)r32(logo + 18); lh = (UINT32)(int)r32(logo + 22);
                if ((int)lh < 0) lh = (UINT32)(-(int)lh);
                x = g->w / 2 - lw / 2; y = g->h / 2 - lh / 2;
            }
            lh = draw_bmp(g, logo, x, y, &lw);
            bar_y = y + lh + 40;
        }
        if (!lh) {   /* 로고 없음: 글자로 대체 */
            UINT32 tw = gfx_text_width("RICEOS", 3);
            gfx_text(g, "RICEOS", g->w / 2 - tw / 2, g->h / 2 - 30, 3, 0xFFFFFF, 0);
            bar_y = g->h / 2 + 50;
        }
        if (bar_y + 20 > g->h) bar_y = g->h - 40;
        drawn = 1;
    }
    draw_bar(g, g->w / 2 - bw / 2, bar_y, bw, percent);
}

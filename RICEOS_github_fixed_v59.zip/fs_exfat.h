#ifndef RICEOS_FS_EXFAT_H
#define RICEOS_FS_EXFAT_H
#include "fs_common.h"

/* 0 = exFAT 볼륨으로 인식됨 */
int exfat_probe(const volume_t *v);
/* 루트 디렉터리 항목마다 cb 호출. 0 = 성공 */
int exfat_list_root(const volume_t *v, dir_cb cb, void *ctx);
/* 루트의 파일을 이름으로 읽기 (cap 바이트까지). 0 = 성공 */
int exfat_read_root_file(const volume_t *v, const CHAR16 *name, UINT8 *out, UINT32 cap, UINT32 *len);
#endif

/* 윈도우 7 스타일 화면: 하늘색 배경, 반투명 작업 표시줄, 녹색 시작 버튼,
 * 밝은 제목 표시줄의 창 (UEFI: 명령 프롬프트, 리눅스: 실제 bash 터미널),
 * 시작 메뉴 (Aero의 투명 효과 대신 알파 블렌딩과 그라데이션으로 표현)
 */
#include "ui.h"
#include "device.h"
#include "fs.h"
#include "pci.h"
#include "net.h"
#ifdef RICEOS_LINUX
#include "term.h"
#include <stdio.h>
#include <string.h>
#define WIN_TITLE "RICEOS 터미널"
#else
#define WIN_TITLE "RICEOS 명령 프롬프트"
#endif

#define COLS      96
#define ROWS      200
#define LINE_MAX  60
#define TASKBAR_H 40
#ifdef RICEOS_LINUX
#define MENU_N    7
#else
#define MENU_N    4
#endif
#define MENU_ROW  40

static gfx_t *G;
static void (*wait_key_fn)(void);
static int menu_open, menu_sel, dirty = 1, exit_req;
static int fullscreen;
#ifdef RICEOS_LINUX
#endif
static int ptr_x, ptr_y;     /* 마우스 포인터 위치 */
static int hw_cursor;        /* 1 = 커서는 하드웨어가 그린다 (화면에 그리지 않음) */
static char clk_hm[16] = "--:--", clk_ymd[16] = "----";

static const char *menu_items[MENU_N] = {
#ifdef RICEOS_LINUX
    "터미널 열기", "장치 목록 보기", "파티션 목록 보기", "Chromium 브라우저",
    "배경화면 바꾸기", "효과음 켜기/끄기",
#else
    "터미널 열기", "장치 목록 보기", "파티션 목록 보기",
#endif
    "시스템 종료"
};

/* 배경화면(그라데이션 색 또는 그림)과 효과음 연결: main_linux가 설정한다 */
static UINT32 th_top = 0x2F7BC4, th_bot = 0xC9E8FA, th_gtop = 0x8DC26A, th_gbot = 0x4E8A3A;
static UINT32 *wp_img;
static UINT32 wp_w, wp_h;
static void (*sound_fn)(int kind);
static void snd(int kind) { if (sound_fn) sound_fn(kind); }

#ifndef RICEOS_LINUX
/* ---------- UEFI 전용: 간단한 명령 창 ---------- */
static UINT32 con[ROWS][COLS];
static UINT32 cur_r, cur_c;
static char input[LINE_MAX + 1];
static UINT32 input_len;

static void con_scroll(void)
{
    for (UINT32 r = 1; r < ROWS; r++)
        for (UINT32 c = 0; c < COLS; c++)
            con[r - 1][c] = con[r][c];
    for (UINT32 c = 0; c < COLS; c++) con[ROWS - 1][c] = 0;
}

static void con_newline(void)
{
    cur_c = 0;
    if (cur_r + 1 < ROWS) cur_r++;
    else con_scroll();
}

static void con_putcp(UINT32 cp)
{
    if (cp == '\n') { con_newline(); return; }
    if (cur_c >= COLS) con_newline();
    con[cur_r][cur_c++] = cp;
}

void ui_write(const char *s)
{
    while (*s) {
        UINT32 cp = utf8_next(&s);
        if (cp == 0) break;
        con_putcp(cp);
    }
    dirty = 1;
}

void ui_print(const char *s)
{
    if (cur_c > 0) con_newline();
    ui_write(s);
}

static int streq(const char *a, const char *b)
{
    while (*a && *a == *b) { a++; b++; }
    return *a == *b;
}

static void show_help(void)
{
    ui_print("명령:\n");
    ui_print("  devices  연결된 저장 장치 보기\n");
    ui_print("  volumes  파티션과 파일 시스템 보기\n");
    ui_print("  ls N     N번 파티션의 루트 디렉터리 보기\n");
    ui_print("  hw       PCI 장치 목록\n");
    ui_print("  net      유선 랜 상태와 MAC 주소\n");
    ui_print("  bsod     블루스크린 테스트\n");
    ui_print("  help     도움말 (ESC: 시작 메뉴)\n");
}

static void exec_line(void)
{
    input[input_len] = 0;
    con_newline();
    if (streq(input, "devices")) device_list(ui_print);
    else if (streq(input, "volumes")) fs_volumes(ui_print);
    else if (input[0] == 'l' && input[1] == 's' && input[2] == ' ') {
        UINT32 n = 0, i = 3;
        while (input[i] >= '0' && input[i] <= '9') n = n * 10 + (UINT32)(input[i++] - '0');
        if (n == 0) ui_print("사용법: ls 번호\n");
        else fs_ls(n, ui_print);
    }
    else if (streq(input, "help")) show_help();
    else if (streq(input, "hw")) pci_list(ui_print);
    else if (streq(input, "net")) net_info(ui_print);
    else if (streq(input, "bsod")) ui_bsod(0x00000001);
    else if (input_len > 0) ui_print("알 수 없는 명령입니다.\n");
    input_len = 0;
    dirty = 1;
}

static void run_text(const char *s)
{
    input_len = 0;
    while (*s && input_len < LINE_MAX) input[input_len++] = *s++;
    exec_line();
}

static void run_cmd(const char *s) { run_text(s); }
#else
/* ---------- 리눅스: 실제 셸 터미널 ---------- */
void ui_write(const char *s) { (void)s; dirty = 1; }
void ui_print(const char *s) { term_feed(s); dirty = 1; }

static void run_cmd(const char *s)
{
    term_type(s);
    term_type("\r");
}
#endif

/* ---------- 그리기 ---------- */
static const char *app_name(void)
{
    return WIN_TITLE;
}

static const char *window_title(void)
{
    return app_name();
}

static void draw_wallpaper(void)
{
    if (wp_img && wp_w == G->w && wp_h == G->h) {     /* 그림 배경화면 */
        for (UINT32 y = 0; y < G->h; y++) {
            UINT32 *d = G->px + y * G->stride;
            const UINT32 *s = wp_img + y * wp_w;
            for (UINT32 x = 0; x < wp_w; x++) d[x] = s[x];
        }
        return;
    }
    gfx_vgrad(G, 0, 0, G->w, G->h, th_top, th_bot);
    /* 아래쪽 초원 느낌 */
    gfx_vgrad(G, 0, G->h * 3 / 4, G->w, G->h / 4, th_gtop, th_gbot);
}

/* 창 영역: 평소에는 가운데 창, 전체 화면이면 바탕 전체 (작업 표시줄 제외) */
static void win_rect(UINT32 *wx, UINT32 *wy, UINT32 *ww, UINT32 *wh)
{
    if (fullscreen) {
        *wx = 0; *wy = 0; *ww = G->w; *wh = G->h - TASKBAR_H;
        return;
    }
    *ww = G->w - 80;
    *wh = G->h - TASKBAR_H - 100;
#ifdef RICEOS_LINUX
    if (*ww > TERM_COLS * 8 + 24) *ww = TERM_COLS * 8 + 24;
    if (*wh > TERM_ROWS * 16 + 60) *wh = TERM_ROWS * 16 + 60;
#else
    if (*ww > 900) *ww = 900;
    if (*wh > 560) *wh = 560;
#endif
    *wx = (G->w - *ww) / 2;
    *wy = 40;
}

/* 제목 표시줄 단추: 닫기(X)와 전체 화면(□) */
static void btn_close(UINT32 wx, UINT32 wy, UINT32 ww, UINT32 *x, UINT32 *y)
{ *x = wx + ww - 42; *y = wy + 5; }
static void btn_full(UINT32 wx, UINT32 wy, UINT32 ww, UINT32 *x, UINT32 *y)
{ *x = wx + ww - 82; *y = wy + 5; }

static int in_rect(UINT32 px, UINT32 py, UINT32 x, UINT32 y, UINT32 w, UINT32 h)
{
    return px >= x && px < x + w && py >= y && py < y + h;
}

static void draw_window(void)
{
    UINT32 wx, wy, ww, wh, body_y, body_h, bx, by;
    rect_t clip;

    win_rect(&wx, &wy, &ww, &wh);

    /* 그림자 (전체 화면일 때는 생략) */
    if (!fullscreen) gfx_blend(G, wx + 4, wy + 6, ww, wh, 0x000000, 60);
    /* 바깥 테두리와 제목 표시줄 */
    gfx_round_rect(G, wx, wy, ww, wh, 8, 0xB8862B);
    gfx_vgrad(G, wx + 1, wy + 1, ww - 2, 30, 0xFFF6C4, 0xF2C230);
    gfx_text(G, window_title(), wx + 12, wy + 8, 1, 0x1B2B3B, 0);

    /* 전체 화면 단추 (□) */
    btn_full(wx, wy, ww, &bx, &by);
    gfx_round_rect(G, bx, by, 34, 22, 4, 0x3E7BC9);
    gfx_rect(G, bx + 9, by + 5, 16, 1, 0xFFFFFF);
    gfx_rect(G, bx + 9, by + 16, 16, 1, 0xFFFFFF);
    gfx_rect(G, bx + 9, by + 5, 1, 12, 0xFFFFFF);
    gfx_rect(G, bx + 24, by + 5, 1, 12, 0xFFFFFF);

    /* 닫기 단추 (X): 화면 표시만 */
    btn_close(wx, wy, ww, &bx, &by);
    gfx_round_rect(G, bx, by, 34, 22, 4, 0xC7463D);
    gfx_text(G, "X", bx + 9, by + 3, 1, 0xFFFFFF, 0);

    /* 본문 */
    body_y = wy + 32;
    body_h = wh - 36;
    gfx_rect(G, wx + 5, body_y, ww - 10, body_h, 0xFFFFFF);
    gfx_rect(G, wx + 5, body_y, ww - 10, 1, 0xD9B54A);

    clip.x0 = wx + 6; clip.y0 = body_y + 2;
    clip.x1 = wx + ww - 6; clip.y1 = body_y + body_h - 2;

#ifdef RICEOS_LINUX
    {
        UINT32 vis = (body_h - 8) / 16;
        int vr, vc;
        if (vis > TERM_ROWS) vis = TERM_ROWS;
        for (UINT32 r = 0; r < vis; r++) {
            const term_cell_t *row = term_row((int)r, (int)vis);
            UINT32 y = body_y + 6 + r * 16;
            for (UINT32 c = 0; c < TERM_COLS; c++) {
                UINT32 cx = wx + 12 + c * 8;
                if (!row[c].cp || row[c].wide == 2) continue;
                if (row[c].wide == 1)   /* 한글: 두 칸을 쓰는 16px 글자 */
                    gfx_char(G, row[c].cp, cx, y, 1, term_rgb(row[c].fg), &clip);
                else if (row[c].cp < 0x80)
                    gfx_char_half(G, row[c].cp, cx, y, term_rgb(row[c].fg), &clip);
            }
        }
        if (term_cursor((int)vis, &vr, &vc))
            gfx_rect(G, wx + 12 + (UINT32)vc * 8, body_y + 6 + (UINT32)vr * 16 + 14, 8, 2, 0x101820);
    }
#else
    {
        UINT32 visible = (body_h - 8) / 16;
        UINT32 start = cur_r + 1 > visible ? cur_r + 1 - visible : 0;
        for (UINT32 r = start; r <= cur_r; r++) {
            UINT32 y = body_y + 6 + (r - start) * 16;
            for (UINT32 c = 0; c < COLS; c++) {
                if (con[r][c]) gfx_char(G, con[r][c], wx + 12 + c * 16, y, 1, 0x101820, &clip);
            }
        }
        {
            UINT32 y = body_y + 6 + (cur_r - start) * 16;
            gfx_rect(G, wx + 12 + cur_c * 16, y + 14, 12, 2, 0x101820);
        }
    }
#endif
}

#ifdef RICEOS_LINUX
/* ---------- 트레이(시계 왼쪽 아이콘), 트레이 패널, 빠른 실행 단추 ---------- */
#define TRAY_N     3
#define TRAY_W     34
#define QL_TERM_X  68
#define QL_BROW_X  176
#define QL_W       100
#define PANEL_W    270
#define PANEL_ROW  36
#define PANEL_ROWS 7
static int tray_left;
static int tray_open;
static int rf_wifi = -1, rf_wlan_up, rf_bt = -1, snd_muted;   /* -1 장치 없음, 0 꺼짐, 1 켜짐 */
static void (*action_fn)(const char *cmd);

void ui_set_action(void (*fn)(const char *cmd)) { action_fn = fn; }
void ui_set_radio(int wifi, int wlan_up, int bt)
{
    if (wifi != rf_wifi || wlan_up != rf_wlan_up || bt != rf_bt) dirty = 1;
    rf_wifi = wifi; rf_wlan_up = wlan_up; rf_bt = bt;
}

/* Chromium 열기: X 세션으로 화면을 바꾼다 (끝나면 RICEOS 바탕화면으로 돌아온다) */
static void open_chromium(void)
{
    menu_open = 0;
    tray_open = 0;
    run_cmd("riceos-chrome");
}

static void act(const char *c)
{
    if (action_fn) action_fn(c);
    dirty = 1;
}

/* 무선과 소리 전환: 트레이 패널과 Alt 단축키가 같이 쓴다 */
static void toggle_wifi(void)
{
    if (rf_wifi >= 0) act(rf_wifi ? "riceos radio wifi off" : "riceos radio wifi on");
}
static void toggle_bt(void)
{
    if (rf_bt >= 0) act(rf_bt ? "riceos radio bt off" : "riceos radio bt on");
}
static void toggle_mute(void)
{
    act(snd_muted ? "riceos sound unmute" : "riceos sound mute");
    snd_muted = !snd_muted;
}

static const char *HELP_TEXT =
    "\n[RICEOS 단축키]\n"
    "  Win 또는 ESC        시작 메뉴\n"
    "  Alt+B               Chromium 브라우저\n"
    "  Alt+T               터미널\n"
    "  Alt+W / Alt+K       Wi-Fi / 블루투스 켜기/끄기\n"
    "  Alt+M               소리 음소거/켜기\n"
    "  F11                 전체 화면\n"
    "  F1                  이 도움말\n";

static void draw_ql(const char *label, UINT32 x, UINT32 y, int on)
{
    UINT32 tw = gfx_text_width(label, 1);
    gfx_round_rect(G, x, y + 5, QL_W, 30, 4, on ? 0xFFF3B0 : 0xE8B530);
    gfx_text(G, label, x + (QL_W - tw) / 2, y + 12, 1, 0x2A1F00, 0);
    if (on) gfx_rect(G, x + 10, y + 33, QL_W - 20, 2, 0x2A1F00);   /* 지금 열린 프로그램 표시 */
}

static void draw_tray(UINT32 y)
{
    for (int i = 0; i < TRAY_N; i++) {
        UINT32 x0 = (UINT32)tray_left + (UINT32)i * TRAY_W, y0 = y + 6;
        if (i == 0) {                                   /* Wi-Fi: 신호 막대 4개 */
            unsigned col = rf_wifi == 1 ? 0x2A1F00 : rf_wifi == 0 ? 0xA89A6A : 0xC8BD96;
            for (UINT32 k = 0; k < 4; k++) {
                UINT32 hh = 6 + k * 4;
                gfx_rect(G, x0 + 4 + k * 6, y0 + 24 - hh, 4, hh, col);
            }
            if (rf_wlan_up) gfx_circle(G, x0 + 25, y0 + 4, 3, 0x2E9E3E);   /* 연결됨 */
        } else if (i == 1) {                            /* 블루투스: B */
            unsigned col = rf_bt == 1 ? 0x2A1F00 : rf_bt == 0 ? 0xA89A6A : 0xC8BD96;
            gfx_text(G, "B", x0 + 9, y0 + 6, 1, col, 0);
        } else {                                        /* 소리: 스피커 (음소거면 빨간 점) */
            unsigned col = snd_muted ? 0xA89A6A : 0x2A1F00;
            gfx_rect(G, x0 + 4, y0 + 11, 6, 6, col);
            for (UINT32 c = 0; c < 10; c++) {
                UINT32 half = 3 + c;
                gfx_rect(G, x0 + 10 + c, y0 + 14 - half, 1, 2 * half, col);
            }
            if (snd_muted) gfx_circle(G, x0 + 25, y0 + 4, 3, 0xC7463D);
        }
    }
}

static void panel_origin(UINT32 *px, UINT32 *py)
{
    *px = G->w - PANEL_W - 8;
    *py = G->h - TASKBAR_H - (PANEL_ROWS * PANEL_ROW + 16) - 8;
}

static void panel_row(int i, UINT32 *x, UINT32 *y, UINT32 *w, UINT32 *h)
{
    UINT32 px, py;
    panel_origin(&px, &py);
    *x = px + 8; *y = py + 8 + (UINT32)i * PANEL_ROW; *w = PANEL_W - 16; *h = PANEL_ROW - 6;
}

/* 줄 오른쪽의 상태 단추: st -1 장치 없음(흐림), 0 꺼짐, 1 켜짐 */
static void state_btn(UINT32 x, UINT32 y, UINT32 w, UINT32 h, int st, const char *on_t, const char *off_t)
{
    const char *t = st < 0 ? "없음" : st ? on_t : off_t;
    unsigned bg = st < 0 ? 0xE6E6E6 : st ? 0x3B7DCA : 0xDADADA;
    unsigned fg = st < 0 ? 0x999999 : st ? 0xFFFFFF : 0x222222;
    UINT32 bx = x + w - 84, tw = gfx_text_width(t, 1);
    gfx_round_rect(G, bx, y + 3, 80, h - 6, 4, bg);
    gfx_text(G, t, bx + (80 - tw) / 2, y + (h - 16) / 2, 1, fg, 0);
}

static void draw_panel(void)
{
    static const char *labels[PANEL_ROWS] = {
        "Wi-Fi", "연결 상태", "블루투스", "소리", "Wi-Fi 목록 보기", "블루투스 설정", "브라우저 열기"
    };
    UINT32 px, py, ph = PANEL_ROWS * PANEL_ROW + 16;
    panel_origin(&px, &py);
    gfx_round_rect(G, px - 1, py - 1, PANEL_W + 2, ph + 2, 7, 0x8A6A1E);
    gfx_round_rect(G, px, py, PANEL_W, ph, 6, 0xFFF8DC);
    for (int i = 0; i < PANEL_ROWS; i++) {
        UINT32 x, y, w, h;
        panel_row(i, &x, &y, &w, &h);
        if (i >= 4) {                                   /* 전체 너비 단추 */
            gfx_round_rect(G, x, y, w, h, 4, 0xDCE8F7);
            gfx_text(G, labels[i], x + 12, y + (h - 16) / 2, 1, 0x1B2B3B, 0);
            continue;
        }
        gfx_text(G, labels[i], x + 8, y + (h - 16) / 2, 1, 0x1B2B3B, 0);
        if (i == 0) state_btn(x, y, w, h, rf_wifi, "켜짐", "꺼짐");
        else if (i == 1) {
            const char *t = rf_wlan_up ? "연결됨" : "끊김";
            UINT32 tw = gfx_text_width(t, 1);
            gfx_text(G, t, x + w - tw - 8, y + (h - 16) / 2, 1, rf_wlan_up ? 0x2E7D32 : 0x777777, 0);
        }
        else if (i == 2) state_btn(x, y, w, h, rf_bt, "켜짐", "꺼짐");
        else if (i == 3) state_btn(x, y, w, h, snd_muted ? 0 : 1, "켜짐", "음소거");
    }
}

/* 패널 안의 줄 번호: -2 패널 밖, -1 패널 안의 빈 곳 */
static int panel_row_at(UINT32 mx, UINT32 my)
{
    UINT32 px, py, rel;
    panel_origin(&px, &py);
    if (!in_rect(mx, my, px, py, PANEL_W, PANEL_ROWS * PANEL_ROW + 16)) return -2;
    if (my < py + 8) return -1;
    rel = my - py - 8;
    if (rel / PANEL_ROW >= PANEL_ROWS || rel % PANEL_ROW >= PANEL_ROW - 6) return -1;
    return (int)(rel / PANEL_ROW);
}

static void panel_click(int row)
{
    switch (row) {
    case 0: toggle_wifi(); break;
    case 2: toggle_bt(); break;
    case 3: toggle_mute(); break;
    case 4: tray_open = 0; run_cmd("wifi list"); break;
    case 5: tray_open = 0; run_cmd("bluetoothctl"); break;
    case 6: open_chromium(); break;
    }
}
#endif

static void draw_taskbar(void)
{
    UINT32 y = G->h - TASKBAR_H;
    UINT32 tw, cx;

    gfx_blend(G, 0, y, G->w, TASKBAR_H, 0xF5C842, 225);
    gfx_rect(G, 0, y, G->w, 1, 0xFFE58A);

    /* 시작 버튼: 녹색 광택 원 */
    gfx_circle(G, 22, y + 20, 17, 0x1F5C2A);
    gfx_circle(G, 22, y + 20, 15, 0x3E9A4B);
    gfx_circle(G, 22, y + 20, 12, 0x6CC77F);
    gfx_circle(G, 22, y + 19, 7, 0xA5E8B6);

#ifdef RICEOS_LINUX
    /* 빠른 실행 단추: 터미널, Chromium */
    draw_ql("터미널", QL_TERM_X, y, 1);
    draw_ql("Chromium", QL_BROW_X, y, 0);
#else
    /* 실행 중인 창 단추 */
    gfx_round_rect(G, 52, y + 5, 170, 30, 4, 0xE8B530);
    gfx_text(G, app_name(), 64, y + 12, 1, 0x2A1F00, 0);
#endif

    /* 시계 */
    tw = gfx_text_width(clk_hm, 1);
    if (gfx_text_width(clk_ymd, 1) > tw) tw = gfx_text_width(clk_ymd, 1);
    cx = G->w - tw - 14;
    gfx_text(G, clk_hm, cx, y + 3, 1, 0x2A1F00, 0);
    gfx_text(G, clk_ymd, cx, y + 20, 1, 0x4A3A00, 0);

#ifdef RICEOS_LINUX
    tray_left = (int)cx - 12 - TRAY_N * TRAY_W;
    draw_tray(y);
#endif
}

static void draw_menu(void)
{
    UINT32 mw = 280, mh = MENU_N * MENU_ROW + 16;
    UINT32 mx = 6, my = G->h - TASKBAR_H - mh - 6;

    gfx_round_rect(G, mx - 1, my - 1, mw + 2, mh + 2, 7, 0x5C82AA);
    gfx_round_rect(G, mx, my, mw, mh, 6, 0xEEF5FC);
    for (UINT32 i = 0; i < MENU_N; i++) {
        UINT32 iy = my + 8 + i * MENU_ROW;
        if ((int)i == menu_sel) {
            gfx_round_rect(G, mx + 6, iy, mw - 12, MENU_ROW - 6, 4, 0x3B7DCA);
            gfx_text(G, menu_items[i], mx + 18, iy + 10, 1, 0xFFFFFF, 0);
        } else {
            gfx_text(G, menu_items[i], mx + 18, iy + 10, 1, 0x1B2B3B, 0);
        }
    }
}

static int menu_activate(void);

/* 커서 모양: 화살표(기본), I 모양(글 입력 영역), 손(누를 수 있는 곳) */
enum { CUR_ARROW, CUR_IBEAM, CUR_HAND };

static int cursor_kind(void)
{
    UINT32 wx, wy, ww, wh, bx, by;
    UINT32 px = (UINT32)ptr_x, py = (UINT32)ptr_y;
    UINT32 sy = G->h - TASKBAR_H;

    if (py >= sy && px < 60) return CUR_HAND;                 /* 시작 단추 */
#ifdef RICEOS_LINUX
    if (py >= sy && (((int)px >= QL_TERM_X && (int)px < QL_BROW_X + QL_W) || (int)px >= tray_left)) return CUR_HAND;
    if (tray_open && panel_row_at(px, py) >= 0) return CUR_HAND;
#endif
    if (menu_open) {
        UINT32 mw = 280, mh = MENU_N * MENU_ROW + 16;
        UINT32 mx = 6, my = G->h - TASKBAR_H - mh - 6;
        if (in_rect(px, py, mx, my, mw, mh)) return CUR_HAND;
        return CUR_ARROW;
    }
    win_rect(&wx, &wy, &ww, &wh);
    btn_full(wx, wy, ww, &bx, &by);
    if (in_rect(px, py, bx, by, 34, 22)) return CUR_HAND;
    btn_close(wx, wy, ww, &bx, &by);
    if (in_rect(px, py, bx, by, 34, 22)) return CUR_HAND;
    /* 본문(글 영역) 위: I 모양 */
    if (in_rect(px, py, wx + 6, wy + 34, ww - 12, wh - 40)) return CUR_IBEAM;
    return CUR_ARROW;
}

static void draw_arrow(UINT32 x, UINT32 y)
{
    for (UINT32 r = 0; r < 14; r++) {
        UINT32 w = r < 8 ? r + 1 : 14 - r;
        if (x + w < G->w && y + r < G->h)
            gfx_rect(G, x, y + r, w, 1, 0x000000);
    }
}

/* I 모양: 위아래 가로 획 + 가운데 세로 획 (가운데 맞춤, 높이 18) */
static void draw_ibeam(UINT32 x, UINT32 y)
{
    if (x < 3 || y + 18 >= G->h || x + 4 >= G->w) return;
    gfx_rect(G, x - 3, y, 7, 1, 0x000000);
    gfx_rect(G, x - 3, y + 17, 7, 1, 0x000000);
    gfx_rect(G, x, y + 1, 1, 16, 0x000000);
}

/* 손 모양 (가리키는 손, 약 12x16): 검지, 나머지 손가락, 손바닥, 엄지 */
static void draw_hand(UINT32 x, UINT32 y)
{
    if (x + 12 >= G->w || y + 16 >= G->h) return;
    gfx_rect(G, x + 4, y, 3, 9, 0x000000);               /* 검지 */
    gfx_rect(G, x + 7, y + 5, 2, 4, 0x000000);           /* 중지 */
    gfx_rect(G, x + 9, y + 6, 2, 4, 0x000000);           /* 약지 */
    gfx_rect(G, x + 2, y + 8, 9, 7, 0x000000);           /* 손바닥 */
    gfx_rect(G, x, y + 9, 2, 4, 0x000000);               /* 엄지 */
    gfx_rect(G, x + 2, y + 15, 8, 1, 0x000000);
}

static void draw_pointer(void)
{
    UINT32 x = (UINT32)ptr_x, y = (UINT32)ptr_y;
    switch (cursor_kind()) {
    case CUR_IBEAM: draw_ibeam(x, y); break;
    case CUR_HAND:  draw_hand(x, y); break;
    default:        draw_arrow(x, y); break;
    }
}

#ifdef RICEOS_LINUX
/* ---------- 로그인 화면 (/etc/riceos/login 이 있을 때만 켜진다) ---------- */
/* 로그인 아이디는 Admin 으로 고정. 파일이 없으면 처음 설정 화면에서 비밀번호를 정한다. */
static int login_on, login_setup_mode, login_field, login_fails;
static int (*login_check_fn)(const char *pw);
static int (*login_setup_fn)(const char *pw);
static char login_pw[2][65];
static int login_len[2];
static const char *login_msg = "";

/* check: 로그인 모드의 비밀번호 확인, setup: 처음 설정 모드의 저장 함수. 둘 다 NULL이면 끈다 */
void ui_set_login(int (*check)(const char *pw), int (*setup)(const char *pw))
{
    login_check_fn = check;
    login_setup_fn = setup;
    login_setup_mode = setup != 0;
    login_on = check != 0 || setup != 0;
    login_fails = 0;
    login_msg = "";
    login_field = 0;
    login_len[0] = login_len[1] = 0;
    login_pw[0][0] = login_pw[1][0] = 0;
    dirty = 1;
}

static void login_clear_field(int f)
{
    login_len[f] = 0;
    login_pw[f][0] = 0;
}

static void login_submit(void)
{
    if (login_setup_mode) {
        if (login_field == 0) {                       /* 첫 칸 Enter: 확인 칸으로 */
            if (login_len[0] == 0) login_msg = "비밀번호를 입력하세요";
            else { login_field = 1; login_msg = ""; }
        } else if (login_len[1] == 0) {
            login_msg = "확인 칸에 한 번 더 입력하세요";
        } else if (strcmp(login_pw[0], login_pw[1]) != 0) {
            login_clear_field(1);
            login_msg = "두 비밀번호가 서로 다릅니다";
        } else if (login_setup_fn && login_setup_fn(login_pw[0])) {
            login_on = 0;                             /* 저장 완료: 바로 바탕화면 */
            snd(UI_SND_CLICK);
        } else {
            login_msg = "설정 파일을 쓸 수 없습니다 (root 권한으로 실행해야 합니다)";
            snd(UI_SND_ERROR);
        }
    } else {
        if (login_check_fn && login_check_fn(login_pw[0])) {
            login_on = 0;
            login_fails = 0;
            login_msg = "";
            snd(UI_SND_CLICK);
        } else {
            login_fails++;
            login_msg = "비밀번호가 맞지 않습니다";
            snd(UI_SND_ERROR);
        }
        login_clear_field(0);
    }
    dirty = 1;
}

static void draw_field(UINT32 bx, UINT32 by, UINT32 bw, UINT32 bh, int f, const char *hint, int focus)
{
    gfx_round_rect(G, bx, by, bw, bh, 6, focus ? 0x3E7BC9 : 0x8A9BB0);
    gfx_rect(G, bx + 2, by + 2, bw - 4, bh - 4, 0xFFFFFF);
    if (!login_len[f]) gfx_text(G, hint, bx + 12, by + 10, 1, 0x9AA5B1, 0);
    for (int i = 0; i < login_len[f] && i < 24; i++)      /* 글자는 * 로 가린다 */
        gfx_text(G, "*", bx + 12 + (UINT32)i * 10, by + 10, 1, 0x1B2B3B, 0);
}

static void draw_login(void)
{
    UINT32 cw = 360, ch = 350;
    UINT32 cx = (G->w - cw) / 2, cy = (G->h - ch) / 2;
    UINT32 bx = cx + 40, bw = cw - 80, bh = 36;
    UINT32 by1 = cy + 170, by2 = cy + 222;
    char info[80];

    gfx_blend(G, 0, 0, G->w, G->h, 0x0B1B33, 120);          /* 바탕화면을 어둡게 */
    gfx_blend(G, cx + 4, cy + 6, cw, ch, 0x000000, 60);
    gfx_round_rect(G, cx, cy, cw, ch, 10, 0xB8862B);
    gfx_vgrad(G, cx + 1, cy + 1, cw - 2, 46, 0xFFF6C4, 0xF2C230);
    gfx_text(G, login_setup_mode ? "RICEOS 처음 설정" : "RICEOS 로그인", cx + 16, cy + 16, 1, 0x1B2B3B, 0);

    gfx_circle(G, cx + cw / 2, cy + 100, 34, 0x3E7BC9);      /* 사용자 아이콘 */
    gfx_circle(G, cx + cw / 2, cy + 100, 30, 0x6CC77F);
    gfx_text(G, "Admin", cx + cw / 2 - 20, cy + 144, 1, 0x1B2B3B, 0);

    if (login_setup_mode) {
        draw_field(bx, by1, bw, bh, 0, "새 비밀번호", login_field == 0);
        draw_field(bx, by2, bw, bh, 1, "비밀번호 확인", login_field == 1);
        gfx_text(G, "Enter: 다음 / 저장", bx, by2 + bh + 10, 1, 0x5A6B7C, 0);
        gfx_text(G, "Tab: 칸 이동", bx, by2 + bh + 28, 1, 0x5A6B7C, 0);
    } else {
        draw_field(bx, by1, bw, bh, 0, "비밀번호", 1);
        gfx_text(G, "Enter: 로그인", bx, by1 + bh + 10, 1, 0x5A6B7C, 0);
        gfx_text(G, "Esc: 지우기", bx, by1 + bh + 28, 1, 0x5A6B7C, 0);
    }
    if (login_msg[0]) gfx_text(G, login_msg, bx, cy + 314, 1, 0xC7463D, 0);
    else if (login_fails) {
        snprintf(info, sizeof info, "%s (%d회 실패)", "비밀번호가 맞지 않습니다", login_fails);
        gfx_text(G, info, bx, cy + 314, 1, 0xC7463D, 0);
    }
}
#endif

void ui_render(void)
{
#ifdef RICEOS_LINUX
    if (login_on) {                       /* 로그인 전에는 바탕화면과 작업 표시줄을 그리지 않는다 */
        draw_wallpaper();
        draw_login();
        if (!hw_cursor) draw_pointer();
        dirty = 0;
        return;
    }
#endif
    draw_wallpaper();
    draw_window();
    draw_taskbar();
    if (menu_open) draw_menu();
#ifdef RICEOS_LINUX
    if (tray_open) draw_panel();
#endif
    if (!hw_cursor) draw_pointer();
    dirty = 0;
}

/* ---------- 마우스 ---------- */
void ui_pointer_move(int dx, int dy)
{
    int x = ptr_x + dx, y = ptr_y + dy;
    if (x < 0) x = 0;
    if (y < 0) y = 0;
    if (x > (int)G->w - 1) x = (int)G->w - 1;
    if (y > (int)G->h - 1) y = (int)G->h - 1;
    ptr_x = x; ptr_y = y;
    if (!hw_cursor) dirty = 1;
}

/* 절대 좌표 장치(태블릿, 가상 머신의 포인터): 장치 범위를 화면 크기로 옮긴다 */
void ui_pointer_abs(int ax, int ay, int minx, int maxx, int miny, int maxy)
{
    long x = ax, y = ay;
    if (maxx > minx) x = (long)(ax - minx) * (long)G->w / (maxx - minx + 1);
    if (maxy > miny) y = (long)(ay - miny) * (long)G->h / (maxy - miny + 1);
    if (x < 0) x = 0;
    if (y < 0) y = 0;
    if (x > (long)G->w - 1) x = (long)G->w - 1;
    if (y > (long)G->h - 1) y = (long)G->h - 1;
    ptr_x = (int)x; ptr_y = (int)y;
    if (!hw_cursor) dirty = 1;
}

/* 포인터 위치에서 왼쪽 클릭 처리. 종료 요청이면 1 */
int ui_click(void)
{
#ifdef RICEOS_LINUX
    if (login_on) { dirty = 1; return 0; }   /* 로그인 화면에서는 마우스 동작 없음 */
#endif
    UINT32 wx, wy, ww, wh, bx, by;
    UINT32 px = (UINT32)ptr_x, py = (UINT32)ptr_y;
    UINT32 sy = G->h - TASKBAR_H;

    dirty = 1;
    /* 시작 단추: 작업 표시줄 왼쪽 */
    if (py >= sy && px < 60) {
        menu_open = !menu_open;
        snd(menu_open ? UI_SND_MENU : UI_SND_CLICK);
        return 0;
    }

#ifdef RICEOS_LINUX
    /* 트레이 패널: 패널 안이면 그 줄을 실행, 바깥이면 닫는다 */
    if (tray_open) {
        int row = panel_row_at(px, py);
        if (row >= 0) { panel_click(row); return 0; }
        if (row == -1) return 0;
        tray_open = 0;
    }
    /* 작업 표시줄: 트레이 아이콘, 빠른 실행 단추 */
    if (py >= sy) {
        if ((int)px >= tray_left && (int)px < tray_left + TRAY_N * TRAY_W) {
            tray_open = !tray_open; menu_open = 0; snd(UI_SND_CLICK); return 0;
        }
        if ((int)px >= QL_TERM_X && (int)px < QL_TERM_X + QL_W) { menu_open = 0; return 0; }
        if ((int)px >= QL_BROW_X && (int)px < QL_BROW_X + QL_W) { open_chromium(); return 0; }
    }
#endif

    if (menu_open) {
        UINT32 mw = 280, mh = MENU_N * MENU_ROW + 16;
        UINT32 mx = 6, my = G->h - TASKBAR_H - mh - 6;
        if (in_rect(px, py, mx, my, mw, mh)) {
            for (UINT32 i = 0; i < MENU_N; i++) {
                UINT32 iy = my + 8 + i * MENU_ROW;
                if (in_rect(px, py, mx + 6, iy, mw - 12, MENU_ROW - 6)) {
                    menu_sel = (int)i;
                    menu_open = 0;
                    return menu_activate();
                }
            }
            return 0;
        }
        menu_open = 0;          /* 메뉴 바깥을 누르면 닫는다 */
        return 0;
    }

    win_rect(&wx, &wy, &ww, &wh);
    btn_full(wx, wy, ww, &bx, &by);
    if (in_rect(px, py, bx, by, 34, 22)) { fullscreen = !fullscreen; snd(UI_SND_CLICK); return 0; }
    /* 닫기(X) 단추는 바탕화면을 끄지 않는다: 종료는 시작 메뉴에서 */
    return 0;
}

/* ---------- 입력과 상태 ---------- */
void ui_init(gfx_t *g, void (*wait_key)(void))
{
    G = g;
    wait_key_fn = wait_key;
#ifdef RICEOS_LINUX
    term_init();
    term_feed("RICEOS 터미널 - 리눅스 bash 셸입니다. 명령 목록은 'riceos' 입력, 시작 메뉴는 ESC 또는 왼쪽 아래 버튼.\r\n");
    term_start();
#else
    ui_print("RICEOS 명령 프롬프트\n");
    show_help();
    ui_print("\n> ");
#endif
    dirty = 1;
}

void ui_set_clock(const char *hm, const char *ymd)
{
    UINT32 i;
    for (i = 0; i < 15 && hm[i]; i++) clk_hm[i] = hm[i];
    clk_hm[i] = 0;
    for (i = 0; i < 15 && ymd[i]; i++) clk_ymd[i] = ymd[i];
    clk_ymd[i] = 0;
    dirty = 1;
}

static int menu_activate(void)
{
    snd(UI_SND_CLICK);
    menu_open = 0;
#ifdef RICEOS_LINUX
    switch (menu_sel) {
    case 0: break;
    case 1: run_cmd("devices"); break;
    case 2: run_cmd("volumes"); break;
    case 3: open_chromium(); break;
    case 4: run_cmd("riceos wallpaper next"); break;
    case 5: run_cmd("riceos sfx toggle"); break;
    case 6: exit_req = 1; break;
    }
#else
    switch (menu_sel) {
    case 0: break;
    case 1: run_cmd("devices"); break;
    case 2: run_cmd("volumes"); break;
    case 3: exit_req = 1; break;
    }
#endif
    return exit_req;
}

int ui_handle_key(UINT16 scan, UINT16 uni)
{
#ifdef RICEOS_LINUX
    if (login_on) {                          /* 로그인/설정 화면: 키는 입력 칸으로 간다 */
        int f = login_setup_mode ? login_field : 0;
        if (uni == '\r') login_submit();
        else if (uni == 0x09 && login_setup_mode) login_field = !login_field;   /* Tab: 칸 바꾸기 */
        else if (uni == 0x08) { if (login_len[f]) { login_len[f]--; login_pw[f][login_len[f]] = 0; } }
        else if (scan == 0x17) login_clear_field(f);                              /* ESC: 지우기 */
        else if (uni >= 0x20 && uni < 0x7F && login_len[f] < 64) {
            login_pw[f][login_len[f]++] = (char)uni;
            login_pw[f][login_len[f]] = 0;
        }
        dirty = 1;
        return 0;
    }
    /* ESC: 시작 메뉴. 전체 화면 프로그램(vi 등)이 켜져 있으면 ESC는 그 프로그램으로 간다 */
    if ((scan == 0x17 && !term_alt()) || scan == 0x1A) {     /* ESC 또는 Win 키 */
        menu_open = !menu_open;
        snd(menu_open ? UI_SND_MENU : UI_SND_CLICK);
        dirty = 1;
        return 0;
    }
    if (menu_open) {
        if (scan == 0x01)      menu_sel = (menu_sel + MENU_N - 1) % MENU_N;
        else if (scan == 0x02) menu_sel = (menu_sel + 1) % MENU_N;
        else if (uni == '\r')  return menu_activate();
        dirty = 1;
        return exit_req;
    }
    if (scan == 0x18) { fullscreen = !fullscreen; dirty = 1; return 0; }   /* F11 */
    if (scan == 0x1B) { open_chromium(); dirty = 1; return 0; }                                              /* Alt+B: Chromium */
    if (scan == 0x1C) { menu_open = 0; tray_open = 0; dirty = 1; return 0; }                 /* Alt+T */
    if (scan == 0x20) { toggle_wifi(); dirty = 1; return 0; }                                                 /* Alt+W */
    if (scan == 0x21) { toggle_bt(); dirty = 1; return 0; }                                                   /* Alt+K */
    if (scan == 0x22) { toggle_mute(); dirty = 1; return 0; }                                                 /* Alt+M */
    if (scan == 0x24) { menu_open = 0; ui_print(HELP_TEXT); dirty = 1; return 0; }                            /* F1 */
    /* PgUp/PgDn: 기록 보기 (전체 화면 프로그램이 아닐 때) */
    if ((scan == 0x15 || scan == 0x16) && !term_alt()) {
        term_scroll_view(scan == 0x15 ? 10 : -10);
        dirty = 1;
        return 0;
    }
    term_key(scan, uni);
    dirty = 1;
    return 0;
#else
    if (scan == 0x17) {                       /* ESC: 시작 메뉴 열기/닫기 */
        menu_open = !menu_open;
        snd(menu_open ? UI_SND_MENU : UI_SND_CLICK);
        dirty = 1;
        return 0;
    }
    if (menu_open) {
        if (scan == 0x01)      menu_sel = (menu_sel + MENU_N - 1) % MENU_N;   /* 위 */
        else if (scan == 0x02) menu_sel = (menu_sel + 1) % MENU_N;            /* 아래 */
        else if (uni == '\r')  return menu_activate();
        dirty = 1;
        return exit_req;
    }
    if (uni == '\r') {
        exec_line();
        ui_print("> ");
    } else if (uni == 0x08) {
        if (input_len > 0) {
            input_len--;
            if (cur_c > 0) { cur_c--; con[cur_r][cur_c] = 0; }
        }
    } else if (uni >= 0x20 && uni <= 0x7E && input_len < LINE_MAX) {
        input[input_len++] = (char)uni;
        con_putcp(uni);
    }
    dirty = 1;
    return 0;
#endif
}

void ui_bsod(UINT32 stop_code)
{
    static const char hex[] = "0123456789ABCDEF";
    char code[11] = "0x00000000";
    for (int i = 0; i < 8; i++) code[9 - i] = hex[(stop_code >> (i * 4)) & 0xF];

    gfx_rect(G, 0, 0, G->w, G->h, 0x0078D7);
    gfx_text(G, ":( RICEOS에 문제가 발생했습니다.", 80, 80, 2, 0xFFFFFF, 0);
    gfx_text(G, "컴퓨터를 다시 시작해 주세요.", 80, 150, 1, 0xFFFFFF, 0);
    gfx_text(G, "정지 코드:", 80, 200, 1, 0xFFFFFF, 0);
    gfx_text(G, code, 200, 200, 1, 0xFFFFFF, 0);
    gfx_text(G, "아무 키나 누르면 계속합니다.", 80, 260, 1, 0xFFFFFF, 0);
    if (wait_key_fn) wait_key_fn();
    dirty = 1;
}

void ui_set_theme(UINT32 top, UINT32 bot, UINT32 gtop, UINT32 gbot)
{
    th_top = top; th_bot = bot; th_gtop = gtop; th_gbot = gbot;
    dirty = 1;
}

UINT32 *ui_set_wallpaper(UINT32 *px, UINT32 w, UINT32 h)
{
    UINT32 *old = wp_img;
    wp_img = px; wp_w = w; wp_h = h;
    dirty = 1;
    return old;
}

void ui_set_sound(void (*fn)(int kind)) { sound_fn = fn; }

int ui_dirty(void) { return dirty; }
void ui_mark_dirty(void) { dirty = 1; }
void ui_clear_dirty(void) { dirty = 0; }

/* ---------- 하드웨어 커서 지원 ---------- */
void ui_set_hw_cursor(int on) { hw_cursor = on; dirty = 1; }
int ui_cursor_kind(void) { return cursor_kind(); }
void ui_pointer_pos(int *x, int *y) { *x = ptr_x; *y = ptr_y; }

/* 커서 모양을 64x64 ARGB 그림으로 만든다. 그리지 않은 곳은 투명, 포인터 끝은 (hx,hy). */
void ui_cursor_image(UINT32 *out, int kind, int *hx, int *hy)
{
    gfx_t cg;
    gfx_t *saved = G;
    for (int i = 0; i < 64 * 64; i++) out[i] = 0x80000000u;   /* 임시 표시: 아직 안 그린 픽셀 */
    cg.px = out; cg.stride = 64; cg.w = 64; cg.h = 64; cg.bgr = saved ? saved->bgr : 1;
    G = &cg;
    if (kind == CUR_IBEAM)      { draw_ibeam(4, 0); *hx = 4; *hy = 9; }
    else if (kind == CUR_HAND)  { draw_hand(4, 0);  *hx = 5; *hy = 0; }
    else                        { draw_arrow(0, 0); *hx = 0; *hy = 0; }
    G = saved;
    for (int i = 0; i < 64 * 64; i++)
        out[i] = (out[i] == 0x80000000u) ? 0u : (out[i] | 0xFF000000u);
}

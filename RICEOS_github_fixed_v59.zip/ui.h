/* RICEOS 윈도우 7 스타일 바탕화면 */
#ifndef RICEOS_UI_H
#define RICEOS_UI_H
#include "gfx.h"

void ui_init(gfx_t *g, void (*wait_key)(void));
void ui_set_clock(const char *hm, const char *ymd);
/* 명령 창에 출력 (device/fs 모듈의 out 콜백으로도 사용) */
void ui_print(const char *s);
/* 줄 맞춤 없이 출력 (외부 프로그램 출력용) */
void ui_write(const char *s);
/* 키 입력 처리. 1을 돌려주면 종료 요청 */
int  ui_handle_key(UINT16 scan, UINT16 uni);
void ui_render(void);
void ui_bsod(UINT32 stop_code);
int  ui_dirty(void);
void ui_mark_dirty(void);
/* 마우스: 상대 이동, 절대 좌표(태블릿), 왼쪽 클릭 (종료 요청이면 1) */
void ui_pointer_move(int dx, int dy);
void ui_pointer_abs(int ax, int ay, int minx, int maxx, int miny, int maxy);
int  ui_click(void);
void ui_clear_dirty(void);

/* 리눅스 트레이: 무선 상태(-1 없음, 0 꺼짐, 1 켜짐)와 설정 명령 실행 함수 */
void ui_set_radio(int wifi, int wlan_up, int bt);
void ui_set_action(void (*fn)(const char *cmd));

/* 배경화면: 그라데이션 테마 4색(하늘 위/아래, 초원 위/아래), 또는 그림 (화면 크기와 같아야 함).
 * ui_set_wallpaper는 이전 그림을 돌려준다 (호출한 쪽이 해제). NULL이면 그라데이션만 쓴다 */
void ui_set_theme(UINT32 top, UINT32 bot, UINT32 gtop, UINT32 gbot);
UINT32 *ui_set_wallpaper(UINT32 *px, UINT32 w, UINT32 h);

/* 효과음 요청: 화면이 kind에 맞는 소리를 내라고 알려 준다 (실제 재생은 호출한 쪽) */
enum { UI_SND_CLICK = 1, UI_SND_MENU, UI_SND_ERROR };
void ui_set_sound(void (*fn)(int kind));

#ifdef RICEOS_LINUX
/* 로그인 화면: check(비밀번호)가 1을 돌려주면 통과. setup(비밀번호)은 처음 설정 때 저장한다.
 * 둘 다 NULL이면 화면을 끈다 */
void ui_set_login(int (*check)(const char *pw), int (*setup)(const char *pw));
#endif

#endif
/* 하드웨어 커서 */
void ui_set_hw_cursor(int on);
int ui_cursor_kind(void);
void ui_pointer_pos(int *x, int *y);
void ui_cursor_image(UINT32 *out, int kind, int *hx, int *hy);

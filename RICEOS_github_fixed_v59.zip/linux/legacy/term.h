/* RICEOS 터미널: 리눅스 셸(bash)을 가상 터미널(pty)에 연결하는 화면 모듈 */
#ifndef RICEOS_TERM_H
#define RICEOS_TERM_H
#include <stdint.h>

#define TERM_COLS 96   /* 한 줄 칸 수 (영문 한 칸 = 8px, 한글 두 칸 = 16px) */
#define TERM_ROWS 40   /* 화면 줄 수 */

typedef struct {
    uint32_t cp;      /* 글자 (0 = 빈 칸) */
    uint8_t  fg;      /* 색 번호 0~15, 16 = 기본 */
    uint8_t  wide;    /* 0 = 한 칸, 1 = 두 칸 글자의 앞, 2 = 뒤 칸 */
} term_cell_t;

void term_init(void);
/* 셸 시작 (이미 떠 있으면 그대로). 성공 0 */
int  term_start(void);
void term_stop(void);
/* 셸 출력을 읽어 화면에 반영. 화면이 바뀌었으면 1 */
int  term_poll(void);
/* 키 입력을 셸로 보낸다. scan: 특수 키 (0이면 아님), uni: 글자 또는 Ctrl 코드 */
void term_key(unsigned scan, unsigned uni);
/* 문자열을 셸 입력으로 보낸다 */
void term_type(const char *s);
/* 문자열을 화면에 직접 쓴다 (안내 문구) */
void term_feed(const char *s);
int  term_alt(void);
/* 기록 보기: delta 줄만큼 위(+)/아래(-)로 */
void term_scroll_view(int delta);
/* 보이는 nvis 줄 중 vrow 번째 줄의 칸들 */
const term_cell_t *term_row(int vrow, int nvis);
/* 커서 위치 (보이는 줄 기준). 보이면 1 */
int  term_cursor(int nvis, int *vr, int *vc);
uint32_t term_rgb(int fg);

#endif

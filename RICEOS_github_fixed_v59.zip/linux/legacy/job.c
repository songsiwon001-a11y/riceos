/* RICEOS 리눅스: 외부 프로그램을 비동기로 실행한다.
 * 출력은 실시간으로 명령 창에 나오고, 입력 줄은 프로그램 표준 입력으로 간다.
 * Ctrl+C로 중단하며, 한 번에 한 개만 실행한다.
 */
#define _GNU_SOURCE
#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <unistd.h>
#include <fcntl.h>
#include <signal.h>
#include <stdlib.h>
#include <sys/wait.h>
#include "job.h"

/* pipe + FD_CLOEXEC (pipe2 는 빌드 옵션에 따라 안 보일 수 있다) */
static int cloexec_pipe(int fd[2])
{
    if (pipe(fd) < 0) return -1;
    fcntl(fd[0], F_SETFD, FD_CLOEXEC);
    fcntl(fd[1], F_SETFD, FD_CLOEXEC);
    return 0;
}

static pid_t jpid = -1;
static int jin = -1, jout = -1;
static int kills, esc_state, ncarry, last_nl = 1;
static int inherit;

void job_set_inherit(int on) { inherit = on; }
static unsigned char carry[4];

int job_active(void) { return jpid > 0; }

/* 끝에서 잘린 UTF-8 글자의 바이트 수 (다음 읽기 때까지 보류) */
static int utf8_tail(const unsigned char *b, int n)
{
    for (int back = 1; back <= 3 && back <= n; back++) {
        unsigned char c = b[n - back];
        int need;
        if ((c & 0xC0) == 0x80) continue;
        need = c >= 0xF0 ? 4 : c >= 0xE0 ? 3 : c >= 0xC0 ? 2 : 1;
        return need > back ? back : 0;
    }
    return 0;
}

/* 화면용 정리: 탭은 공백 4칸, CR과 ANSI 색 코드는 버리고 제어 문자는 뺀다 */
static void sanitize(job_out_fn out, const unsigned char *b, int n)
{
    char o[4200];
    int k = 0;
    for (int i = 0; i < n; i++) {
        unsigned char c = b[i];
        if (esc_state == 1) { esc_state = c == '[' ? 2 : 0; continue; }
        if (esc_state == 2) { if (c >= 0x40 && c <= 0x7E) esc_state = 0; continue; }
        if (c == 0x1B) { esc_state = 1; continue; }
        if (c == '\t') { for (int t = 0; t < 4; t++) o[k++] = ' '; }
        else if (c == '\n' || (c >= 0x20 && c != 0x7F)) o[k++] = (char)c;
    }
    if (k) {
        o[k] = 0;
        out(o);
        last_nl = o[k - 1] == '\n';
    }
}

static void drain(job_out_fn out)
{
    unsigned char buf[1100];
    for (int round = 0; round < 8 && jout >= 0; round++) {
        ssize_t k;
        int total, keep;
        memcpy(buf, carry, ncarry);
        k = read(jout, buf + ncarry, sizeof buf - ncarry);
        if (k == 0) { close(jout); jout = -1; break; }   /* 끝 (EOF) */
        if (k < 0) break;                                 /* 아직 데이터 없음 */
        total = ncarry + (int)k;
        keep = utf8_tail(buf, total);
        sanitize(out, buf, total - keep);
        memcpy(carry, buf + total - keep, keep);
        ncarry = keep;
    }
}

void job_poll(job_out_fn out)
{
    int st = 0;
    pid_t r;
    char msg[96];
    if (jpid <= 0) return;
    /* 종료를 먼저 확인해야 그 뒤에 쓰인 마지막 출력을 빠뜨리지 않는다 */
    r = waitpid(jpid, &st, WNOHANG);
    drain(out);
    if (r == jpid || r < 0) {
        if (ncarry) { sanitize(out, carry, ncarry); ncarry = 0; }
        if (!last_nl) out("\n");
        if (r == jpid && WIFSIGNALED(st))
            snprintf(msg, sizeof msg, "[시그널 %d로 종료됨]\n", WTERMSIG(st));
        else if (r == jpid)
            snprintf(msg, sizeof msg, "[종료 코드 %d]\n", WEXITSTATUS(st));
        else
            snprintf(msg, sizeof msg, "[종료됨]\n");
        out(msg);
        if (jout >= 0) { close(jout); jout = -1; }
        if (jin >= 0) { close(jin); jin = -1; }
        jpid = -1;
        kills = 0;
        esc_state = 0;
        last_nl = 1;
    }
}

int job_start(char *const *argv, job_out_fn out)
{
    int pin[2], pout[2];
    pid_t pid;

    if (job_active()) {
        out("이미 실행 중인 프로그램이 있습니다 (Ctrl+C로 중단)\n");
        return -1;
    }
    if (inherit) {
        /* 터미널 안에서: 입출력과 신호(Ctrl+C)를 그대로 물려 주고 끝날 때까지 기다린다 */
        int st = 0;
        pid_t p = fork();
        char msg[96];
        if (p < 0) { out("프로그램을 시작할 수 없습니다\n"); return -1; }
        if (p == 0) {
            signal(SIGPIPE, SIG_DFL);
            execvp(argv[0], argv);
            fprintf(stderr, "실행할 수 없습니다: %s (%s)\n", argv[0], strerror(errno));
            _exit(127);
        }
        while (waitpid(p, &st, 0) < 0 && errno == EINTR) ;
        if (WIFSIGNALED(st))
            snprintf(msg, sizeof msg, "[시그널 %d로 종료됨]\n", WTERMSIG(st));
        else if (WEXITSTATUS(st) != 0)
            snprintf(msg, sizeof msg, "[종료 코드 %d]\n", WEXITSTATUS(st));
        else
            msg[0] = 0;
        if (msg[0]) out(msg);
        return 0;
    }
    if (cloexec_pipe(pin) < 0) { out("파이프를 만들 수 없습니다\n"); return -1; }
    if (cloexec_pipe(pout) < 0) {
        close(pin[0]); close(pin[1]);
        out("파이프를 만들 수 없습니다\n");
        return -1;
    }
    pid = fork();
    if (pid < 0) {
        close(pin[0]); close(pin[1]); close(pout[0]); close(pout[1]);
        out("프로그램을 시작할 수 없습니다\n");
        return -1;
    }
    if (pid == 0) {
        /* 자식: 입출력을 파이프에 잇고 새 프로세스 그룹으로 옮긴다 */
        const char *head = "실행할 수 없습니다: ";
        const char *why = strerror(errno);
        setpgid(0, 0);
        signal(SIGPIPE, SIG_DFL);
        dup2(pin[0], 0);
        dup2(pout[1], 1);
        dup2(pout[1], 2);
        execvp(argv[0], argv);
        why = strerror(errno);
        (void)!write(2, head, strlen(head));
        (void)!write(2, why, strlen(why));
        (void)!write(2, "\n", 1);
        _exit(127);
    }
    setpgid(pid, pid);   /* 부모 쪽에서도 설정 (자식이 exec 하기 전 경쟁 방지) */
    close(pin[0]);
    close(pout[1]);
    fcntl(pout[0], F_SETFL, O_NONBLOCK);
    jpid = pid;
    jin = pin[1];
    jout = pout[0];
    kills = 0;
    ncarry = 0;
    esc_state = 0;
    last_nl = 1;
    return 0;
}

void job_send(const char *line)
{
    if (jin < 0) return;
    (void)!write(jin, line, strlen(line));
    (void)!write(jin, "\n", 1);
}

void job_interrupt(void)
{
    if (jpid <= 0) return;
    kills++;
    kill(-jpid, kills > 1 ? SIGKILL : SIGINT);
}

void job_stop(void)
{
    if (jpid > 0) kill(-jpid, SIGKILL);
}

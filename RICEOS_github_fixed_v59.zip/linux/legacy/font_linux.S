/* 폰트 바이너리를 ELF 실행 파일에 포함 */
    .section .rodata
    .balign 16
    .globl riceos_font
riceos_font:
    .incbin "RICEOS_FONT.BIN"
    .section .note.GNU-stack,"",@progbits

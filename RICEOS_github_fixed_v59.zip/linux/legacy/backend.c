/* RICEOS 리눅스 백엔드: ui.c가 부르는 device/fs/pci/net 함수를 /sys, /proc으로 구현 */
#define _GNU_SOURCE
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <dirent.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/mount.h>
#include <sys/wait.h>
#include "../../device.h"
#include "../../fs.h"
#include "../../pci.h"
#include "../../net.h"
#include "job.h"
#include "elfinfo.h"
#include "media.h"
#include <strings.h>
#include <limits.h>
#include <errno.h>

/* ---------- 도우미 ---------- */
static int read_file(const char *path, char *buf, size_t n)
{
    FILE *f = fopen(path, "r");
    size_t k;
    if (!f) { buf[0] = 0; return 0; }
    k = fread(buf, 1, n - 1, f);
    fclose(f);
    buf[k] = 0;
    while (k && (buf[k - 1] == '\n' || buf[k - 1] == ' ')) buf[--k] = 0;
    return 1;
}
static int cmp_str(const void *a, const void *b) { return strcmp(*(char *const *)a, *(char *const *)b); }

/* 디렉터리의 항목 이름을 정렬해서 돌려준다 (호출자가 free) */
static int list_dir(const char *path, char ***out)
{
    DIR *d = opendir(path);
    struct dirent *e;
    char **v = 0;
    int n = 0, cap = 0;
    *out = 0;
    if (!d) return 0;
    while ((e = readdir(d))) {
        if (e->d_name[0] == '.') continue;
        if (n == cap) { cap = cap ? cap * 2 : 32; v = realloc(v, cap * sizeof(char *)); }
        v[n++] = strdup(e->d_name);
    }
    closedir(d);
    if (n) qsort(v, n, sizeof(char *), cmp_str);
    *out = v;
    return n;
}
static void free_list(char **v, int n) { for (int i = 0; i < n; i++) free(v[i]); free(v); }

/* ---------- 저장 장치 ---------- */
#define MAXD 64
static char known[MAXD][32];
static int nknown;

static int is_real_disk(const char *n)
{
    return strncmp(n, "loop", 4) && strncmp(n, "ram", 3) && strncmp(n, "zram", 4) &&
           strncmp(n, "dm-", 3) && strncmp(n, "md", 2) && strncmp(n, "nbd", 3);
}

static const char *kind_of(const char *n)
{
    static char link[512];
    char p[128];
    ssize_t k;
    snprintf(p, sizeof p, "/sys/block/%s", n);
    k = readlink(p, link, sizeof link - 1);
    link[k > 0 ? k : 0] = 0;
    if (!strncmp(n, "sr", 2)) return "광학 드라이브(CD/DVD)";
    if (!strncmp(n, "fd", 2)) return "플로피 디스크";
    if (!strncmp(n, "nvme", 4)) return "NVMe 디스크";
    if (strstr(link, "/usb")) return "USB 저장장치";
    if (!strncmp(n, "mmcblk", 6)) return "SD/eMMC";
    if (!strncmp(n, "sd", 2) || !strncmp(n, "hd", 2)) return "SATA 디스크";
    return "기타 블록 장치";
}

static void describe(const char *n, int idx, char *line, size_t sz)
{
    char p[128], v[64];
    unsigned long long sect = 0;
    int removable = 0;
    snprintf(p, sizeof p, "/sys/block/%s/size", n);
    if (read_file(p, v, sizeof v)) sect = strtoull(v, 0, 10);
    snprintf(p, sizeof p, "/sys/block/%s/removable", n);
    if (read_file(p, v, sizeof v)) removable = atoi(v);
    if (sect == 0)
        snprintf(line, sz, "  [%d] %s  (미디어 없음)  [%s]  /dev/%s\n", idx, kind_of(n),
                 removable ? "이동식" : "고정", n);
    else
        snprintf(line, sz, "  [%d] %s  %llu MB  [%s]  /dev/%s\n", idx, kind_of(n),
                 sect / 2048, removable ? "이동식" : "고정", n);
}

static int disks(char names[][32])
{
    char **v;
    int n = list_dir("/sys/block", &v), k = 0;
    for (int i = 0; i < n && k < MAXD; i++)
        if (is_real_disk(v[i])) { snprintf(names[k], 32, "%s", v[i]); k++; }
    free_list(v, n);
    return k;
}

void device_init(EFI_BOOT_SERVICES *bs)
{
    (void)bs;
    nknown = disks(known);
}

void device_list(out_fn out)
{
    char names[MAXD][32], line[256];
    int n = disks(names);
    out("연결된 저장 장치:\n");
    if (!n) { out("  (없음)\n"); return; }
    for (int i = 0; i < n; i++) { describe(names[i], i + 1, line, sizeof line); out(line); }
}

void device_poll(out_fn out)
{
    char now[MAXD][32], line[256];
    int n = disks(now);
    for (int i = 0; i < nknown; i++) {
        int f = 0;
        for (int j = 0; j < n; j++) if (!strcmp(known[i], now[j])) f = 1;
        if (!f) {
            snprintf(line, sizeof line, "장치 분리: /dev/%s\n", known[i]);
            out(line);
        }
    }
    for (int j = 0; j < n; j++) {
        int f = 0;
        for (int i = 0; i < nknown; i++) if (!strcmp(known[i], now[j])) f = 1;
        if (!f) { out("새 장치 연결:\n"); describe(now[j], j + 1, line, sizeof line); out(line); }
    }
    memcpy(known, now, sizeof known);
    nknown = n;
}

/* ---------- 파티션 ---------- */
#define MAXV 64
static char vname[MAXV][32];

static const char *ident(const char *dev)
{
    unsigned char b[2048];
    int fd = open(dev, O_RDONLY);
    ssize_t k;
    if (fd < 0) return 0;
    k = pread(fd, b, sizeof b, 0);
    close(fd);
    if (k < 512) return "알 수 없음";
    if (!memcmp(b + 3, "EXFAT   ", 8)) return "exfat";
    if (!memcmp(b + 3, "NTFS    ", 8)) return "ntfs";
    if (k >= 1082 && b[1080] == 0x53 && b[1081] == 0xEF) return "ext4";
    if (b[510] == 0x55 && b[511] == 0xAA) {
        if (!memcmp(b + 82, "FAT32   ", 8)) return "vfat";
        if (!memcmp(b + 54, "FAT16   ", 8) || !memcmp(b + 54, "FAT12   ", 8)) return "vfat";
    }
    return "알 수 없음";
}

static int partitions(void)
{
    char names[MAXD][32];
    int nd = disks(names), nv = 0;
    for (int i = 0; i < nd; i++) {
        char p[96], **v;
        int n;
        snprintf(p, sizeof p, "/sys/block/%s", names[i]);
        n = list_dir(p, &v);
        for (int j = 0; j < n && nv < MAXV; j++)
            if (!strncmp(v[j], names[i], strlen(names[i])) && v[j][strlen(names[i])] != 0)
                snprintf(vname[nv++], 32, "%s", v[j]);
        free_list(v, n);
    }
    return nv;
}

void fs_volumes(out_fn out)
{
    int n = partitions();
    char line[200], dev[64];
    if (!n) { out("파티션이 없습니다.\n"); return; }
    out("파티션 목록:\n");
    for (int i = 0; i < n; i++) {
        const char *t;
        snprintf(dev, sizeof dev, "/dev/%s", vname[i]);
        t = ident(dev);
        snprintf(line, sizeof line, "  [%d] %s  %s  /dev/%s\n", i + 1, t ? t : "읽기 실패",
                 (t && strcmp(t, "알 수 없음")) ? "(읽기 가능)" : "(지원하지 않음)", vname[i]);
        out(line);
    }
}

void fs_ls(UINT32 index, out_fn out)
{
    int n = partitions();
    char dev[64], mp[64], line[600], **v;
    const char *t;
    int cnt;
    if (index < 1 || (int)index > n) { out("잘못된 파티션 번호입니다.\n"); return; }
    snprintf(dev, sizeof dev, "/dev/%s", vname[index - 1]);
    snprintf(mp, sizeof mp, "/mnt/riceos%u", index);
    t = ident(dev);
    if (!t || !strcmp(t, "알 수 없음")) { out("이 파일 시스템은 읽을 수 없습니다.\n"); return; }
    mkdir("/mnt", 0755);
    mkdir(mp, 0755);
    (void)mount(dev, mp, !strcmp(t, "ntfs") ? "ntfs3" : t, MS_RDONLY, 0);
    cnt = list_dir(mp, &v);
    out("루트 디렉터리:\n");
    for (int i = 0; i < cnt; i++) {
        struct stat st;
        char full[700];
        snprintf(full, sizeof full, "%s/%s", mp, v[i]);
        if (stat(full, &st) == 0 && S_ISDIR(st.st_mode))
            snprintf(line, sizeof line, "  [DIR] %s\n", v[i]);
        else
            snprintf(line, sizeof line, "        %s  %lld B\n", v[i], (long long)st.st_size);
        out(line);
    }
    if (!cnt) out("  (비어 있거나 마운트할 수 없습니다)\n");
    free_list(v, cnt);
}

/* ---------- PCI ---------- */
void pci_list(pci_out_fn out)
{
    char **v, p[160], a[32], line[200];
    int n = list_dir("/sys/bus/pci/devices", &v);
    out("PCI 장치 목록:\n");
    for (int i = 0; i < n; i++) {
        unsigned ven = 0, dev = 0, cls = 0;
        const char *name;
        snprintf(p, sizeof p, "/sys/bus/pci/devices/%s/vendor", v[i]);
        if (read_file(p, a, sizeof a)) ven = (unsigned)strtoul(a, 0, 16);
        snprintf(p, sizeof p, "/sys/bus/pci/devices/%s/device", v[i]);
        if (read_file(p, a, sizeof a)) dev = (unsigned)strtoul(a, 0, 16);
        snprintf(p, sizeof p, "/sys/bus/pci/devices/%s/class", v[i]);
        if (read_file(p, a, sizeof a)) cls = (unsigned)strtoul(a, 0, 16);
        switch (cls >> 16) {
        case 0x01: name = (cls >> 8 & 0xFF) == 0x08 ? "NVMe 컨트롤러" : "저장장치 컨트롤러"; break;
        case 0x02: name = "네트워크 어댑터"; break;
        case 0x03: name = "그래픽 컨트롤러"; break;
        case 0x04: name = "오디오/멀티미디어"; break;
        case 0x06: name = "브리지"; break;
        case 0x0C: name = (cls >> 8 & 0xFF) == 0x03 ? "USB 컨트롤러" : "직렬 버스 컨트롤러"; break;
        default:   name = "기타 장치"; break;
        }
        snprintf(line, sizeof line, "  %s  %04X:%04X  %s\n", v[i] + 5, ven, dev, name);
        out(line);
    }
    if (!n) out("  (장치를 찾지 못했습니다)\n");
    free_list(v, n);
}

/* ---------- 네트워크 ---------- */
void net_init(EFI_BOOT_SERVICES *bs) { (void)bs; }

void net_info(net_out_fn out)
{
    char **v, p[160], a[64], st[32], line[200];
    int n = list_dir("/sys/class/net", &v), shown = 0;
    out("네트워크:\n");
    for (int i = 0; i < n; i++) {
        if (!strcmp(v[i], "lo")) continue;
        snprintf(p, sizeof p, "/sys/class/net/%s/address", v[i]);
        read_file(p, a, sizeof a);
        snprintf(p, sizeof p, "/sys/class/net/%s/operstate", v[i]);
        read_file(p, st, sizeof st);
        snprintf(line, sizeof line, "  %s  상태: %s  MAC: %s\n", v[i], st, a);
        out(line);
        shown++;
    }
    if (!shown) out("  (네트워크 장치가 없습니다)\n");
    free_list(v, n);
}

/* ---------- 파티션 마운트 (쓰기 가능, 실행 허용) ---------- */
static int is_mounted_at(const char *dev, char *where, size_t sz)
{
    FILE *f = fopen("/proc/mounts", "r");
    char line[512], a[256], m[256];
    if (!f) return 0;
    while (fgets(line, sizeof line, f)) {
        if (sscanf(line, "%255s %255s", a, m) == 2 && !strcmp(a, dev)) {
            snprintf(where, sz, "%s", m);
            fclose(f);
            return 1;
        }
    }
    fclose(f);
    return 0;
}

int linux_mount_part(UINT32 index, out_fn out)
{
    int n = partitions();
    char dev[64], mp[64], where[256], line[320];
    const char *t;
    if (index < 1 || (int)index > n) { out("잘못된 파티션 번호입니다.\n"); return -1; }
    snprintf(dev, sizeof dev, "/dev/%s", vname[index - 1]);
    t = ident(dev);
    if (!t || !strcmp(t, "알 수 없음")) { out("이 파일 시스템은 읽을 수 없습니다.\n"); return -1; }
    snprintf(mp, sizeof mp, "/mnt/riceos%u", index);
    if (is_mounted_at(dev, where, sizeof where) && strcmp(where, mp)) {
        snprintf(line, sizeof line, "이미 다른 곳에 마운트되어 있습니다: %s\n", where);
        out(line);
        return -1;
    }
    mkdir("/mnt", 0755);
    mkdir(mp, 0755);
    umount(mp);   /* ls 가 읽기 전용으로 붙여 둔 경우 떼고 다시 붙인다 */
    if (mount(dev, mp, !strcmp(t, "ntfs") ? "ntfs3" : t, 0, 0)) {
        snprintf(line, sizeof line, "마운트 실패: %s\n", strerror(errno));
        out(line);
        return -1;
    }
    snprintf(line, sizeof line, "%s 를 %s 에 마운트했습니다 (읽기/쓰기, 실행 허용)\n", dev, mp);
    out(line);
    return 0;
}


/* ---------- 무선 인터넷 (NetworkManager, nmcli) ---------- */
/* 주변 무선 네트워크를 다시 검색하고 목록을 보여 준다 */
static const char *wifi_list_sh =
    "nmcli radio wifi on 2>/dev/null\n"
    "nmcli device wifi rescan 2>/dev/null; sleep 2\n"
    "nmcli -f IN-USE,SIGNAL,SECURITY,SSID device wifi list 2>&1\n";

/* 인자: $1=장치 $2=SSID $3=비밀번호(없으면 빈 문자열, 열린 네트워크) */
static const char *wifi_connect_sh =
    "IF=$1; SSID=$2; PASS=$3\n"
    "nmcli radio wifi on 2>/dev/null\n"
    "if [ -n \"$PASS\" ]; then\n"
    "  nmcli device wifi connect \"$SSID\" password \"$PASS\" ifname \"$IF\" 2>&1\n"
    "else\n"
    "  nmcli device wifi connect \"$SSID\" ifname \"$IF\" 2>&1\n"
    "fi\n";

/* 장치 상태, 연결 이름, IP 주소 */
static const char *wifi_status_sh =
    "nmcli -f DEVICE,TYPE,STATE,CONNECTION device status 2>&1\n"
    "ip -4 -br addr 2>&1\n";

static void wifi_usage(out_fn out)
{
    out("사용법:\n");
    out("  wifi list                      주변 무선 네트워크 검색\n");
    out("  wifi connect 장치 이름 [암호]  무선 네트워크 연결 (공백 없는 이름과 암호)\n");
    out("  wifi status                    연결 상태와 IP 주소\n");
    out("  ※ 입력한 암호는 명령 창에 그대로 보입니다.\n");
}

static int wifi_command(int n, char **argv, out_fn out)
{
    char *sh[10];
    if (n < 2) { wifi_usage(out); return 0; }
    if (!strcmp(argv[1], "list")) {
        sh[0] = "/bin/sh"; sh[1] = "-c"; sh[2] = (char *)wifi_list_sh; sh[3] = 0;
    } else if (!strcmp(argv[1], "status")) {
        sh[0] = "/bin/sh"; sh[1] = "-c"; sh[2] = (char *)wifi_status_sh; sh[3] = 0;
    } else if (!strcmp(argv[1], "connect")) {
        if (n < 4) { out("사용법: wifi connect 장치 이름 [암호]\n"); return 0; }
        sh[0] = "/bin/sh"; sh[1] = "-c"; sh[2] = (char *)wifi_connect_sh;
        sh[3] = "wifi";                 /* $0 */
        sh[4] = argv[2];                /* $1 장치 */
        sh[5] = argv[3];                /* $2 SSID */
        sh[6] = n >= 5 ? argv[4] : "";  /* $3 암호 */
        sh[7] = 0;
    } else { wifi_usage(out); return 0; }
    job_start(sh, out);
    return 1;
}


/* ---------- 드라이버와 펌웨어 (Debian apt, 인터넷 필요) ---------- */
/* 장치별 드라이버 연결 상태 */
static void driver_status(out_fn out)
{
    char **v, p[200], line[300], drv[256], a[32];
    int n = list_dir("/sys/bus/pci/devices", &v), missing = 0;
    out("장치별 드라이버 상태:\n");
    for (int i = 0; i < n; i++) {
        unsigned ven = 0, dev = 0;
        ssize_t k;
        const char *name = "(드라이버 없음)";
        snprintf(p, sizeof p, "/sys/bus/pci/devices/%s/vendor", v[i]);
        if (read_file(p, a, sizeof a)) ven = (unsigned)strtoul(a, 0, 16);
        snprintf(p, sizeof p, "/sys/bus/pci/devices/%s/device", v[i]);
        if (read_file(p, a, sizeof a)) dev = (unsigned)strtoul(a, 0, 16);
        snprintf(p, sizeof p, "/sys/bus/pci/devices/%s/driver", v[i]);
        k = readlink(p, drv, sizeof drv - 1);
        if (k > 0) {
            char *base;
            drv[k] = 0;
            base = strrchr(drv, '/');
            name = base ? base + 1 : drv;
        } else {
            missing++;
        }
        snprintf(line, sizeof line, "  %s  %04X:%04X  %s\n", v[i] + 5, ven, dev, name);
        out(line);
    }
    if (!n) out("  (PCI 장치를 찾지 못했습니다)\n");
    free_list(v, n);
    v = 0;
    n = 0;

    /* USB 장치: 인터페이스(장치:1.0 등)에 드라이버가 붙었는지 본다 */
    n = list_dir("/sys/bus/usb/devices", &v);
    out("\nUSB 장치:\n");
    for (int i = 0; i < n; i++) {
        char dpath[300], ipath[300], prod[128] = "", vid[16] = "", pid[16] = "";
        int bound = 0;
        DIR *d;
        struct dirent *e;
        snprintf(p, sizeof p, "/sys/bus/usb/devices/%s/idVendor", v[i]);
        if (!read_file(p, vid, sizeof vid)) continue;
        snprintf(p, sizeof p, "/sys/bus/usb/devices/%s/idProduct", v[i]);
        read_file(p, pid, sizeof pid);
        snprintf(p, sizeof p, "/sys/bus/usb/devices/%s/product", v[i]);
        read_file(p, prod, sizeof prod);
        snprintf(dpath, sizeof dpath, "/sys/bus/usb/devices");
        d = opendir(dpath);
        if (d) {
            while ((e = readdir(d))) {
                if (strncmp(e->d_name, v[i], strlen(v[i])) || e->d_name[strlen(v[i])] != ':') continue;
                snprintf(ipath, sizeof ipath, "%s/%s/driver", dpath, e->d_name);
                if (access(ipath, F_OK) == 0) bound = 1;
            }
            closedir(d);
        }
        snprintf(line, sizeof line, "  %s  %s:%s  %s  %s\n", v[i], vid, pid,
                 prod[0] ? prod : "(이름 없음)", bound ? "[드라이버 연결됨]" : "[드라이버 없음]");
        out(line);
    }
    if (!n) out("  (USB 장치 없음)\n");
    free_list(v, n);
    v = 0;
    n = 0;
    if (missing) {
        snprintf(line, sizeof line, "\n드라이버가 없는 장치 %d개: 'driver install' 로 펌웨어와 드라이버를 설치하세요.\n", missing);
        out(line);
    }
}

/* 기본 설치: 펌웨어(무선랜·CPU·그래픽·사운드·블루투스), Mesa(그래픽), 오디오와 블루투스 도구 */
static const char *driver_pkgs[] = {
    "firmware-linux", "firmware-linux-nonfree", "firmware-misc-nonfree", "firmware-realtek",
    "firmware-iwlwifi", "firmware-atheros", "firmware-brcm80211", "firmware-amd-graphics",
    "firmware-sof-signed", "intel-microcode", "amd64-microcode",
    "libgl1-mesa-dri", "mesa-vulkan-drivers", "vulkan-tools", "vainfo",
    "alsa-utils", "bluez", 0
};

static const char *apt_sh =
    "export DEBIAN_FRONTEND=noninteractive\n"
    "apt-get update && apt-get install -y --no-install-recommends \"$@\" && "
    "echo '설치 완료. 드라이버를 적용하려면 컴퓨터를 재부팅하세요.'\n";

static const char *apt_nvidia_sh =
    "export DEBIAN_FRONTEND=noninteractive\n"
    "apt-get update && apt-get install -y --no-install-recommends linux-headers-amd64 nvidia-driver && "
    "echo 'NVIDIA 드라이버 설치 완료. 재부팅 후 적용됩니다. (모듈 빌드에 몇 분 걸릴 수 있습니다)'\n";


/* USB 무선랜 드라이버 (Realtek 계열: 커널에 기본 드라이버가 없는 칩). 원본은 GitHub에서 받아 DKMS로 빌드 */
static const struct { const char *name, *url, *desc; } usb_wifi[] = {
    { "8812au", "https://github.com/morrownr/8812au-20210820.git", "RTL8812AU (예: Archer T2U Plus 계열)" },
    { "8821au", "https://github.com/morrownr/8821au-20210708.git", "RTL8811AU / RTL8821AU" },
    { "8821cu", "https://github.com/morrownr/8821cu-20210916.git", "RTL8821CU" },
    { "88x2bu", "https://github.com/morrownr/88x2bu-20210702.git", "RTL8812BU / RTL8822BU (예: Archer T3U, T4U V3)" },
};

static const char *usb_wifi_sh =
    "export DEBIAN_FRONTEND=noninteractive\n"
    "apt-get update && apt-get install -y --no-install-recommends git dkms build-essential bc libelf-dev rfkill iw \"linux-headers-$(uname -r)\" || exit 1\n"
    "rm -rf \"$2\" && git clone --depth 1 \"$1\" \"$2\" || exit 1\n"
    "cd \"$2\" && sh install-driver.sh && echo 'USB 무선랜 드라이버 설치 완료. 재부팅 후 동글을 다시 꽂으세요.'\n";

static int usb_wifi_command(int n, char **argv, out_fn out)
{
    static char *sh[8];
    static char dir[128];
    if (n < 3) {
        out("사용법: driver usb-wifi 칩이름   (칩 이름은 lsusb 결과나 제품 설명서로 확인)\n");
        for (unsigned i = 0; i < sizeof usb_wifi / sizeof usb_wifi[0]; i++) {
            char line[200];
            snprintf(line, sizeof line, "  %-7s %s\n", usb_wifi[i].name, usb_wifi[i].desc);
            out(line);
        }
        return 0;
    }
    for (unsigned i = 0; i < sizeof usb_wifi / sizeof usb_wifi[0]; i++) {
        if (strcmp(argv[2], usb_wifi[i].name)) continue;
        snprintf(dir, sizeof dir, "/usr/src/riceos-usb-wifi-%s", usb_wifi[i].name);
        sh[0] = "/bin/sh"; sh[1] = "-c"; sh[2] = (char *)usb_wifi_sh;
        sh[3] = "driver"; sh[4] = (char *)usb_wifi[i].url; sh[5] = dir; sh[6] = 0;
        out("USB 무선랜 드라이버를 받아 DKMS로 빌드합니다 (몇 분 걸림, 중간에 질문이 나오면 답을 입력하세요)\n");
        job_start(sh, out);
        return 1;
    }
    out("알 수 없는 칩 이름입니다. 'driver usb-wifi' 로 목록을 보세요.\n");
    return 0;
}

static int driver_command(int n, char **argv, out_fn out)
{
    static char *sh[40];
    int k = 0;
    if (n < 2 || !strcmp(argv[1], "status")) { driver_status(out); return 0; }
    if (!strcmp(argv[1], "install")) {
        sh[k++] = "/bin/sh"; sh[k++] = "-c"; sh[k++] = (char *)apt_sh; sh[k++] = "driver";
        for (int i = 0; driver_pkgs[i]; i++) sh[k++] = (char *)driver_pkgs[i];
        sh[k] = 0;
        out("인터넷에서 펌웨어와 드라이버를 받습니다 (몇 분 걸릴 수 있습니다, Ctrl+C로 중단)\n");
        job_start(sh, out);
        return 1;
    }
    if (!strcmp(argv[1], "usb-wifi"))
        return usb_wifi_command(n, argv, out);
    if (!strcmp(argv[1], "nvidia")) {
        sh[0] = "/bin/sh"; sh[1] = "-c"; sh[2] = (char *)apt_nvidia_sh; sh[3] = "driver"; sh[4] = 0;
        out("NVIDIA 독점 드라이버를 설치합니다 (non-free, 커널 헤더 필요, 시간이 오래 걸립니다)\n");
        job_start(sh, out);
        return 1;
    }
    out("사용법:\n");
    out("  driver status    장치별 드라이버 연결 상태\n");
    out("  driver install   펌웨어, Mesa 그래픽, 오디오, 블루투스 설치 (인터넷 필요)\n");
    out("  driver nvidia    NVIDIA 독점 드라이버 설치 (인터넷 필요)\n");
    out("  driver usb-wifi  USB 무선랜 드라이버 (Realtek, DKMS, 인터넷 필요)\n");
    return 0;
}


/* ---------- 사운드 (ALSA: alsa-utils, 여러 프로그램이 dmix로 함께 씀) ---------- */
static const char *sound_sh =
    "ctl=Master\n"
    "amixer get Master >/dev/null 2>&1 || ctl=PCM\n"
    "if ! grep -q '\\[' /proc/asound/cards 2>/dev/null; then\n"
    "  echo '사운드 장치를 찾지 못했습니다. (드라이버: driver install)'; exit 1\n"
    "fi\n"
    "case \"$1\" in\n"
    "  up)     amixer -q sset \"$ctl\" 5%+ unmute ;;\n"
    "  down)   amixer -q sset \"$ctl\" 5%- unmute ;;\n"
    "  mute)   amixer -q sset \"$ctl\" mute ;;\n"
    "  unmute) amixer -q sset \"$ctl\" unmute ;;\n"
    "  test)   timeout 5 speaker-test -t sine -f 440 -l 1 >/dev/null 2>&1 && echo '재생 완료 (소리가 들렸다면 정상입니다)' ;;\n"
    "  *)      ;;\n"
    "esac\n"
    "amixer get \"$ctl\" 2>/dev/null | grep -o '\\[[^]]*\\]' | tr '\\n' ' '; echo\n";

static int sound_command(int n, char **argv, out_fn out)
{
    char *sh[6];
    const char *sub = n >= 2 ? argv[1] : "status";
    if (strcmp(sub, "status") && strcmp(sub, "up") && strcmp(sub, "down") &&
        strcmp(sub, "mute") && strcmp(sub, "unmute") && strcmp(sub, "test")) {
        out("사용법: riceos sound [status|up|down|mute|unmute|test]\n");
        return 0;
    }
    if (!strcmp(sub, "status")) sub = "";
    sh[0] = "/bin/sh"; sh[1] = "-c"; sh[2] = (char *)sound_sh; sh[3] = "sound"; sh[4] = (char *)sub; sh[5] = 0;
    job_start(sh, out);
    return 1;
}

/* ---------- 무선 장치 켜기/끄기 (작업 표시줄 트레이와 명령 모두에서 쓴다) ---------- */
static const char *radio_sh =
    "case \"$1\" in\n"
    "  wifi) case \"$2\" in\n"
    "          on)  rfkill unblock wifi ;;\n"
    "          off) rfkill block wifi ;;\n"
    "        esac ;;\n"
    "  bt)   case \"$2\" in\n"
    "          on)  rfkill unblock bluetooth; systemctl start bluetooth 2>/dev/null; sleep 1; bluetoothctl power on >/dev/null 2>&1 ;;\n"
    "          off) bluetoothctl power off >/dev/null 2>&1; rfkill block bluetooth ;;\n"
    "        esac ;;\n"
    "esac\n"
    "exit 0\n";

static int radio_command(int n, char **argv, out_fn out)
{
    char *sh[7];
    if (n < 3 || (strcmp(argv[1], "wifi") && strcmp(argv[1], "bt")) ||
        (strcmp(argv[2], "on") && strcmp(argv[2], "off"))) {
        out("사용법: riceos radio wifi|bt on|off\n");
        return 0;
    }
    sh[0] = "/bin/sh"; sh[1] = "-c"; sh[2] = (char *)radio_sh; sh[3] = "radio";
    sh[4] = argv[1]; sh[5] = argv[2]; sh[6] = 0;
    job_start(sh, out);
    return 1;
}

/* ---------- 배경화면 · 효과음 (설정 파일을 고치면 화면이 1초 안에 반영한다) ---------- */
static int wallpaper_command(int n, char **argv, out_fn out)
{
    ui_conf_t c;
    char msg[400];
    const char *sub = n >= 2 ? argv[1] : "status";
    conf_load(&c);
    if (!strcmp(sub, "status")) {
        snprintf(msg, sizeof msg, "현재 배경화면: %s\n", c.wallpaper);
        out(msg);
        return 0;
    }
    if (!strcmp(sub, "next")) {
        char nm[256];
        wp_next_name(c.wallpaper, nm, sizeof nm);
        snprintf(c.wallpaper, sizeof c.wallpaper, "%s", nm);
    } else if (!strcmp(sub, "default")) {
        snprintf(c.wallpaper, sizeof c.wallpaper, "default");
    } else if (!strcmp(sub, "set") && n >= 3) {
        char real[PATH_MAX];
        size_t len = strlen(argv[2]);
        if (len < 5 || (strcasecmp(argv[2] + len - 4, ".png") && strcasecmp(argv[2] + len - 4, ".bmp"))) {
            out("PNG 또는 BMP 그림 파일만 쓸 수 있습니다\n");
            return 0;
        }
        if (!realpath(argv[2], real)) {
            out("그림 파일을 찾지 못했습니다\n");
            return 0;
        }
        snprintf(c.wallpaper, sizeof c.wallpaper, "%s", real);
    } else {
        out("사용법: riceos wallpaper [status|next|set 그림파일|default]\n");
        return 0;
    }
    if (conf_save(&c)) {
        out("설정을 저장하지 못했습니다 (root 권한으로 실행하세요)\n");
        return 0;
    }
    snprintf(msg, sizeof msg, "배경화면: %s (잠시 후 바뀝니다)\n", c.wallpaper);
    out(msg);
    return 0;
}

static int sfx_command(int n, char **argv, out_fn out)
{
    ui_conf_t c;
    const char *sub = n >= 2 ? argv[1] : "status";
    conf_load(&c);
    if (!strcmp(sub, "status")) {
        out(c.sfx ? "효과음: 켜짐\n" : "효과음: 꺼짐\n");
        return 0;
    }
    if (!strcmp(sub, "test")) {
        sfx_init();
        sfx_enable(1);
        sfx_play(SFX_CLICK);
        out("효과음을 재생합니다\n");
        return 0;
    }
    if (!strcmp(sub, "on")) c.sfx = 1;
    else if (!strcmp(sub, "off")) c.sfx = 0;
    else if (!strcmp(sub, "toggle")) c.sfx = !c.sfx;
    else {
        out("사용법: riceos sfx [on|off|toggle|test]\n");
        return 0;
    }
    if (conf_save(&c)) {
        out("설정을 저장하지 못했습니다 (root 권한으로 실행하세요)\n");
        return 0;
    }
    out(c.sfx ? "효과음: 켜짐 (잠시 후 반영)\n" : "효과음: 꺼짐 (잠시 후 반영)\n");
    return 0;
}

/* ---------- 명령 실행: 외부 프로그램은 비동기로 ---------- */
static int split_words(char *s, char **argv, int max)
{
    int n = 0;
    char *p = s;
    while (*p && n < max - 1) {
        while (*p == ' ') p++;
        if (!*p) break;
        argv[n++] = p;
        while (*p && *p != ' ') p++;
        if (*p) *p++ = 0;
    }
    argv[n] = 0;
    return n;
}

/* 경로의 파일을 실행해도 되는지 확인하고 설명 문장을 msg 에 쓴다 */
static int exec_ok(const char *path, char *msg, size_t sz)
{
    char info[300];
    int host_ok = 0, r;
    const char *os = foreign_os(path);
    if (os) { snprintf(msg, sz, "이것은 %s 전용 파일입니다.\n", os); return 0; }
    r = elf_describe(path, info, sizeof info, &host_ok);
    if (r < 0) { snprintf(msg, sz, "실행 파일이 아닙니다: %s (%s)\n", path, info); return 0; }
    if (!host_ok) { snprintf(msg, sz, "이 컴퓨터의 CPU와 맞지 않는 파일입니다: %s (%s)\n", path, info); return 0; }
    if (access(path, X_OK) != 0) {
        snprintf(msg, sz, "실행 권한이 없습니다. 'chmod +x %s' 후 다시 실행하세요.\n", path);
        return 0;
    }
    snprintf(msg, sz, "[%s] %s\n", path, info);
    return 1;
}

/* 명령 한 줄 처리. 내장 명령(run, file, mount)이 아니면 /bin/sh -c 로 실행 */
int linux_command(const char *line, out_fn out)
{
    char buf[256], msg[400], info[300];
    char *argv[32];
    int n, host_ok = 0;

    snprintf(buf, sizeof buf, "%s", line);
    n = split_words(buf, argv, 32);
    if (n == 0) return 0;

    if (!strcmp(argv[0], "run")) {
        if (n < 2) { out("사용법: run 경로 [인자...]\n"); return 0; }
        if (strchr(argv[1], '/')) {
            if (!exec_ok(argv[1], msg, sizeof msg)) { out(msg); return 0; }
            out(msg);
        }
        job_start(&argv[1], out);   /* 경로에 / 가 없으면 PATH 에서 찾는다 */
        return 1;
    }
    if (!strcmp(argv[0], "file")) {
        const char *os;
        if (n < 2) { out("사용법: file 경로\n"); return 0; }
        os = foreign_os(argv[1]);
        if (os) { snprintf(msg, sizeof msg, "%s: 이것은 %s 전용 파일입니다.\n", argv[1], os); out(msg); return 0; }
        elf_describe(argv[1], info, sizeof info, &host_ok);
        snprintf(msg, sizeof msg, "%s: %s\n", argv[1], info);
        out(msg);
        return 0;
    }
    if (!strcmp(argv[0], "devices")) { device_list(out); return 0; }
    if (!strcmp(argv[0], "volumes")) { fs_volumes(out); return 0; }
    if (!strcmp(argv[0], "hw")) { pci_list(out); return 0; }
    if (!strcmp(argv[0], "net")) { net_info(out); return 0; }
    if (!strcmp(argv[0], "ls")) {
        UINT32 idx = 0;
        int i;
        if (n < 2) { out("사용법: ls 번호\n"); return 0; }
        for (i = 0; argv[1][i] >= '0' && argv[1][i] <= '9'; i++)
            idx = idx * 10 + (UINT32)(argv[1][i] - '0');
        if (i == 0) { out("사용법: ls 번호\n"); return 0; }
        fs_ls(idx, out);
        return 0;
    }
    if (!strcmp(argv[0], "wifi"))
        return wifi_command(n, argv, out);
    if (!strcmp(argv[0], "sound"))
        return sound_command(n, argv, out);
    if (!strcmp(argv[0], "radio"))
        return radio_command(n, argv, out);
    if (!strcmp(argv[0], "wallpaper"))
        return wallpaper_command(n, argv, out);
    if (!strcmp(argv[0], "sfx"))
        return sfx_command(n, argv, out);
    if (!strcmp(argv[0], "driver"))
        return driver_command(n, argv, out);
    if (!strcmp(argv[0], "mount")) {
        UINT32 idx = 0;
        int i;
        if (n < 2) { out("사용법: mount 번호 (파티션 번호는 volumes 명령으로 확인)\n"); return 0; }
        for (i = 0; argv[1][i] >= '0' && argv[1][i] <= '9'; i++)
            idx = idx * 10 + (UINT32)(argv[1][i] - '0');
        if (i == 0) { out("사용법: mount 번호\n"); return 0; }
        linux_mount_part(idx, out);
        return 0;
    }
    /* 실행 파일 이름을 직접 입력한 경우(예: setup.exe)도 같은 안내를 띄운다 */
    if (strchr(argv[0], '/') || strchr(argv[0], '.')) {
        const char *os = foreign_os(argv[0]);
        if (os) { snprintf(msg, sizeof msg, "이것은 %s 전용 파일입니다.\n", os); out(msg); return 0; }
    }
    {
        char *sh[] = { "/bin/sh", "-c", (char *)line, 0 };
        job_start(sh, out);
    }
    return 1;
}

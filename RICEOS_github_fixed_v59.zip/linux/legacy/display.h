/* RICEOS 모니터 출력 (DRM/KMS, 리눅스 전용)
 * 연결된 모니터마다 자기 해상도와 주사율로 따로 켠다 (HDMI, DP, VGA, DVI, eDP 모두 같은 방식).
 * 모니터끼리 주사율이 달라도 된다: 출력마다 CRTC가 독립적으로 타이밍을 만든다.
 */
#ifndef RICEOS_DISPLAY_H
#define RICEOS_DISPLAY_H
#include <stdint.h>
#include <stddef.h>
#include <drm/drm_mode.h>

typedef void (*display_out_fn)(const char *s);

typedef struct {
    char name[32];                       /* 예: HDMI-1, DP-2, VGA-1 */
    uint32_t connector_id, crtc_id, fb_id, handle, pitch;
    uint32_t width, height, refresh;     /* refresh: Hz (이 모니터가 고른 모드) */
    uint32_t *map;                       /* 덤 버퍼 매핑 */
    size_t size;
    struct drm_mode_modeinfo mode;
} display_out_t;

/* 0: 성공, -1: DRM 장치나 연결된 모니터가 없음 (호출한 쪽이 fb0로 대신 그린다) */
int display_init(void);
/* 모니터를 끄고 DRM 권한을 놓는다 (Chrome 세션으로 넘길 때 호출) */
void display_close(void);
/* 1초마다 호출. 모니터가 붙거나 떨어지면 다시 설정하고 1을 돌려준다 */
int display_poll(void);
/* 기준 화면 크기 (연결된 모니터 가운데 가장 큰 것) */
void display_size(uint32_t *w, uint32_t *h);
/* 기준 화면(sw x sh, 32비트)을 모든 모니터에 보낸다. 크기가 다르면 최근접 이웃으로 늘린다 */
void display_present(const uint32_t *src, uint32_t sw, uint32_t sh);
/* 모니터 목록 출력 */
void display_list(display_out_fn out);
int display_count(void);

#endif

/* 하드웨어 커서 (DRM 커서 평면). 커서만 움직일 때는 화면을 다시 그리지 않는다.
 * 64x64 ARGB 그림을 넘기고, 그림 안의 (hx,hy)가 포인터 끝이다. -1: 실패(소프트웨어 커서로 대신) */
int display_cursor_set(const uint32_t *img, int hx, int hy);
/* 기준 화면(sw x sh) 좌표의 포인터 위치를 각 모니터 좌표로 옮긴다 */
void display_cursor_move(int x, int y, uint32_t sw, uint32_t sh);
void display_cursor_off(void);
/* 연결된 모니터 가운데 가장 높은 주사율 (Hz). 모니터가 없으면 60 */
uint32_t display_max_refresh(void);

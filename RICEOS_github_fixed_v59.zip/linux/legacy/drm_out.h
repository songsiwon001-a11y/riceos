/* RICEOS 화면 출력 (DRM/KMS): 모니터 여러 대, HDMI/DP/DVI/VGA/내장 패널,
 * 모니터마다 해상도와 주사율이 달라도 각자 따로 출력한다.
 * libdrm 없이 커널 ioctl만 쓰므로 정적 링크로 빌드된다. */
#ifndef RICEOS_DRM_OUT_H
#define RICEOS_DRM_OUT_H
#include <stdint.h>
#include <poll.h>
#include "../../gfx.h"
#include "../../ui.h"

#define DRM_OUT_MAX 8        /* 동시에 쓰는 모니터 수 (상한) */
#define DRM_CARD_MAX 4       /* 그래픽 카드 수 (내장 + 외장 등) */
#define DRM_MODE_MAX 128

/* 모드 선택용 최소 정보 (테스트하기 쉽게 커널 구조체와 분리) */
typedef struct {
    uint32_t w, h;           /* 해상도 */
    uint32_t mhz;            /* 주사율 (1/1000 Hz, 60000 = 60.000 Hz) */
    int preferred;           /* 모니터가 권장하는(기본) 모드 */
    int interlaced;
} dmode_t;

/* 설정 한 줄: 모니터 이름별 원하는 모드 */
typedef enum { WANT_AUTO, WANT_PREFERRED, WANT_OFF, WANT_EXACT } want_kind_t;
typedef struct { want_kind_t kind; uint32_t w, h, hz; } want_t;   /* hz 0 = 그 해상도의 최고 주사율 */

/* 모드 목록에서 want에 맞는 것을 고른다. 못 찾으면 -1.
 * AUTO: 모니터의 기본 해상도에서 가장 높은 주사율 (인터레이스 제외) */
int drm_pick_mode(const dmode_t *m, int n, want_t want, int *exact_found);
/* 설정 파일 한 줄 해석: 모드 문자열("1920x1080@144", "auto", "preferred", "off") */
int drm_parse_want(const char *s, want_t *out);

/* 화면 켜기. 켜진 모니터 수를 돌려준다 (0이면 DRM을 쓸 수 없음 -> fbdev 사용) */
int  drm_out_init(const char *conf_path);
void drm_out_close(void);
int  drm_out_count(void);
/* poll()에 넣을 파일 기술자 (카드마다 하나). 채운 개수를 돌려준다 */
int  drm_out_fds(struct pollfd *pf, int max);
/* poll 이후 호출: 화면 전환(page flip) 완료 알림을 처리 */
void drm_out_dispatch(void);
/* 모든 모니터를 다시 그리도록 표시 */
void drm_out_mark_dirty(void);
/* 다시 그릴 필요가 있고 직전 화면 전환이 끝난 모니터만 그려서 내보낸다.
 * 그린 모니터 수를 돌려준다. */
int  drm_out_present(void);
/* 모니터 연결/분리 확인 (몇 초마다 호출). 구성이 바뀌면 다시 설정하고 1 */
int  drm_out_hotplug_check(void);
/* 설정 파일을 다시 읽고 모니터를 다시 설정 (SIGUSR1) */
int  drm_out_reconfigure(void);
/* 현재 구성을 사람이 읽는 글로 (display 명령, /run/riceos-display.txt) */
void drm_out_describe(char *buf, size_t n);

#endif

/* RICEOS 터미널: 리눅스 셸(bash)을 가상 터미널(pty)에 연결하고,
 * VT100/xterm 제어 코드를 해석해 글자 격자(화면 + 기록)로 만든다.
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <errno.h>
#include <signal.h>
#include <sys/ioctl.h>
#include <sys/wait.h>
#include <termios.h>
#include "term.h"

/* glibc 의 forkpty (<pty.h>). 헤더 옵션에 따라 안 보일 수 있어 직접 선언 */
pid_t forkpty(int *amaster, char *name, const struct termios *termp, const struct winsize *winp);

#define LROWS 1000          /* 기록 포함 전체 줄 수 (링 버퍼) */
#define SROWS TERM_ROWS     /* 화면 줄 수 */
#define BLANK_FG 16

static term_cell_t ring[LROWS][TERM_COLS];
static int inited;
static int top;                     /* 화면 첫 줄의 링 인덱스 */
static int cur_r, cur_c, saved_r, saved_c;
static int view, hist;              /* 기록 보기 위치, 쌓인 기록 줄 수 */
static int fg = BLANK_FG;
static int alt, appcur, dead = 1;
static int master = -1;
static pid_t child = -1;
static int pst, plen, nump;
static char par[64];
static int pv[16];
static uint32_t u8cp;
static int u8need;

static int ridx(int r) { return ((top + r) % LROWS + LROWS) % LROWS; }
static term_cell_t *cell(int r, int c) { return &ring[ridx(r)][c]; }

static void clear_cells(int r, int from, int to)
{
    if (from < 0) from = 0;
    if (to > TERM_COLS) to = TERM_COLS;
    for (int c = from; c < to; c++) {
        term_cell_t *x = cell(r, c);
        x->cp = 0; x->fg = BLANK_FG; x->wide = 0;
    }
}

static void copy_row(int dst, int src)
{
    memcpy(ring[ridx(dst)], ring[ridx(src)], sizeof ring[0]);
}

static void scroll_up(void)
{
    top = (top + 1) % LROWS;
    clear_cells(SROWS - 1, 0, TERM_COLS);
    if (hist < LROWS - SROWS) hist++;
}

static void linefeed(void)
{
    if (cur_r < SROWS - 1) cur_r++;
    else scroll_up();
}

static void erase_screen(int mode)
{
    if (mode == 0) {
        clear_cells(cur_r, cur_c, TERM_COLS);
        for (int r = cur_r + 1; r < SROWS; r++) clear_cells(r, 0, TERM_COLS);
    } else if (mode == 1) {
        for (int r = 0; r < cur_r; r++) clear_cells(r, 0, TERM_COLS);
        clear_cells(cur_r, 0, cur_c + 1);
    } else {
        for (int r = 0; r < SROWS; r++) clear_cells(r, 0, TERM_COLS);
    }
}

static void erase_line(int mode)
{
    if (mode == 0) clear_cells(cur_r, cur_c, TERM_COLS);
    else if (mode == 1) clear_cells(cur_r, 0, cur_c + 1);
    else clear_cells(cur_r, 0, TERM_COLS);
}

/* 동아시아 글자와 이모지는 두 칸 */
static int wide_cp(uint32_t c)
{
    return (c >= 0x1100 && c <= 0x115F) || (c >= 0x2E80 && c <= 0xA4CF) ||
           (c >= 0xAC00 && c <= 0xD7A3) || (c >= 0xF900 && c <= 0xFAFF) ||
           (c >= 0xFE30 && c <= 0xFE4F) || (c >= 0xFF00 && c <= 0xFF60) ||
           (c >= 0xFFE0 && c <= 0xFFE6) || (c >= 0x1F300 && c <= 0x1F64F) ||
           (c >= 0x1F900 && c <= 0x1F9FF);
}

static void put(uint32_t c)
{
    int w = wide_cp(c) ? 2 : 1;
    term_cell_t *x;
    if (cur_c + w > TERM_COLS) { cur_c = 0; linefeed(); }
    x = cell(cur_r, cur_c);
    x->cp = c; x->fg = (uint8_t)fg; x->wide = w == 2 ? 1 : 0;
    if (w == 2) {
        x = cell(cur_r, cur_c + 1);
        x->cp = 0; x->fg = (uint8_t)fg; x->wide = 2;
    }
    cur_c += w;
}

static void reply(const char *s, int n)
{
    if (master >= 0) { if (write(master, s, (size_t)n) < 0) { /* 무시 */ } }
}

static int P(int i, int def)
{
    return (i < nump && pv[i] > 0) ? pv[i] : def;
}

static void parse_params(void)
{
    const char *p = par;
    int have = 0, v = 0;
    nump = 0;
    if (*p == '?') p++;
    for (;;) {
        if (*p >= '0' && *p <= '9') { v = v * 10 + (*p - '0'); have = 1; }
        else if (*p == ';' || *p == 0) {
            if (nump < 16) pv[nump++] = have ? v : 0;
            v = 0; have = 0;
            if (!*p) break;
        }
        p++;
    }
}

static void sgr(void)
{
    if (!nump) { fg = BLANK_FG; return; }
    for (int i = 0; i < nump; i++) {
        int p = pv[i];
        if (p == 0 || p == 39) fg = BLANK_FG;
        else if (p >= 30 && p <= 37) fg = p - 30;
        else if (p >= 90 && p <= 97) fg = p - 90 + 8;
        else if (p == 38 || p == 48) {          /* 확장 색: 건너뛴다 */
            if (i + 1 < nump && pv[i + 1] == 5) i += 2;
            else if (i + 1 < nump && pv[i + 1] == 2) i += 4;
        }
    }
}

/* 전체 화면 프로그램: 들어갈 때 원래 화면을 저장하고, 나올 때 되돌린다 */
static term_cell_t altsave[SROWS][TERM_COLS];
static int alt_cur_r, alt_cur_c;

static void set_mode(int m, int on)
{
    if (m == 1) appcur = on;
    else if (m == 1049 || m == 1047 || m == 47) {
        if (on && !alt) {
            for (int r = 0; r < SROWS; r++) memcpy(altsave[r], ring[ridx(r)], sizeof altsave[r]);
            alt_cur_r = cur_r; alt_cur_c = cur_c;
            alt = 1;
            erase_screen(2);
            cur_r = cur_c = 0;
        } else if (!on && alt) {
            for (int r = 0; r < SROWS; r++) memcpy(ring[ridx(r)], altsave[r], sizeof altsave[r]);
            cur_r = alt_cur_r; cur_c = alt_cur_c;
            alt = 0;
        }
    }
}

static void csi(char f)
{
    int priv = par[0] == '?';
    int n1, n2;
    parse_params();
    n1 = P(0, 1);
    n2 = P(1, 1);
    switch (f) {
    case 'A': cur_r -= n1; break;
    case 'B': cur_r += n1; break;
    case 'C': cur_c += n1; break;
    case 'D': cur_c -= n1; break;
    case 'E': cur_r += n1; cur_c = 0; break;
    case 'F': cur_r -= n1; cur_c = 0; break;
    case 'G': cur_c = n1 - 1; break;
    case 'd': cur_r = n1 - 1; break;
    case 'H': case 'f': cur_r = n1 - 1; cur_c = n2 - 1; break;
    case 'J': erase_screen(nump ? pv[0] : 0); break;
    case 'K': erase_line(nump ? pv[0] : 0); break;
    case 'L':                                   /* 줄 삽입 */
        for (int r = SROWS - 1; r >= cur_r + n1; r--) copy_row(r, r - n1);
        for (int r = cur_r; r < cur_r + n1 && r < SROWS; r++) clear_cells(r, 0, TERM_COLS);
        break;
    case 'M':                                   /* 줄 삭제 */
        for (int r = cur_r; r + n1 < SROWS; r++) copy_row(r, r + n1);
        for (int r = SROWS - n1; r < SROWS; r++) if (r >= cur_r) clear_cells(r, 0, TERM_COLS);
        break;
    case 'P':                                   /* 글자 삭제 */
        for (int c = cur_c; c + n1 < TERM_COLS; c++) *cell(cur_r, c) = *cell(cur_r, c + n1);
        clear_cells(cur_r, TERM_COLS - n1, TERM_COLS);
        break;
    case '@':                                   /* 글자 삽입 */
        for (int c = TERM_COLS - 1; c >= cur_c + n1; c--) *cell(cur_r, c) = *cell(cur_r, c - n1);
        clear_cells(cur_r, cur_c, cur_c + n1);
        break;
    case 'X': clear_cells(cur_r, cur_c, cur_c + n1); break;
    case 'm': sgr(); break;
    case 'n':                                   /* 커서 위치 보고: 셸이 묻는다 */
        if (nump && pv[0] == 6) {
            char b[32];
            int k = snprintf(b, sizeof b, "\x1b[%d;%dR", cur_r + 1, cur_c + 1);
            reply(b, k);
        } else if (nump && pv[0] == 5) {
            reply("\x1b[0n", 4);
        }
        break;
    case 'c':
        if (!priv) reply("\x1b[?1;2c", 7);
        break;
    case 's': saved_r = cur_r; saved_c = cur_c; break;
    case 'u': cur_r = saved_r; cur_c = saved_c; break;
    case 'h': case 'l':
        if (priv) for (int i = 0; i < nump; i++) set_mode(pv[i], f == 'h');
        break;
    default: break;                             /* 모르는 제어 코드는 무시 */
    }
    if (cur_r < 0) cur_r = 0;
    if (cur_r > SROWS - 1) cur_r = SROWS - 1;
    if (cur_c < 0) cur_c = 0;
    if (cur_c > TERM_COLS - 1) cur_c = TERM_COLS - 1;
}

static void esc_single(unsigned char c)
{
    switch (c) {
    case '7': saved_r = cur_r; saved_c = cur_c; break;
    case '8': cur_r = saved_r; cur_c = saved_c; break;
    case 'M': if (cur_r > 0) cur_r--; break;
    case 'D': linefeed(); break;
    case 'E': cur_c = 0; linefeed(); break;
    case 'c': erase_screen(2); cur_r = cur_c = 0; fg = BLANK_FG; break;
    default: break;
    }
}

/* 상태 기계: 0 일반, 1 ESC 뒤, 2 CSI, 3 OSC, 4 문자 집합 지정 뒤, 5 OSC 안의 ESC */
static void feed_bytes(const unsigned char *b, int n)
{
    for (int i = 0; i < n; i++) {
        unsigned char c = b[i];
        switch (pst) {
        case 0:
            if (c == 0x1B) { pst = 1; break; }
            if (c < 0x20 || c == 0x7F) {
                if (c == 0x08) { if (cur_c > 0) cur_c--; }
                else if (c == 0x09) {
                    cur_c = (cur_c / 8 + 1) * 8;
                    if (cur_c >= TERM_COLS) cur_c = TERM_COLS - 1;
                }
                else if (c == 0x0A || c == 0x0B || c == 0x0C) linefeed();
                else if (c == 0x0D) cur_c = 0;
                break;
            }
            if (c < 0x80) { put(c); break; }
            if ((c & 0xE0) == 0xC0) { u8cp = c & 0x1F; u8need = 1; }
            else if ((c & 0xF0) == 0xE0) { u8cp = c & 0x0F; u8need = 2; }
            else if ((c & 0xF8) == 0xF0) { u8cp = c & 0x07; u8need = 3; }
            else if ((c & 0xC0) == 0x80 && u8need > 0) {
                u8cp = (u8cp << 6) | (c & 0x3F);
                if (--u8need == 0) put(u8cp);
            }
            break;
        case 1:
            if (c == '[') { pst = 2; plen = 0; par[0] = 0; }
            else if (c == ']') pst = 3;
            else if (c == '(' || c == ')' || c == '#' || c == '%') pst = 4;
            else { esc_single(c); pst = 0; }
            break;
        case 2:
            if (c >= 0x40 && c <= 0x7E) { csi((char)c); pst = 0; }
            else if (c == 0x1B) pst = 1;
            else if (c >= 0x20 && plen < (int)sizeof par - 1) { par[plen++] = (char)c; par[plen] = 0; }
            break;
        case 3:
            if (c == 0x07) pst = 0;
            else if (c == 0x1B) pst = 5;
            break;
        case 4:
            pst = 0;
            break;
        case 5:
            pst = 0;
            break;
        }
    }
}

void term_feed(const char *s)
{
    term_init();
    feed_bytes((const unsigned char *)s, (int)strlen(s));
}

void term_init(void)
{
    if (inited) return;
    inited = 1;
    for (int r = 0; r < LROWS; r++)
        for (int c = 0; c < TERM_COLS; c++) {
            ring[r][c].cp = 0; ring[r][c].fg = BLANK_FG; ring[r][c].wide = 0;
        }
    top = cur_r = cur_c = 0;
}

static void shell_gone(void)
{
    int st;
    if (master >= 0) { close(master); master = -1; }
    if (child > 0) { waitpid(child, &st, 0); child = -1; }
    dead = 1;
    pst = 0;
    term_feed("\r\n[셸이 종료되었습니다. 아무 키나 누르면 새 셸을 시작합니다]\r\n");
}

int term_start(void)
{
    struct winsize ws;
    term_init();
    if (master >= 0) return 0;
    memset(&ws, 0, sizeof ws);
    ws.ws_row = SROWS;
    ws.ws_col = TERM_COLS;
    child = forkpty(&master, NULL, NULL, &ws);
    if (child < 0) {
        master = -1; child = -1;
        term_feed("[셸을 시작할 수 없습니다]\r\n");
        return -1;
    }
    if (child == 0) {
        /* 자식: 새 세션의 bash (로그인 셸) */
        signal(SIGPIPE, SIG_DFL);
        setenv("TERM", "xterm", 1);
        setenv("LANG", "C.UTF-8", 1);
        if (!getenv("HOME")) setenv("HOME", "/root", 1);
        if (!getenv("PATH"))
            setenv("PATH", "/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin", 1);
        execl("/bin/bash", "-bash", (char *)0);
        execl("/bin/sh", "-sh", (char *)0);
        _exit(127);
    }
    fcntl(master, F_SETFL, O_NONBLOCK);
    fcntl(master, F_SETFD, FD_CLOEXEC);
    dead = 0;
    appcur = 0;
    alt = 0;
    fg = BLANK_FG;
    pst = 0;
    view = 0;
    return 0;
}

void term_stop(void)
{
    if (child > 0) kill(-child, SIGHUP);
    if (master >= 0) { close(master); master = -1; }
    child = -1;
    dead = 1;
}

int term_poll(void)
{
    int got = 0;
    if (master < 0) return 0;
    for (int round = 0; round < 16; round++) {
        char b[1024];
        ssize_t k = read(master, b, sizeof b);
        if (k > 0) { feed_bytes((const unsigned char *)b, (int)k); got = 1; }
        else if (k == 0 || (k < 0 && errno == EIO)) { shell_gone(); got = 1; break; }
        else break;
    }
    return got;
}

void term_type(const char *s)
{
    if (dead) { term_start(); }
    if (master >= 0) reply(s, (int)strlen(s));
}

void term_key(unsigned scan, unsigned uni)
{
    char b[16];
    int n = 0;
    if (dead) { term_start(); return; }
    view = 0;
    if (scan) {
        const char *s;
        switch (scan) {
        case 0x01: s = appcur ? "\x1bOA" : "\x1b[A"; break;
        case 0x02: s = appcur ? "\x1bOB" : "\x1b[B"; break;
        case 0x11: s = appcur ? "\x1bOC" : "\x1b[C"; break;
        case 0x10: s = appcur ? "\x1bOD" : "\x1b[D"; break;
        case 0x12: s = "\x1b[H"; break;
        case 0x13: s = "\x1b[F"; break;
        case 0x14: s = "\x1b[3~"; break;
        case 0x15: s = "\x1b[5~"; break;
        case 0x16: s = "\x1b[6~"; break;
        case 0x17: s = "\x1b"; break;
        default: return;
        }
        n = (int)strlen(s);
        memcpy(b, s, (size_t)n);
    } else if (uni == 0x08 || uni == 0x7F) {
        b[n++] = 0x7F;
    } else if (uni == 0x0D) {
        b[n++] = '\r';
    } else if (uni < 0x80) {
        b[n++] = (char)uni;
    } else if (uni < 0x800) {
        b[n++] = (char)(0xC0 | (uni >> 6));
        b[n++] = (char)(0x80 | (uni & 0x3F));
    } else {
        b[n++] = (char)(0xE0 | (uni >> 12));
        b[n++] = (char)(0x80 | ((uni >> 6) & 0x3F));
        b[n++] = (char)(0x80 | (uni & 0x3F));
    }
    if (n && master >= 0) reply(b, n);
}

int term_alt(void) { return alt; }

void term_scroll_view(int delta)
{
    view += delta;
    if (view < 0) view = 0;
    if (view > hist) view = hist;
}

const term_cell_t *term_row(int vrow, int nvis)
{
    int first = SROWS - nvis - view;
    return &ring[ridx(first + vrow)][0];
}

int term_cursor(int nvis, int *vr, int *vc)
{
    int first = SROWS - nvis - view;
    int v = cur_r - first;
    if (v < 0 || v >= nvis) return 0;
    *vr = v;
    *vc = cur_c;
    return 1;
}

uint32_t term_rgb(int fg_idx)
{
    static const uint32_t pal[17] = {
        0x101820, 0xB03A2E, 0x1E8449, 0x9A7D0A, 0x1F5FA8, 0x7D3C98, 0x117A65, 0x7F8C8D,
        0x566573, 0xE74C3C, 0x27AE60, 0xD4AC0D, 0x2E86C1, 0xA569BD, 0x148F77, 0x5D6D7E,
        0x101820
    };
    if (fg_idx < 0 || fg_idx > 16) return 0x101820;
    return pal[fg_idx];
}

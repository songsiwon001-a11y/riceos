/* RICEOS 리눅스: 외부 프로그램 비동기 실행 */
#ifndef RICEOS_JOB_H
#define RICEOS_JOB_H

typedef void (*job_out_fn)(const char *s);

/* 실행 중인 프로그램이 있으면 1 */
int  job_active(void);
/* 프로그램을 시작한다 (화면을 멈추지 않는다). 성공 0, 실패 -1 */
int  job_start(char *const *argv, job_out_fn out);
/* 실행 중인 프로그램의 표준 입력에 한 줄 보내기 (끝에 \n 추가) */
void job_send(const char *line);
/* Ctrl+C: 처음엔 SIGINT, 두 번째부터 SIGKILL */
void job_interrupt(void);
/* 출력을 가져오고 종료를 확인한다. 주기적으로 호출 */
void job_poll(job_out_fn out);
/* 화면을 끌 때 실행 중인 프로그램 정리 */
void job_stop(void);
/* 1: 터미널에서 직접 실행 (입출력을 그대로 잇고 끝날 때까지 기다린다) */
void job_set_inherit(int on);

#endif

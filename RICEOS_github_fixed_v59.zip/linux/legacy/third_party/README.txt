라이브러리 소스를 넣는 곳 (내장 빌드)

RICEOS 는 zlib, libpng 을 이 폴더의 소스로 직접 컴파일합니다.
인터넷도, configure도, apt 도 필요 없습니다.

1) zlib 1.3.1 소스 (zlib-1.3.1.tar.gz) 를 풀고, 아래 파일들을 third_party/zlib/ 에 그대로 복사:
     *.c  와  *.h  (파일 전체, 폴더 구조는 평평하게)
   필수 .c : adler32 crc32 deflate infback inffast inflate inftrees trees zutil
             compress uncompr gzclose gzlib gzread gzwrite

2) libpng 1.6.43 소스 (libpng-1.6.43.tar.xz) 를 풀고, 아래 파일들을 third_party/libpng/ 에 복사:
     png.c pngerror.c pngget.c pngmem.c pngpread.c pngread.c pngrio.c pngrtran.c
     pngrutil.c pngset.c pngtrans.c pngwio.c pngwrite.c pngwtran.c pngwutil.c
     png.h pngconf.h pngdebug.h pngpriv.h pngstruct.h pnginfo.h pngstruct.h
   그리고 pnglibconf.h.prebuilt 를 pnglibconf.h 이름으로 함께 복사
   (tarball 안의 scripts/pnglibconf.h.prebuilt 또는 같은 이름 파일).

확인: sh build.sh 를 실행하면 빠진 파일 목록을 알려 줍니다.

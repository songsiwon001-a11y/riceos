/* RICEOS 설정 · 배경화면 · 효과음 구현 (libpng 사용, 정적 링크)
 * 테스트 때는 -DRICEOS_CONF_PATH 등으로 경로를 바꿀 수 있다.
 */
#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <math.h>
#include <errno.h>
#include <fcntl.h>
#include <dirent.h>
#include <unistd.h>
#include <setjmp.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <png.h>
#include "media.h"

#ifndef RICEOS_CONF_DIR
#define RICEOS_CONF_DIR "/etc/riceos"
#endif
#ifndef RICEOS_WP_DIR
#define RICEOS_WP_DIR "/usr/share/riceos/wallpapers"
#endif
#ifndef RICEOS_RUN_DIR
#define RICEOS_RUN_DIR "/run/riceos"
#endif

#define CONF_PATH RICEOS_CONF_DIR "/ui.conf"
#define SFX_RATE  22050

/* ---------- 공통 작은 도구 ---------- */
static void trim(char *s)
{
    size_t n = strlen(s);
    while (n && (s[n - 1] == '\n' || s[n - 1] == '\r' || s[n - 1] == ' ')) s[--n] = 0;
}

static int read_file(const char *path, unsigned char **buf, size_t *size)
{
    FILE *f = fopen(path, "rb");
    long n;
    if (!f) return -1;
    if (fseek(f, 0, SEEK_END) || (n = ftell(f)) < 0 || fseek(f, 0, SEEK_SET)) { fclose(f); return -1; }
    *buf = malloc((size_t)n ? (size_t)n : 1);
    if (!*buf || fread(*buf, 1, (size_t)n, f) != (size_t)n) { free(*buf); fclose(f); return -1; }
    *size = (size_t)n;
    fclose(f);
    return 0;
}

/* ---------- 설정 ---------- */
static time_t conf_mtime = -1;
static off_t conf_size = -1;

void conf_load(ui_conf_t *c)
{
    char line[512];
    FILE *f;
    strcpy(c->wallpaper, "default");
    c->sfx = 1;
    f = fopen(CONF_PATH, "r");
    if (!f) return;
    while (fgets(line, sizeof line, f)) {
        char *eq = strchr(line, '=');
        if (!eq) continue;
        *eq++ = 0;
        trim(line);
        trim(eq);
        if (!strcmp(line, "wallpaper") && *eq) {
            strncpy(c->wallpaper, eq, sizeof c->wallpaper - 1);
            c->wallpaper[sizeof c->wallpaper - 1] = 0;
        } else if (!strcmp(line, "sfx")) {
            c->sfx = strcmp(eq, "off") != 0;
        }
    }
    fclose(f);
}

int conf_save(const ui_conf_t *c)
{
    char tmp[300];
    FILE *f;
    mkdir(RICEOS_CONF_DIR, 0755);            /* 이미 있으면 오류는 무시 */
    snprintf(tmp, sizeof tmp, "%s.tmp", CONF_PATH);
    f = fopen(tmp, "w");
    if (!f) return -1;
    fprintf(f, "# RICEOS 화면 설정 (riceos wallpaper / riceos sfx 로 바꿀 수 있습니다)\n");
    fprintf(f, "wallpaper=%s\n", c->wallpaper);
    fprintf(f, "sfx=%s\n", c->sfx ? "on" : "off");
    if (fclose(f)) return -1;
    return rename(tmp, CONF_PATH) == 0 ? 0 : -1;   /* 원자적으로 교체 */
}

int conf_changed(void)
{
    struct stat st;
    if (stat(CONF_PATH, &st) != 0) {          /* 파일이 없어진 것도 변화 (한 번만 알린다) */
        if (conf_size == -2) return 0;
        conf_size = -2;
        conf_mtime = 0;
        return 1;
    }
    if (st.st_mtime == conf_mtime && st.st_size == conf_size) return 0;
    conf_mtime = st.st_mtime;
    conf_size = st.st_size;
    return 1;
}

/* ---------- 기본 테마 ---------- */
struct theme { const char *name; uint32_t top, bot, gtop, gbot; };
static const struct theme themes[] = {
    { "default", 0x2F7BC4, 0xC9E8FA, 0x8DC26A, 0x4E8A3A },   /* 하늘과 초원 (기존 바탕화면) */
    { "night",   0x0B1B33, 0x2A4A7A, 0x1E3A2A, 0x0C1C14 },   /* 밤하늘 */
    { "mint",    0x2BB39A, 0xD8F7EE, 0x7CCB9E, 0x3E8E6A },   /* 민트 */
};
#define NTHEME ((int)(sizeof themes / sizeof themes[0]))

int wp_theme(const char *name, uint32_t *top, uint32_t *bot, uint32_t *gtop, uint32_t *gbot)
{
    for (int i = 0; i < NTHEME; i++)
        if (!strcmp(name, themes[i].name)) {
            *top = themes[i].top; *bot = themes[i].bot;
            *gtop = themes[i].gtop; *gbot = themes[i].gbot;
            return 1;
        }
    return 0;
}

static int cmp_str(const void *a, const void *b) { return strcmp(*(char *const *)a, *(char *const *)b); }

int wp_next_name(const char *cur, char *out, size_t n)
{
    static char names[NTHEME + 64][256];
    char *ptr[NTHEME + 64];
    int cnt = 0, idx = -1;
    DIR *d;
    struct dirent *e;

    for (int i = 0; i < NTHEME; i++) snprintf(names[cnt++], sizeof names[0], "%s", themes[i].name);
    d = opendir(RICEOS_WP_DIR);
    if (d) {
        char files[64][256];
        int nf = 0;
        while ((e = readdir(d)) && nf < 64) {
            size_t len = strlen(e->d_name);
            if (len < 5) continue;
            if (strcasecmp(e->d_name + len - 4, ".png") && strcasecmp(e->d_name + len - 4, ".bmp")) continue;
            snprintf(files[nf++], sizeof files[0], "%s/%s", RICEOS_WP_DIR, e->d_name);
        }
        closedir(d);
        for (int i = 0; i < nf; i++) ptr[i] = files[i];
        qsort(ptr, nf, sizeof ptr[0], cmp_str);
        for (int i = 0; i < nf; i++) snprintf(names[cnt++], sizeof names[0], "%s", ptr[i]);
    }
    for (int i = 0; i < cnt; i++) if (!strcmp(names[i], cur)) idx = i;
    snprintf(out, n, "%s", names[(idx + 1) % cnt]);
    return 0;
}

/* ---------- 그림 읽기: PNG (libpng), BMP (직접) ---------- */
typedef struct { uint32_t w, h; unsigned char *rgb; } img_t;   /* 위에서 아래로, RGB 8비트 */

static int load_png(const char *path, img_t *im)
{
    FILE *f = fopen(path, "rb");
    png_structp png;
    png_infop info;
    volatile int ok = 0;
    unsigned char *volatile buf = NULL;
    png_bytep *volatile rows = NULL;
    if (!f) return -1;
    png = png_create_read_struct(PNG_LIBPNG_VER_STRING, 0, 0, 0);
    if (!png) { fclose(f); return -1; }
    info = png_create_info_struct(png);
    if (!info) { png_destroy_read_struct(&png, 0, 0); fclose(f); return -1; }
    if (setjmp(png_jmpbuf(png))) goto done;

    png_init_io(png, f);
    png_read_info(png, info);
    png_set_strip_16(png);
    png_set_palette_to_rgb(png);
    png_set_expand_gray_1_2_4_to_8(png);
    png_set_gray_to_rgb(png);
    png_set_tRNS_to_alpha(png);
    png_set_strip_alpha(png);
    png_read_update_info(png, info);

    im->w = png_get_image_width(png, info);
    im->h = png_get_image_height(png, info);
    if (png_get_channels(png, info) != 3 || png_get_bit_depth(png, info) != 8) goto done;

    buf = malloc((size_t)im->w * im->h * 3);
    rows = malloc(sizeof(png_bytep) * im->h);
    if (!buf || !rows) goto done;
    for (uint32_t y = 0; y < im->h; y++) rows[y] = buf + (size_t)y * im->w * 3;
    png_read_image(png, rows);
    im->rgb = buf;
    ok = 1;
done:
    png_destroy_read_struct(&png, &info, 0);
    fclose(f);
    free((void *)rows);
    if (!ok) free((void *)buf);
    return ok ? 0 : -1;
}

static int load_bmp(const char *path, img_t *im)
{
    unsigned char *d = NULL;
    size_t size = 0;
    uint32_t off, comp, stride;
    int32_t w, h;
    uint16_t bpp;
    int topdown;
    if (read_file(path, &d, &size) || size < 54 || d[0] != 'B' || d[1] != 'M') { free(d); return -1; }
    off  = d[10] | d[11] << 8 | d[12] << 16 | (uint32_t)d[13] << 24;
    w    = (int32_t)(d[18] | d[19] << 8 | d[20] << 16 | (uint32_t)d[21] << 24);
    h    = (int32_t)(d[22] | d[23] << 8 | d[24] << 16 | (uint32_t)d[25] << 24);
    bpp  = (uint16_t)(d[28] | d[29] << 8);
    comp = d[30] | d[31] << 8 | d[32] << 16 | (uint32_t)d[33] << 24;
    topdown = h < 0;
    if (topdown) h = -h;
    if (w <= 0 || h <= 0 || (bpp != 24 && bpp != 32) || (comp != 0 && comp != 3)) { free(d); return -1; }
    stride = (((uint32_t)w * bpp + 31) / 32) * 4;
    if (off >= size || (size_t)off + (size_t)stride * (uint32_t)h > size) { free(d); return -1; }

    im->w = (uint32_t)w; im->h = (uint32_t)h;
    im->rgb = malloc((size_t)w * h * 3);
    if (!im->rgb) { free(d); return -1; }
    for (uint32_t y = 0; y < im->h; y++) {
        const unsigned char *src = d + off + (size_t)(topdown ? y : im->h - 1 - y) * stride;
        unsigned char *dst = im->rgb + (size_t)y * im->w * 3;
        for (uint32_t x = 0; x < im->w; x++, src += bpp / 8) {
            dst[x * 3 + 0] = src[2];   /* R */
            dst[x * 3 + 1] = src[1];   /* G */
            dst[x * 3 + 2] = src[0];   /* B */
        }
    }
    free(d);
    return 0;
}

uint32_t *wp_load_image(const char *path, uint32_t W, uint32_t H, int bgr)
{
    img_t im = {0, 0, 0};
    uint32_t *out, *p;
    int *xmap;
    double k, ox, oy;
    unsigned char magic[8] = {0};
    FILE *f = fopen(path, "rb");

    if (!f || !W || !H) { if (f) fclose(f); return NULL; }
    if (fread(magic, 1, sizeof magic, f) == 0) { fclose(f); return NULL; }
    fclose(f);
    if (magic[0] == 0x89 && magic[1] == 'P' && magic[2] == 'N' && magic[3] == 'G') {
        if (load_png(path, &im)) return NULL;
    } else if (magic[0] == 'B' && magic[1] == 'M') {
        if (load_bmp(path, &im)) return NULL;
    } else {
        return NULL;
    }

    /* 화면을 꽉 채우도록 확대하고 가운데를 자른다 */
    k = (double)W / im.w;
    if ((double)H / im.h > k) k = (double)H / im.h;
    ox = (im.w * k - W) / 2.0;
    oy = (im.h * k - H) / 2.0;

    out = malloc((size_t)W * H * 4);
    xmap = malloc(sizeof(int) * W);
    if (!out || !xmap) { free(out); free(xmap); free(im.rgb); return NULL; }
    for (uint32_t x = 0; x < W; x++) {
        int sx = (int)((x + ox) / k);
        xmap[x] = sx < 0 ? 0 : (sx >= (int)im.w ? (int)im.w - 1 : sx);
    }
    p = out;
    for (uint32_t y = 0; y < H; y++) {
        int sy = (int)((y + oy) / k);
        const unsigned char *row;
        if (sy < 0) sy = 0;
        if (sy >= (int)im.h) sy = (int)im.h - 1;
        row = im.rgb + (size_t)sy * im.w * 3;
        for (uint32_t x = 0; x < W; x++, p++) {
            const unsigned char *c = row + (size_t)xmap[x] * 3;
            uint32_t r = c[0], g = c[1], b = c[2];
            *p = bgr ? (r << 16 | g << 8 | b) : (b << 16 | g << 8 | r);
        }
    }
    free(xmap);
    free(im.rgb);
    return out;
}

/* ---------- 효과음: WAV 합성 후 aplay로 재생 ---------- */
static const char *sfx_names[SFX_COUNT] = { "start", "click", "menu", "error", "shutdown" };
static char sfx_dir[160];
static int sfx_ready, sfx_on = 1;

static void put16(FILE *f, uint32_t v) { fputc(v & 0xFF, f); fputc((v >> 8) & 0xFF, f); }
static void put32(FILE *f, uint32_t v) { put16(f, v & 0xFFFF); put16(f, v >> 16); }

static int write_wav(const char *path, const float *s, uint32_t n)
{
    FILE *f = fopen(path, "wb");
    if (!f) return -1;
    fwrite("RIFF", 1, 4, f); put32(f, 36 + n * 2);
    fwrite("WAVEfmt ", 1, 8, f); put32(f, 16);
    put16(f, 1);                 /* PCM */
    put16(f, 1);                 /* 모노 */
    put32(f, SFX_RATE);
    put32(f, SFX_RATE * 2);      /* 바이트 속도 */
    put16(f, 2);                 /* 블록 정렬 */
    put16(f, 16);                /* 비트 */
    fwrite("data", 1, 4, f); put32(f, n * 2);
    for (uint32_t i = 0; i < n; i++) {
        float v = s[i];
        int16_t q;
        if (v > 1.0f) v = 1.0f;
        if (v < -1.0f) v = -1.0f;
        q = (int16_t)(v * 30000.0f);
        put16(f, (uint16_t)q);
    }
    return fclose(f) == 0 ? 0 : -1;
}

/* 시작 t0초에 길이 dur초의 사인파(감쇠 포함)를 더한다 */
static void tone(float *s, uint32_t n, double t0, double dur, double freq, double amp, double decay)
{
    uint32_t i0 = (uint32_t)(t0 * SFX_RATE), len = (uint32_t)(dur * SFX_RATE);
    for (uint32_t i = 0; i < len && i0 + i < n; i++) {
        double t = (double)i / SFX_RATE;
        double env = exp(-decay * t) * (t < 0.003 ? t / 0.003 : 1.0);   /* 짧은 가장자리로 클릭음 방지 */
        s[i0 + i] += (float)(amp * env * sin(2.0 * M_PI * freq * t));
    }
}

void sfx_init(void)
{
    static const double lens[SFX_COUNT] = { 1.0, 0.06, 0.22, 0.55, 0.9 };
    char path[256];
    snprintf(sfx_dir, sizeof sfx_dir, "%s/sfx", RICEOS_RUN_DIR);
    mkdir(RICEOS_RUN_DIR, 0755);
    mkdir(sfx_dir, 0755);
    if (access(sfx_dir, W_OK) != 0) {               /* /run을 쓸 수 없으면 임시 폴더 */
        snprintf(sfx_dir, sizeof sfx_dir, "/tmp/riceos-sfx");
        mkdir(sfx_dir, 0755);
    }
    for (int k = 0; k < SFX_COUNT; k++) {
        uint32_t n = (uint32_t)(lens[k] * SFX_RATE);
        float *s = calloc(n, sizeof(float));
        if (!s) return;
        switch (k) {
        case SFX_START:   /* 시작음: C5 E5 G5 C6 (아르페지오) */
            tone(s, n, 0.00, 0.5, 523.25, 0.25, 6); tone(s, n, 0.14, 0.5, 659.25, 0.25, 6);
            tone(s, n, 0.28, 0.5, 783.99, 0.25, 6); tone(s, n, 0.42, 0.55, 1046.5, 0.28, 5);
            break;
        case SFX_CLICK:   /* 짧은 틱 */
            tone(s, n, 0.0, 0.05, 1400, 0.35, 60);
            break;
        case SFX_MENU:    /* 메뉴 열림: 위로 올라가는 두 음 */
            tone(s, n, 0.00, 0.08, 784, 0.3, 25); tone(s, n, 0.06, 0.14, 1175, 0.3, 20);
            break;
        case SFX_ERROR:   /* 오류: 낮은 두 음 */
            tone(s, n, 0.00, 0.18, 330, 0.4, 8); tone(s, n, 0.20, 0.30, 262, 0.4, 5);
            break;
        case SFX_SHUTDOWN:/* 종료: 내려가는 음 */
            tone(s, n, 0.00, 0.40, 1046.5, 0.28, 6); tone(s, n, 0.15, 0.40, 783.99, 0.28, 6);
            tone(s, n, 0.30, 0.40, 659.25, 0.28, 6); tone(s, n, 0.45, 0.42, 523.25, 0.28, 5);
            break;
        default: break;
        }
        snprintf(path, sizeof path, "%s/%s.wav", sfx_dir, sfx_names[k]);
        write_wav(path, s, n);
        free(s);
    }
    sfx_ready = 1;
}

void sfx_enable(int on) { sfx_on = on != 0; }

/* aplay 의 오류 출력은 /run/riceos/sfx.log 에 남긴다 (소리가 안 날 때 원인을 볼 수 있게) */
static void sfx_log_fd(int fd)
{
    char log[300];
    int lg;
    snprintf(log, sizeof log, "%s/sfx.log", RICEOS_RUN_DIR);
    lg = open(log, O_WRONLY | O_CREAT | O_APPEND, 0644);
    if (lg >= 0) { dup2(lg, fd); close(lg); }
    else { int nul = open("/dev/null", O_RDWR); if (nul >= 0) { dup2(nul, fd); close(nul); } }
}

void sfx_play(sfx_t s)
{
    char path[320];
    pid_t p;
    if (!sfx_ready || !sfx_on || s < 0 || s >= SFX_COUNT) return;
    snprintf(path, sizeof path, "%s/%s.wav", sfx_dir, sfx_names[s]);
    /* 이중 포크: 중간 자식은 바로 끝나서 waitpid로 거두고, aplay는 init이 맡는다.
     * (SA_NOCLDWAIT를 쓰면 job.c의 waitpid가 깨지므로 쓰지 않는다) */
    p = fork();
    if (p == 0) {
        if (fork() == 0) {
            int nul = open("/dev/null", O_RDWR);
            if (nul >= 0) { dup2(nul, 0); dup2(nul, 1); close(nul); }
            sfx_log_fd(2);
            execlp("aplay", "aplay", "-q", path, (char *)0);
            _exit(127);
        }
        _exit(0);
    }
    if (p > 0) {
        int st;
        while (waitpid(p, &st, 0) < 0 && errno == EINTR) ;
    }
}

/* 부팅 시작음: 사운드 카드가 준비될 때까지 기다린 뒤(최대 10초) 재생한다.
 * 바탕화면이 뜨는 것과 같은 시점에 울리면 장치가 아직 음소거 상태일 수 있다.
 * 기다리는 동안 화면은 멈추지 않도록 별도 셸(분리된 프로세스)에서 재생한다. */
void sfx_play_boot_once(void)
{
    char mark[300], path[320], cmd[800];
    pid_t p;
    snprintf(mark, sizeof mark, "%s/booted", RICEOS_RUN_DIR);
    if (access(mark, F_OK) == 0) return;          /* 이번 부팅에서 이미 울렸다 */
    { int fd = open(mark, O_CREAT | O_WRONLY, 0644); if (fd >= 0) close(fd); }
    if (!sfx_ready || !sfx_on) return;
    snprintf(path, sizeof path, "%s/%s.wav", sfx_dir, sfx_names[SFX_START]);
    snprintf(cmd, sizeof cmd,
             "i=0; while [ $i -lt 100 ] && [ ! -s /proc/asound/cards ]; do sleep 0.1; i=$((i+1)); done; "
             "sleep 1; echo \"boot sound: cards ready after $i ticks\" >>'%s/sfx.log'; "
             "aplay -q '%s' >>'%s/sfx.log' 2>&1",
             RICEOS_RUN_DIR, path, RICEOS_RUN_DIR);
    p = fork();
    if (p == 0) {
        if (fork() == 0) {
            int nul = open("/dev/null", O_RDWR);
            if (nul >= 0) { dup2(nul, 0); dup2(nul, 1); dup2(nul, 2); close(nul); }
            execl("/bin/sh", "sh", "-c", cmd, (char *)0);
            _exit(127);
        }
        _exit(0);
    }
    if (p > 0) {
        int st;
        while (waitpid(p, &st, 0) < 0 && errno == EINTR) ;
    }
}

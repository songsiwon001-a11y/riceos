/* RICEOS 설정 · 배경화면 · 효과음 (리눅스 전용)
 * 설정은 /etc/riceos/ui.conf 한 곳에 둔다. 메뉴와 터미널 명령(riceos wallpaper / riceos sfx)은
 * 이 파일만 고치고, 화면 쪽이 conf_changed()로 바뀐 것을 감지해 바로 반영한다.
 */
#ifndef RICEOS_MEDIA_H
#define RICEOS_MEDIA_H
#include <stdint.h>
#include <stddef.h>

/* ---------- 설정 ---------- */
typedef struct {
    char wallpaper[256];   /* "default" | "night" | "mint" | 그림 파일 경로 */
    int  sfx;              /* 1 = 효과음 켜짐 */
} ui_conf_t;

void conf_load(ui_conf_t *c);        /* 파일이 없으면 기본값 */
int  conf_save(const ui_conf_t *c);  /* 0 = 성공 */
int  conf_changed(void);             /* 마지막 확인 뒤 파일이 바뀌었으면 1 */

/* ---------- 배경화면 ---------- */
/* 기본 테마 이름이면 1을 돌려주고 색을 채운다 (그라데이션 4색: 하늘 위/아래, 초원 위/아래) */
int  wp_theme(const char *name, uint32_t *top, uint32_t *bot, uint32_t *gtop, uint32_t *gbot);
/* 현재 이름 다음의 배경화면 이름을 out에 쓴다 (테마 → 그림 파일 순서로 돈다) */
int  wp_next_name(const char *cur, char *out, size_t n);
/* 그림(PNG/BMP)을 W x H 로 꽉 채워 읽는다 (가운데 기준으로 잘라 맞춤). 실패하면 NULL.
 * 반환 버퍼는 호출한 쪽이 free 한다. bgr: gfx.h의 픽셀 배치와 같은 값 */
uint32_t *wp_load_image(const char *path, uint32_t W, uint32_t H, int bgr);

/* ---------- 효과음 ---------- */
typedef enum { SFX_START, SFX_CLICK, SFX_MENU, SFX_ERROR, SFX_SHUTDOWN, SFX_COUNT } sfx_t;

void sfx_init(void);                 /* 효과음 WAV 파일 만들기 (부팅 때 한 번) */
void sfx_enable(int on);
void sfx_play(sfx_t s);              /* 바로 돌아온다 (aplay를 따로 띄움) */
void sfx_play_boot_once(void);       /* 부팅 한 번만 시작음 */

#endif

/* RICEOS 리눅스: ELF 실행 파일 확인 */
#ifndef RICEOS_ELFINFO_H
#define RICEOS_ELFINFO_H
#include <stddef.h>

/* 반환: 0 = ELF 실행 파일, 1 = 쉘 스크립트(#!), -1 = 실행할 수 없는 파일.
 * out 에 설명을 쓰고, host_ok 는 이 컴퓨터의 CPU 종류와 맞으면 1 */
int elf_describe(const char *path, char *out, size_t sz, int *host_ok);

/* 다른 운영체제 전용 파일이면 그 OS 이름("Windows", "macOS", "Android", "MS-DOS"),
 * 아니면 NULL */
const char *foreign_os(const char *path);

#endif

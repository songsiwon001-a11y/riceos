#!/bin/sh
# RICEOS 라이브러리 자동 준비: zlib, libpng 를 받아 검증하고 정적 라이브러리로 빌드한다.
# 결과: deps/prefix/include, deps/prefix/lib  (build.sh가 자동으로 사용)
# 사용: sh deps/fetch_build.sh [--force]    (--force: 이미 빌드된 것도 다시 빌드)
set -eu

DEPS="$(cd "$(dirname "$0")" && pwd)"
. "$DEPS/versions.conf"
PREFIX="$DEPS/prefix"
CACHE="$DEPS/cache"
WORK="$DEPS/work"
FORCE=0
[ "${1:-}" = "--force" ] && FORCE=1
JOBS=$(nproc 2>/dev/null || echo 2)

log() { printf '[deps] %s\n' "$*"; }
die() { printf '[deps] 오류: %s\n' "$*" >&2; exit 1; }

# $1 파일 이름, $2 URL 목록. 캐시에 있으면 받지 않는다.
download() {
    dest="$CACHE/$1"
    [ -f "$dest" ] && return 0
    for u in $2; do
        log "다운로드: $u"
        if command -v curl >/dev/null 2>&1; then
            if curl -fsSL --retry 3 --connect-timeout 20 -o "$dest.part" "$u"; then
                mv "$dest.part" "$dest"; return 0
            fi
        elif command -v wget >/dev/null 2>&1; then
            if wget -q -O "$dest.part" "$u"; then
                mv "$dest.part" "$dest"; return 0
            fi
        else
            die "curl 또는 wget이 필요합니다 (sudo apt install curl)"
        fi
        rm -f "$dest.part"
    done
    return 1
}

# $1 파일, $2 기대 SHA256 (비어 있으면 값만 출력)
verify() {
    actual=$(sha256sum "$1" | cut -d' ' -f1)
    if [ -z "$2" ]; then
        log "SHA256 (아직 고정 안 됨): $actual"
        log "  → deps/versions.conf 의 SHA256 항목에 적으면 이후 변조를 막을 수 있습니다."
    elif [ "$actual" != "$2" ]; then
        rm -f "$1"
        die "SHA256 불일치: $(basename "$1") 기대 $2 / 실제 $actual (파일을 삭제했습니다)"
    else
        log "SHA256 확인 완료: $(basename "$1")"
    fi
}

# $1 이름, $2 URL 목록, $3 SHA256, $4 파일 이름
fetch() {
    download "$4" "$2" || die "$1 다운로드 실패. 인터넷 연결이나 deps/versions.conf 의 URL을 확인하세요."
    verify "$CACHE/$4" "$3"
}

# $1 폴더 이름(압축 해제 결과), $2 파일 이름
extract() {
    rm -rf "$WORK/$1"
    mkdir -p "$WORK"
    tar -xf "$CACHE/$2" -C "$WORK" || die "압축 해제 실패: $2"
}

build_zlib() {
    stamp="$PREFIX/.stamp-zlib-$ZLIB_VERSION"
    if [ "$FORCE" = 0 ] && [ -f "$stamp" ]; then log "zlib $ZLIB_VERSION: 이미 빌드됨"; return 0; fi
    fetch zlib "$ZLIB_URLS" "$ZLIB_SHA256" "zlib-$ZLIB_VERSION.tar.gz"
    extract "zlib-$ZLIB_VERSION" "zlib-$ZLIB_VERSION.tar.gz"
    log "zlib $ZLIB_VERSION 설정 · 컴파일 (정적)"
    ( cd "$WORK/zlib-$ZLIB_VERSION" &&
      ./configure --static --prefix="$PREFIX" > configure.log 2>&1 ) || { tail -30 "$WORK/zlib-$ZLIB_VERSION/configure.log"; die "zlib configure 실패"; }
    ( cd "$WORK/zlib-$ZLIB_VERSION" && make -j"$JOBS" > build.log 2>&1 ) || { tail -40 "$WORK/zlib-$ZLIB_VERSION/build.log"; die "zlib 컴파일 실패"; }
    ( cd "$WORK/zlib-$ZLIB_VERSION" && make install > install.log 2>&1 ) || die "zlib 설치 실패"
    touch "$stamp"
    log "zlib $ZLIB_VERSION: 완료"
}

build_libpng() {
    stamp="$PREFIX/.stamp-libpng-$LIBPNG_VERSION"
    if [ "$FORCE" = 0 ] && [ -f "$stamp" ]; then log "libpng $LIBPNG_VERSION: 이미 빌드됨"; return 0; fi
    fetch libpng "$LIBPNG_URLS" "$LIBPNG_SHA256" "libpng-$LIBPNG_VERSION.tar.xz"
    extract "libpng-$LIBPNG_VERSION" "libpng-$LIBPNG_VERSION.tar.xz"
    log "libpng $LIBPNG_VERSION 설정 · 컴파일 (정적, zlib 연결)"
    ( cd "$WORK/libpng-$LIBPNG_VERSION" &&
      CPPFLAGS="-I$PREFIX/include" LDFLAGS="-L$PREFIX/lib" \
      ./configure --prefix="$PREFIX" --disable-shared --enable-static > configure.log 2>&1 ) || { tail -30 "$WORK/libpng-$LIBPNG_VERSION/configure.log"; die "libpng configure 실패"; }
    ( cd "$WORK/libpng-$LIBPNG_VERSION" && make -j"$JOBS" > build.log 2>&1 ) || { tail -40 "$WORK/libpng-$LIBPNG_VERSION/build.log"; die "libpng 컴파일 실패"; }
    ( cd "$WORK/libpng-$LIBPNG_VERSION" && make install > install.log 2>&1 ) || die "libpng 설치 실패"
    touch "$stamp"
    log "libpng $LIBPNG_VERSION: 완료"
}

mkdir -p "$PREFIX" "$CACHE" "$WORK"
build_zlib
build_libpng

[ -f "$PREFIX/lib/libz.a" ] && [ -f "$PREFIX/lib/libpng16.a" ] || die "설치 결과에 정적 라이브러리가 없습니다"
log "준비 완료: $PREFIX"

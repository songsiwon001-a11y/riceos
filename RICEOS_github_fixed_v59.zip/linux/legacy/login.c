/* RICEOS 로그인: 비밀번호 확인.
 * 파일 /etc/riceos/login 한 줄: "솔트:해시"
 *   해시 = SHA-256(솔트 문자열 + 비밀번호), 소문자 16진수 64자
 * 처음 실행 때 화면에서 비밀번호를 정하면 이 파일이 만들어진다. 아이디는 Admin (고정).
 * 바꾸기: sudo riceos-setpw
 * 테스트용으로 환경 변수 RICEOS_LOGIN_FILE 로 다른 파일을 가리킬 수 있다. */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <errno.h>
#include <sys/stat.h>
#include <sys/types.h>
#include "login.h"

#define LOGIN_FILE "/etc/riceos/login"

static const char *login_path(void)
{
    const char *p = getenv("RICEOS_LOGIN_FILE");
    return p && *p ? p : LOGIN_FILE;
}

int login_configured(void)
{
    FILE *f = fopen(login_path(), "r");
    if (!f) return 0;
    fclose(f);
    return 1;
}

/* ---------- SHA-256 (FIPS 180-4) ---------- */
static const uint32_t K[64] = {
    0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5,
    0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174,
    0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc, 0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da,
    0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967,
    0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
    0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070,
    0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3,
    0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208, 0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2
};

static uint32_t rotr(uint32_t x, int n) { return (x >> n) | (x << (32 - n)); }

static void sha256_block(uint32_t h[8], const unsigned char *p)
{
    uint32_t w[64], a, b, c, d, e, f, g, hh;
    for (int i = 0; i < 16; i++)
        w[i] = (uint32_t)p[4 * i] << 24 | (uint32_t)p[4 * i + 1] << 16 |
               (uint32_t)p[4 * i + 2] << 8 | (uint32_t)p[4 * i + 3];
    for (int i = 16; i < 64; i++) {
        uint32_t s0 = rotr(w[i - 15], 7) ^ rotr(w[i - 15], 18) ^ (w[i - 15] >> 3);
        uint32_t s1 = rotr(w[i - 2], 17) ^ rotr(w[i - 2], 19) ^ (w[i - 2] >> 10);
        w[i] = w[i - 16] + s0 + w[i - 7] + s1;
    }
    a = h[0]; b = h[1]; c = h[2]; d = h[3]; e = h[4]; f = h[5]; g = h[6]; hh = h[7];
    for (int i = 0; i < 64; i++) {
        uint32_t S1 = rotr(e, 6) ^ rotr(e, 11) ^ rotr(e, 25);
        uint32_t ch = (e & f) ^ (~e & g);
        uint32_t t1 = hh + S1 + ch + K[i] + w[i];
        uint32_t S0 = rotr(a, 2) ^ rotr(a, 13) ^ rotr(a, 22);
        uint32_t maj = (a & b) ^ (a & c) ^ (b & c);
        uint32_t t2 = S0 + maj;
        hh = g; g = f; f = e; e = d + t1;
        d = c; c = b; b = a; a = t1 + t2;
    }
    h[0] += a; h[1] += b; h[2] += c; h[3] += d; h[4] += e; h[5] += f; h[6] += g; h[7] += hh;
}

static void sha256(const unsigned char *msg, size_t len, unsigned char out[32])
{
    uint32_t h[8] = { 0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a,
                      0x510e527f, 0x9b05688c, 0x1f83d9ab, 0x5be0cd19 };
    unsigned char tail[128];
    const unsigned char *p = msg;
    size_t n = len, total;
    uint64_t bits = (uint64_t)len * 8;
    while (n >= 64) { sha256_block(h, p); p += 64; n -= 64; }
    memset(tail, 0, sizeof tail);
    memcpy(tail, p, n);
    tail[n] = 0x80;
    total = n < 56 ? 64 : 128;
    for (int i = 0; i < 8; i++) tail[total - 1 - i] = (unsigned char)(bits >> (8 * i));
    sha256_block(h, tail);
    if (total == 128) sha256_block(h, tail + 64);
    for (int i = 0; i < 8; i++) {
        out[4 * i] = (unsigned char)(h[i] >> 24);
        out[4 * i + 1] = (unsigned char)(h[i] >> 16);
        out[4 * i + 2] = (unsigned char)(h[i] >> 8);
        out[4 * i + 3] = (unsigned char)h[i];
    }
}

/* 솔트 + 비밀번호의 SHA-256 을 hex 문자열로 */
static void hash_hex(const char *salt, const char *pw, char hex[65])
{
    char msg[160];
    unsigned char dig[32];
    size_t sl = strlen(salt), pl = strlen(pw);
    if (sl + pl >= sizeof msg) { hex[0] = 0; return; }
    memcpy(msg, salt, sl);
    memcpy(msg + sl, pw, pl);
    sha256((const unsigned char *)msg, sl + pl, dig);
    for (int i = 0; i < 32; i++) sprintf(hex + 2 * i, "%02x", dig[i]);
}

int login_check(const char *pw)
{
    char line[200], hex[65];
    FILE *f = fopen(login_path(), "r");
    char *colon, *hash, *nl;
    if (!f) return 0;
    if (!fgets(line, sizeof line, f)) { fclose(f); return 0; }
    fclose(f);
    colon = strchr(line, ':');
    if (!colon) return 0;
    *colon = 0;
    hash = colon + 1;
    nl = strchr(hash, '\n');
    if (nl) *nl = 0;
    if (!*line || !*pw) return 0;
    hash_hex(line, pw, hex);
    return hex[0] && strcmp(hex, hash) == 0;
}

/* 처음 설정: 임의 솔트를 만들어 "솔트:해시" 파일을 쓴다 (0600). 성공하면 1 */
int login_setup(const char *pw)
{
    unsigned char r[8];
    char salt[17], hex[65];
    FILE *u, *f;
    if (!*pw) return 0;
    u = fopen("/dev/urandom", "rb");
    if (!u || fread(r, 1, sizeof r, u) != sizeof r) { if (u) fclose(u); return 0; }
    fclose(u);
    for (int i = 0; i < 8; i++) sprintf(salt + 2 * i, "%02x", r[i]);
    hash_hex(salt, pw, hex);
    if (!hex[0]) return 0;
    if (!getenv("RICEOS_LOGIN_FILE")) mkdir("/etc/riceos", 0700);   /* 이미 있으면 무시 */
    f = fopen(login_path(), "w");
    if (!f) return 0;
    fprintf(f, "%s:%s\n", salt, hex);
    fclose(f);
    chmod(login_path(), 0600);
    return 1;
}

/* RICEOS 로그인 (리눅스): 비밀번호 확인. 자세한 내용은 login.c 참고 */
#ifndef RICEOS_LOGIN_H
#define RICEOS_LOGIN_H

/* /etc/riceos/login 파일이 있으면 1 (있을 때만 로그인 화면을 켠다) */
int login_configured(void);
/* 비밀번호가 맞으면 1 */
int login_check(const char *pw);
/* 처음 설정: 비밀번호를 저장한다. 성공하면 1 */
int login_setup(const char *pw);

#endif

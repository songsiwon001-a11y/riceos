/* RICEOS 모니터 출력 (DRM/KMS)
 * 흐름: /dev/dri/cardN 열기 → 커넥터(HDMI/DP/VGA...) 찾기 → 출력마다 CRTC와 선호 모드 배정
 *       → 출력마다 덤 버퍼 만들기 → 출력마다 SETCRTC (각자 자기 주사율로 켜짐)
 * 화면 그리기: display_present가 기준 화면을 각 모니터 버퍼에 복사한다 (크기가 다르면 확대/축소).
 */
#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <errno.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <sys/mman.h>
#include <drm/drm.h>
#include <drm/drm_mode.h>
#include "display.h"

#define MAXOUT  8
#define MAXCARD 8
#define CONN_CONNECTED 1   /* 커널 connector_status: 1 = connected (UAPI에는 이름이 없음) */

static int dfd = -1;                  /* DRM 장치 파일 */
static display_out_t outs[MAXOUT];
static int nout;

/* 변한 부분만 보내기 위한 상태.
 * - prev_px: 지난번에 모니터로 보낸 화면
 * - tdirty: 64x64 칸마다 이번에 바뀌었는지
 * - scale_x / runs: 크기가 다른 모니터용 x 좌표표와, 같은 칸 열끼리 묶은 구간 */
#define TILE 64
typedef struct { uint32_t x0, x1, tx; } run_t;

static uint32_t *prev_px;
static uint32_t prev_w, prev_h, tw, th;
static uint8_t *tdirty;
static uint32_t last_ow[MAXOUT], last_oh[MAXOUT];
static uint32_t *last_map[MAXOUT];
static uint32_t *scale_x[MAXOUT];
static uint32_t scale_w[MAXOUT], scale_sw[MAXOUT];
static run_t *runs[MAXOUT];
static uint32_t nruns[MAXOUT];

static void scale_free(void)
{
    for (int i = 0; i < MAXOUT; i++) {
        free(scale_x[i]);
        free(runs[i]);
        scale_x[i] = NULL;
        runs[i] = NULL;
        scale_w[i] = scale_sw[i] = nruns[i] = 0;
        last_ow[i] = last_oh[i] = 0;
        last_map[i] = NULL;
    }
    free(prev_px); prev_px = NULL;
    free(tdirty); tdirty = NULL;
    prev_w = prev_h = 0;
}
static uint64_t last_sig, cur_sig;    /* 연결 상태 지문: 바뀌면 다시 설정 */

struct res {
    uint32_t *crtcs, *conns, *encs;
    uint32_t ncrtc, nconn, nenc;
};

static int xioctl(int fd, unsigned long req, void *arg)
{
    int r;
    do r = ioctl(fd, req, arg); while (r < 0 && errno == EINTR);
    return r;
}

static const char *type_label(uint32_t t)
{
    switch (t) {
    case DRM_MODE_CONNECTOR_VGA:        return "VGA";
    case DRM_MODE_CONNECTOR_DVII:
    case DRM_MODE_CONNECTOR_DVID:
    case DRM_MODE_CONNECTOR_DVIA:       return "DVI";
    case DRM_MODE_CONNECTOR_HDMIA:
    case DRM_MODE_CONNECTOR_HDMIB:      return "HDMI";
    case DRM_MODE_CONNECTOR_DisplayPort:return "DP";
    case DRM_MODE_CONNECTOR_eDP:        return "eDP";
    case DRM_MODE_CONNECTOR_LVDS:       return "LVDS";
    default:                            return "OUT";
    }
}

/* 출력 하나를 끈다: 주사 끄기 → 프레임버퍼 해제 → 매핑 해제 → 덤 버퍼 삭제 */
static void drop_out(display_out_t *o)
{
    if (dfd >= 0 && o->crtc_id) {
        struct drm_mode_crtc cr = {0};
        cr.crtc_id = o->crtc_id;          /* fb 0, 연결 없음 = 끄기 */
        xioctl(dfd, DRM_IOCTL_MODE_SETCRTC, &cr);
    }
    if (dfd >= 0 && o->fb_id) {
        uint32_t id = o->fb_id;
        xioctl(dfd, DRM_IOCTL_MODE_RMFB, &id);
    }
    if (o->map) munmap(o->map, o->size);
    if (dfd >= 0 && o->handle) {
        struct drm_mode_destroy_dumb dd = {0};
        dd.handle = o->handle;
        xioctl(dfd, DRM_IOCTL_MODE_DESTROY_DUMB, &dd);
    }
    memset(o, 0, sizeof *o);
}

/* ---------- 하드웨어 커서 ---------- */
#define CUR_SIZE 64
static uint32_t cur_handle[MAXOUT], cur_pitch[MAXOUT];
static size_t cur_bytes[MAXOUT];
static uint32_t *cur_map[MAXOUT];

static void cursor_free(void)
{
    for (int i = 0; i < MAXOUT; i++) {
        if (cur_map[i]) munmap(cur_map[i], cur_bytes[i]);
        if (cur_handle[i] && dfd >= 0) {
            struct drm_mode_destroy_dumb dd = {0};
            dd.handle = cur_handle[i];
            xioctl(dfd, DRM_IOCTL_MODE_DESTROY_DUMB, &dd);
        }
        cur_map[i] = NULL;
        cur_handle[i] = 0;
        cur_bytes[i] = 0;
        cur_pitch[i] = 0;
    }
}

static int cursor_create(int i)
{
    struct drm_mode_create_dumb cd = {0};
    struct drm_mode_map_dumb md = {0};
    cd.width = CUR_SIZE; cd.height = CUR_SIZE; cd.bpp = 32;
    if (xioctl(dfd, DRM_IOCTL_MODE_CREATE_DUMB, &cd) < 0) return -1;
    md.handle = cd.handle;
    if (xioctl(dfd, DRM_IOCTL_MODE_MAP_DUMB, &md) < 0) goto fail;
    cur_map[i] = mmap(0, cd.size, PROT_READ | PROT_WRITE, MAP_SHARED, dfd, md.offset);
    if (cur_map[i] == MAP_FAILED) { cur_map[i] = NULL; goto fail; }
    cur_handle[i] = cd.handle;
    cur_pitch[i] = cd.pitch;
    cur_bytes[i] = cd.size;
    return 0;
fail:
    {
        struct drm_mode_destroy_dumb dd = {0};
        dd.handle = cd.handle;
        xioctl(dfd, DRM_IOCTL_MODE_DESTROY_DUMB, &dd);
    }
    return -1;
}

int display_cursor_set(const uint32_t *img, int hx, int hy)
{
    if (dfd < 0 || nout == 0) return -1;
    for (int i = 0; i < nout; i++) {
        struct drm_mode_cursor2 c = {0};
        if (!cur_map[i] && cursor_create(i) < 0) return -1;
        for (uint32_t y = 0; y < CUR_SIZE; y++)
            memcpy(cur_map[i] + (size_t)y * (cur_pitch[i] / 4), img + (size_t)y * CUR_SIZE, CUR_SIZE * 4);
        c.flags = DRM_MODE_CURSOR_BO;
        c.crtc_id = outs[i].crtc_id;
        c.handle = cur_handle[i];
        c.width = CUR_SIZE; c.height = CUR_SIZE;
        c.hot_x = hx; c.hot_y = hy;
        if (xioctl(dfd, DRM_IOCTL_MODE_CURSOR2, &c) < 0) return -1;
    }
    return 0;
}

void display_cursor_move(int x, int y, uint32_t sw, uint32_t sh)
{
    if (dfd < 0 || sw == 0 || sh == 0) return;
    for (int i = 0; i < nout; i++) {
        struct drm_mode_cursor c = {0};
        if (!cur_map[i]) continue;
        c.flags = DRM_MODE_CURSOR_MOVE;
        c.crtc_id = outs[i].crtc_id;
        c.x = (int32_t)((uint64_t)x * outs[i].width / sw);
        c.y = (int32_t)((uint64_t)y * outs[i].height / sh);
        xioctl(dfd, DRM_IOCTL_MODE_CURSOR, &c);
    }
}

void display_cursor_off(void)
{
    if (dfd < 0) return;
    for (int i = 0; i < nout; i++) {
        struct drm_mode_cursor2 c = {0};
        c.flags = DRM_MODE_CURSOR_BO;
        c.crtc_id = outs[i].crtc_id;
        xioctl(dfd, DRM_IOCTL_MODE_CURSOR2, &c);
    }
    cursor_free();
}

uint32_t display_max_refresh(void)
{
    uint32_t best = 0;
    for (int i = 0; i < nout; i++)
        if (outs[i].refresh > best) best = outs[i].refresh;
    return best ? best : 60;
}

static void free_outputs(void)
{
    cursor_free();
    for (int i = 0; i < nout; i++) drop_out(&outs[i]);
    nout = 0;
}

static int get_res(struct res *r)
{
    struct drm_mode_card_res cr = {0};
    if (xioctl(dfd, DRM_IOCTL_MODE_GETRESOURCES, &cr) < 0) return -1;
    r->ncrtc = cr.count_crtcs;
    r->nconn = cr.count_connectors;
    r->nenc  = cr.count_encoders;
    r->crtcs = calloc(r->ncrtc + 1, sizeof(uint32_t));
    r->conns = calloc(r->nconn + 1, sizeof(uint32_t));
    r->encs  = calloc(r->nenc + 1, sizeof(uint32_t));
    if (!r->crtcs || !r->conns || !r->encs) return -1;

    cr = (struct drm_mode_card_res){0};
    cr.crtc_id_ptr      = (uintptr_t)r->crtcs;
    cr.connector_id_ptr = (uintptr_t)r->conns;
    cr.encoder_id_ptr   = (uintptr_t)r->encs;
    cr.count_crtcs      = r->ncrtc;
    cr.count_connectors = r->nconn;
    cr.count_encoders   = r->nenc;
    return xioctl(dfd, DRM_IOCTL_MODE_GETRESOURCES, &cr);
}

static void res_free(struct res *r)
{
    free(r->crtcs); free(r->conns); free(r->encs);
}

/* 이 커넥터에 연결할 수 있는 빈 CRTC를 찾는다 (현재 인코더 먼저, 그다음 목록) */
static uint32_t find_crtc(uint32_t enc_cur, const uint32_t *encs, uint32_t nenc,
                          const struct res *r, const char *used, uint32_t *idx)
{
    for (uint32_t k = 0; k <= nenc; k++) {
        uint32_t eid = k == 0 ? enc_cur : encs[k - 1];
        if (!eid) continue;
        struct drm_mode_get_encoder e = {0};
        e.encoder_id = eid;
        if (xioctl(dfd, DRM_IOCTL_MODE_GETENCODER, &e) < 0) continue;
        for (uint32_t j = 0; j < r->ncrtc; j++)
            if (!used[j] && (e.possible_crtcs & (1u << j))) {
                *idx = j;
                return r->crtcs[j];
            }
    }
    return 0;
}

/* 연결된 모니터 하나를 설정한다. c에는 1차 조회 결과(개수)가 들어 있다. */
static void add_output(struct drm_mode_get_connector *c, const struct res *r, char *used)
{
    display_out_t *o = &outs[nout];
    struct drm_mode_modeinfo *modes = calloc(c->count_modes ? c->count_modes : 1, sizeof *modes);
    uint32_t *encs = calloc(c->count_encoders + 1, sizeof *encs);
    uint32_t idx = 0, crtc = 0;
    int ok = 0, mi = 0;

    if (!modes || !encs) goto done;
    c->modes_ptr    = (uintptr_t)modes;
    c->encoders_ptr = (uintptr_t)encs;
    c->count_props = 0; c->props_ptr = 0; c->prop_values_ptr = 0;
    if (xioctl(dfd, DRM_IOCTL_MODE_GETCONNECTOR, c) < 0 || c->count_modes == 0) goto done;

    /* 모니터가 알려 준 기본(선호) 모드를 쓴다. 없으면 첫 번째 모드 */
    for (uint32_t m = 0; m < c->count_modes; m++)
        if (modes[m].type & DRM_MODE_TYPE_PREFERRED) { mi = (int)m; break; }

    crtc = find_crtc(c->encoder_id, encs, c->count_encoders, r, used, &idx);
    if (!crtc) goto done;

    struct drm_mode_modeinfo *m = &modes[mi];
    o->connector_id = c->connector_id;
    o->crtc_id = crtc;
    o->mode = *m;
    o->width = m->hdisplay;
    o->height = m->vdisplay;
    o->refresh = m->vrefresh;
    snprintf(o->name, sizeof o->name, "%s-%u", type_label(c->connector_type), c->connector_type_id);

    struct drm_mode_create_dumb cd = {0};
    cd.width = o->width; cd.height = o->height; cd.bpp = 32;
    if (xioctl(dfd, DRM_IOCTL_MODE_CREATE_DUMB, &cd) < 0) goto fail;
    o->handle = cd.handle; o->pitch = cd.pitch; o->size = cd.size;

    struct drm_mode_map_dumb md = {0};
    md.handle = cd.handle;
    if (xioctl(dfd, DRM_IOCTL_MODE_MAP_DUMB, &md) < 0) goto fail;
    o->map = mmap(0, cd.size, PROT_READ | PROT_WRITE, MAP_SHARED, dfd, md.offset);
    if (o->map == MAP_FAILED) { o->map = 0; goto fail; }

    struct drm_mode_fb_cmd fc = {0};
    fc.width = o->width; fc.height = o->height; fc.pitch = o->pitch;
    fc.bpp = 32; fc.depth = 24; fc.handle = cd.handle;
    if (xioctl(dfd, DRM_IOCTL_MODE_ADDFB, &fc) < 0) goto fail;
    o->fb_id = fc.fb_id;

    /* 이 출력만의 모드 설정: 이 CRTC가 이 모니터의 주사율로 돈다 */
    uint32_t cid = c->connector_id;
    struct drm_mode_crtc cr = {0};
    cr.set_connectors_ptr = (uintptr_t)&cid;
    cr.count_connectors = 1;
    cr.crtc_id = crtc;
    cr.fb_id = o->fb_id;
    cr.mode_valid = 1;
    cr.mode = *m;
    if (xioctl(dfd, DRM_IOCTL_MODE_SETCRTC, &cr) < 0) goto fail;

    used[idx] = 1;
    ok = 1;
    goto done;

fail:
done:
    free(modes);
    free(encs);
    if (ok) nout++;
    else drop_out(o);
}

/* 연결 상태를 훑는다. setup이 0이면 지문(cur_sig)만 계산하고, 1이면 출력을 만든다. */
static int scan(int setup)
{
    struct res r = {0};
    uint64_t sig = 1469598103934665603ull;
    char *used;

    if (get_res(&r) < 0) { res_free(&r); cur_sig = 0; return -1; }
    used = calloc(r.ncrtc + 1, 1);
    if (!used) { res_free(&r); return -1; }

    for (uint32_t i = 0; i < r.nconn; i++) {
        struct drm_mode_get_connector c = {0};
        c.connector_id = r.conns[i];
        if (xioctl(dfd, DRM_IOCTL_MODE_GETCONNECTOR, &c) < 0) continue;
        int on = c.connection == CONN_CONNECTED;
        sig = sig * 1000003ull + c.connector_id * 2u + (on ? 1u : 0u);
        if (!setup || !on || nout >= MAXOUT) continue;
        add_output(&c, &r, used);
    }
    cur_sig = sig;
    free(used);
    res_free(&r);
    return nout;
}

int display_init(void)
{
    for (int i = 0; i < MAXCARD && nout == 0; i++) {
        char path[32];
        snprintf(path, sizeof path, "/dev/dri/card%d", i);
        int fd = open(path, O_RDWR | O_CLOEXEC);
        if (fd < 0) continue;
        dfd = fd;
        if (xioctl(dfd, DRM_IOCTL_SET_MASTER, 0) < 0) {   /* 다른 프로그램이 화면을 잡고 있으면 건너뜀 */
            close(dfd); dfd = -1;
            continue;
        }
        scan(1);
        if (nout == 0) {
            xioctl(dfd, DRM_IOCTL_DROP_MASTER, 0);
            close(dfd); dfd = -1;
            continue;
        }
        last_sig = cur_sig;
    }
    return nout > 0 ? 0 : -1;
}

void display_close(void)
{
    if (dfd < 0) return;
    free_outputs();
    scale_free();
    xioctl(dfd, DRM_IOCTL_DROP_MASTER, 0);
    close(dfd);
    dfd = -1;
}

int display_poll(void)
{
    if (dfd < 0) return 0;
    scan(0);
    if (cur_sig == last_sig) return 0;
    free_outputs();
    scan(1);
    last_sig = cur_sig;
    return 1;
}

void display_size(uint32_t *w, uint32_t *h)
{
    uint64_t best = 0;
    *w = 1024; *h = 768;
    for (int i = 0; i < nout; i++) {
        uint64_t area = (uint64_t)outs[i].width * outs[i].height;
        if (area > best) { best = area; *w = outs[i].width; *h = outs[i].height; }
    }
}

/* 바뀐 칸을 찾는다. 처음이거나 full 이면 모든 칸을 바뀐 것으로 본다. */
static void mark_dirty(const uint32_t *src, uint32_t sw, uint32_t sh, int full)
{
    uint32_t ntw = (sw + TILE - 1) / TILE, nth = (sh + TILE - 1) / TILE;
    if (!prev_px || prev_w != sw || prev_h != sh) {
        free(prev_px); free(tdirty);
        prev_px = calloc((size_t)sw * sh, 4);
        tdirty = malloc((size_t)ntw * nth);
        if (!prev_px || !tdirty) { free(prev_px); free(tdirty); prev_px = NULL; tdirty = NULL; return; }
        prev_w = sw; prev_h = sh; tw = ntw; th = nth;
        full = 1;
    }
    for (uint32_t ty = 0; ty < th; ty++) {
        uint32_t y0 = ty * TILE, y1 = y0 + TILE < sh ? y0 + TILE : sh;
        for (uint32_t tx = 0; tx < tw; tx++) {
            uint32_t x0 = tx * TILE, x1 = x0 + TILE < sw ? x0 + TILE : sw;
            size_t bytes = (size_t)(x1 - x0) * 4;
            int d = full;
            for (uint32_t y = y0; !d && y < y1; y++)
                if (memcmp(src + (size_t)y * sw + x0, prev_px + (size_t)y * sw + x0, bytes)) d = 1;
            tdirty[ty * tw + tx] = (uint8_t)d;
            if (d)
                for (uint32_t y = y0; y < y1; y++)
                    memcpy(prev_px + (size_t)y * sw + x0, src + (size_t)y * sw + x0, bytes);
        }
    }
}

/* 크기가 다른 모니터의 x 좌표표와 구간을 만든다. */
static int build_scale(int i, const display_out_t *o, uint32_t sw)
{
    uint32_t *m = realloc(scale_x[i], (size_t)o->width * sizeof *m);
    run_t *r = realloc(runs[i], (size_t)o->width * sizeof *r);
    if (!m || !r) { scale_x[i] = m; runs[i] = r; return -1; }
    scale_x[i] = m;
    runs[i] = r;
    uint32_t nr = 0;
    for (uint32_t x = 0; x < o->width; x++) {
        m[x] = (uint32_t)((uint64_t)x * sw / o->width);
        uint32_t tx = m[x] / TILE;
        if (nr == 0 || r[nr - 1].tx != tx) { r[nr].x0 = x; r[nr].x1 = x + 1; r[nr].tx = tx; nr++; }
        else r[nr - 1].x1 = x + 1;
    }
    nruns[i] = nr;
    scale_w[i] = o->width;
    scale_sw[i] = sw;
    return 0;
}

void display_present(const uint32_t *src, uint32_t sw, uint32_t sh)
{
    int full = 0;
    /* 1) 모니터가 바뀌었거나 좌표표를 새로 만들면 전체를 다시 보낸다 */
    for (int i = 0; i < nout; i++) {
        display_out_t *o = &outs[i];
        if (o->width != last_ow[i] || o->height != last_oh[i] || o->map != last_map[i]) {
            full = 1;
            last_ow[i] = o->width; last_oh[i] = o->height; last_map[i] = o->map;
        }
        if ((o->width != sw || o->height != sh) &&
            (!scale_x[i] || scale_w[i] != o->width || scale_sw[i] != sw)) {
            if (build_scale(i, o, sw) != 0) return;
            full = 1;
        }
    }
    /* 2) 기준 화면에서 바뀐 칸만 찾는다 */
    mark_dirty(src, sw, sh, full);
    if (!tdirty) return;

    uint8_t *rowdirty = malloc(th);
    if (!rowdirty) return;

    for (int i = 0; i < nout; i++) {
        display_out_t *o = &outs[i];
        uint32_t stride = o->pitch / 4;
        if (o->width == sw && o->height == sh) {
            /* 같은 크기: 바뀐 칸만 그대로 복사 */
            for (uint32_t ty = 0; ty < th; ty++) {
                uint32_t y0 = ty * TILE, y1 = y0 + TILE < sh ? y0 + TILE : sh;
                for (uint32_t tx = 0; tx < tw; tx++) {
                    if (!tdirty[ty * tw + tx]) continue;
                    uint32_t x0 = tx * TILE, x1 = x0 + TILE < sw ? x0 + TILE : sw;
                    for (uint32_t y = y0; y < y1; y++)
                        memcpy(o->map + (size_t)y * stride + x0, src + (size_t)y * sw + x0, (size_t)(x1 - x0) * 4);
                }
            }
            continue;
        }
        /* 크기가 다른 모니터: 바뀐 칸에 해당하는 출력 픽셀만 다시 계산한다 */
        const uint32_t *m = scale_x[i];
        for (uint32_t ty = 0; ty < th; ty++) {
            rowdirty[ty] = 0;
            for (uint32_t tx = 0; tx < tw; tx++) if (tdirty[ty * tw + tx]) { rowdirty[ty] = 1; break; }
        }
        for (uint32_t y = 0; y < o->height; y++) {
            uint32_t sy = (uint32_t)((uint64_t)y * sh / o->height);
            uint32_t ty = sy / TILE;
            if (!rowdirty[ty]) continue;
            const uint32_t *s = src + (size_t)sy * sw;
            uint32_t *d = o->map + (size_t)y * stride;
            for (uint32_t k = 0; k < nruns[i]; k++) {
                run_t *r = &runs[i][k];
                if (!tdirty[ty * tw + r->tx]) continue;
                for (uint32_t x = r->x0; x < r->x1; x++)
                    d[x] = s[m[x]];
            }
        }
    }
    free(rowdirty);
}

int display_count(void) { return nout; }

void display_list(display_out_fn out)
{
    char line[160];
    if (nout == 0) { out("연결된 모니터가 없습니다 (DRM)\n"); return; }
    for (int i = 0; i < nout; i++) {
        display_out_t *o = &outs[i];
        snprintf(line, sizeof line, "  %s  %ux%u @ %uHz%s\n",
                 o->name, o->width, o->height, o->refresh, i == 0 ? "  (기준)" : "");
        out(line);
    }
}

/* RICEOS 리눅스: ELF 실행 파일 확인 - 비트 수, CPU 종류, 링크 방식 */
#define _GNU_SOURCE
#include <stdio.h>
#include <string.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/utsname.h>
#include "elfinfo.h"

static unsigned long long le(const unsigned char *p, int n)
{
    unsigned long long v = 0;
    for (int i = n - 1; i >= 0; i--) v = (v << 8) | p[i];
    return v;
}

static const char *machine_name(unsigned m)
{
    switch (m) {
    case 0x03: return "x86";
    case 0x3E: return "x86_64";
    case 0x28: return "arm";
    case 0xB7: return "aarch64";
    case 0xF3: return "riscv";
    default:   return "알 수 없음";
    }
}

static int host_is(const char *name)
{
    struct utsname u;
    if (uname(&u)) return 0;
    if (!strcmp(name, "x86"))
        return !strcmp(u.machine, "i386") || !strcmp(u.machine, "i686");
    return !strcmp(u.machine, name);
}

int elf_describe(const char *path, char *out, size_t sz, int *host_ok)
{
    unsigned char h[64], ph[64];
    unsigned long long phoff, phnum, phentsize, type, i;
    int fd, is64;
    int dynamic = 0;
    char interp[256] = "";
    const char *mname, *kind, *link;
    ssize_t k;

    *host_ok = 0;
    fd = open(path, O_RDONLY);
    if (fd < 0) { snprintf(out, sz, "파일을 열 수 없습니다"); return -1; }
    k = read(fd, h, sizeof h);
    if (k >= 2 && h[0] == '#' && h[1] == '!') {
        close(fd);
        snprintf(out, sz, "쉘 스크립트 (#!)");
        *host_ok = 1;
        return 1;
    }
    if (k < 52 || memcmp(h, "\177ELF", 4)) {
        close(fd);
        snprintf(out, sz, "ELF 형식이 아닙니다");
        return -1;
    }
    is64 = h[4] == 2;
    if (h[5] != 1) {
        close(fd);
        snprintf(out, sz, "빅엔디언 ELF는 지원하지 않습니다");
        return -1;
    }
    type = le(h + 16, 2);
    mname = machine_name((unsigned)le(h + 18, 2));
    if (is64) { phoff = le(h + 32, 8); phentsize = le(h + 54, 2); phnum = le(h + 56, 2); }
    else      { phoff = le(h + 28, 4); phentsize = le(h + 42, 2); phnum = le(h + 44, 2); }

    /* 프로그램 헤더: 동적 링크 여부와 인터프리터(ld-linux 등) 경로 */
    for (i = 0; i < phnum && phentsize >= 32 && phentsize <= sizeof ph; i++) {
        unsigned long long ptype, poff, pfsz;
        if (lseek(fd, (off_t)(phoff + i * phentsize), SEEK_SET) < 0) break;
        if (read(fd, ph, phentsize) != (ssize_t)phentsize) break;
        ptype = le(ph, 4);
        if (is64) { poff = le(ph + 8, 8); pfsz = le(ph + 32, 8); }
        else      { poff = le(ph + 4, 4); pfsz = le(ph + 16, 4); }
        if (ptype == 2) dynamic = 1;                    /* PT_DYNAMIC */
        if (ptype == 3 && pfsz > 0 && pfsz < sizeof interp) {  /* PT_INTERP */
            ssize_t r;
            if (lseek(fd, (off_t)poff, SEEK_SET) >= 0) {
                r = read(fd, interp, (size_t)pfsz);
                interp[r > 0 ? r : 0] = 0;
            }
        }
    }
    close(fd);

    *host_ok = host_is(mname);
    kind = type == 2 ? "실행 파일"
         : type == 3 ? (interp[0] ? "PIE 실행 파일" : "공유 라이브러리")
         : type == 1 ? "재배치 객체" : "기타";
    link = !dynamic ? "정적 링크" : (interp[0] ? "동적 링크" : "동적 링크(인터프리터 없음)");
    snprintf(out, sz, "ELF %d비트 · %s · %s · %s", is64 ? 64 : 32, mname, kind, link);
    if (interp[0]) {
        size_t left = sz - strlen(out) - 1;
        strncat(out, " · 인터프리터: ", left);
        left = sz - strlen(out) - 1;
        strncat(out, interp, left);
    }
    return 0;
}

/* 파일 머리(매직 넘버)로 다른 운영체제 실행 파일을 가려낸다 */
const char *foreign_os(const char *path)
{
    unsigned char h[256];
    int fd;
    ssize_t k;
    unsigned long long e_lfanew;
    const char *dot;

    fd = open(path, O_RDONLY);
    if (fd < 0) return NULL;
    k = read(fd, h, sizeof h);
    if (k < 4) { close(fd); return NULL; }

    /* Windows(PE)와 MS-DOS: "MZ" 헤더, 그 뒤에 PE 시그니처가 있으면 Windows */
    if (h[0] == 'M' && h[1] == 'Z') {
        const char *os = "MS-DOS";
        if (k >= 64) {
            e_lfanew = le(h + 0x3C, 4);
            if (e_lfanew > 0 && e_lfanew + 4 <= (unsigned long long)k) {
                if (!memcmp(h + e_lfanew, "PE\0\0", 4)) os = "Windows";
            } else if (e_lfanew > 0 && lseek(fd, (off_t)e_lfanew, SEEK_SET) >= 0) {
                unsigned char sig[4];
                if (read(fd, sig, 4) == 4 && !memcmp(sig, "PE\0\0", 4)) os = "Windows";
            }
        }
        close(fd);
        return os;
    }
    /* macOS: Mach-O 매직 (32/64비트, 리틀/빅 엔디언, 유니버설) */
    if ((h[0] == 0xCF && h[1] == 0xFA && h[2] == 0xED && h[3] == 0xFE) ||
        (h[0] == 0xCE && h[1] == 0xFA && h[2] == 0xED && h[3] == 0xFE) ||
        (h[0] == 0xFE && h[1] == 0xED && h[2] == 0xFA && (h[3] == 0xCE || h[3] == 0xCF)) ||
        (h[0] == 0xCA && h[1] == 0xFE && h[2] == 0xBA && h[3] == 0xBE)) {
        close(fd);
        return "macOS";
    }
    close(fd);
    /* Android: DEX 파일, 또는 확장자 .apk 인 ZIP */
    if (!memcmp(h, "dex\n", 4)) return "Android";
    dot = strrchr(path, '.');
    if (dot && !strcmp(dot, ".apk") && !memcmp(h, "PK\x03\x04", 4)) return "Android";
    return NULL;
}

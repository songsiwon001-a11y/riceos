#!/bin/sh
# Debian 12 (bookworm) netinst 설치 이미지 내려받기 + SHA512 검증
# 사용: ./fetch_debian.sh [저장 폴더]   (인터넷 필요, 약 700MB)
set -e
DIR="${1:-.}"
BASE="https://cdimage.debian.org/debian-cd/current/amd64/iso-cd"
ISO=$(curl -fsSL "$BASE/SHA512SUMS" | awk '/netinst\.iso$/ {print $2; exit}')
[ -n "$ISO" ] || { echo "ISO 이름을 찾지 못했습니다"; exit 1; }
mkdir -p "$DIR" && cd "$DIR"
curl -fL -C - -o "$ISO" "$BASE/$ISO"
curl -fsSL -o SHA512SUMS "$BASE/SHA512SUMS"
grep " $ISO\$" SHA512SUMS | sha512sum -c -
echo "검증 완료: $DIR/$ISO"

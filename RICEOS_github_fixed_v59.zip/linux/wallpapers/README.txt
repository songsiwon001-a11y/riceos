여기에 PNG 또는 BMP 그림을 넣으면 이미지 생성 시 /usr/share/riceos/wallpapers 로 복사되어
'riceos wallpaper next' (시작 메뉴 "배경화면 바꾸기") 순환 목록에 들어갑니다.
그림은 화면 크기에 맞춰 가운데 기준으로 꽉 채워집니다.

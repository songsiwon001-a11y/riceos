# RICEOS (리눅스 기반)

Debian 13 위에서 전체 화면 RICEOS 바탕화면(`riceos-ui`)이 뜨는 USB 이미지를 만듭니다.
UEFI 응용 프로그램(`BOOTX64.EFI`)은 부트 화면 실험용이고, 실제 OS는 이쪽입니다.

## 역할 나누기 (원칙)
- **RICEOS UI (`riceos-ui.py`, GTK 4)는 화면만 맡습니다.** 목록을 그리고, 버튼을 누르면 리눅스 도구를 호출해 결과를 보여 줄 뿐입니다. 장치를 직접 만지거나 설정 파일을 직접 쓰지 않습니다.
- 나머지 일은 리눅스 도구가 합니다.

| 기능 | 화면 (riceos-ui) | 실제 일을 하는 도구 |
|---|---|---|
| 네트워크 (유선·무선) | 네트워크 | NetworkManager (`nmcli`) |
| 소리 | 소리 | PipeWire + WirePlumber (`wpctl`), 고급 설정은 `pavucontrol` |
| 디스플레이 | 디스플레이 | Xorg + xrandr (편집은 `arandr`) |
| 프린터 | 프린터 | CUPS (`lpstat`, 관리는 `system-config-printer`) |
| 시스템 정보 | 시스템 정보 | `riceos-sysinfo` (lscpu, lspci, free, lsblk) |
| 앱 | 앱 | 설치된 .desktop 항목 (`Gio.AppInfo`) |
| 개인 설정 | 개인 설정 | lxappearance, pcmanfm |
| 로그인 | 로그인 화면 (처음 설정 포함) | root 전용 헬퍼 `riceos-auth` (sudo 로만 호출, 비밀번호는 표준 입력으로) |
| 빠른 설정 | 빠른 설정 창 | NetworkManager (`nmcli`), PipeWire (`wpctl`) |

- 시스템 정보 수집 스크립트: `linux/riceos-sysinfo` (이미지에 `/usr/local/bin/riceos-sysinfo`로 설치).
- 이 README의 나머지 항목 중 일부(작업 표시줄 트레이, 단축키, 터미널 명령 `run`·`wifi`·`driver`·`mount`·`riceos ...`, 배경화면과 효과음, Chromium 자동 실행, 드라이버·무선 세부 설명)는 **framebuffer 버전(`linux/legacy/`, 이미지에 포함되지 않음)의 기능**입니다. 현재 이미지의 riceos-ui에는 아직 구현되어 있지 않습니다. 트레이 역할은 tint2(작업 표시줄)와 nm-applet, 그리고 '빠른 설정' 창이 나눠 맡습니다.

## 언어 (한국어, English, 日本語, 中文, Français, Español)
- 화면 글과 바로가기 이름이 여섯 언어로 나옵니다. 기본은 한국어입니다.
- 고르는 순서: 환경 변수 `RICEOS_LANG` → `~/.config/riceos/ui.json` → 시스템 `LANG` → 한국어.
- 바꾸기: 바탕화면의 **개인 설정** 화면에서 언어를 고르고 **언어 저장**을 누릅니다. 다시 열면 적용됩니다.
- 이미지에는 여섯 언어의 로케일(UTF-8)이 모두 만들어집니다. 글꼴은 Noto CJK(한·중·일), 나눔(한글), DejaVu(라틴 문자)가 들어 있습니다.
- 파일 이름과 Wi-Fi 이름(SSID)은 UTF-8로 읽고 쓰며, 깨진 바이트가 있어도 화면이 멈추지 않고 치환 문자로 보여 줍니다.
- 시스템 정보 화면의 항목 이름도 같은 언어로 나옵니다 (`riceos-sysinfo`).
- 한계: 한글·한자·가나를 **입력**하려면 입력기(IME)가 필요하며 이미지에는 아직 없습니다. 지금은 표시만 지원합니다. 입력란에는 영문과 숫자로 입력하세요. 콘솔 메시지(`riceos-setpw`, `riceos-auth`)는 한국어로만 나옵니다.
- 번역 검사: `python3 tests/test_ui_i18n.py` (모든 문장이 여섯 언어를 갖는지, 자리표시자가 맞는지, 인코딩과 언어 선택 순서를 검사합니다).

## 구성 (소스 파일 설명)
- `riceos-ui.py` : RICEOS UI (GTK 4). 앱 목록, 네트워크, 소리, 디스플레이, 프린터, 개인 설정, 시스템 정보, 로그인, 빠른 설정 화면. 화면만 맡고 실제 일은 리눅스 도구가 한다.
- `riceos-sysinfo` : 시스템 정보 수집 (읽기 전용 스크립트).
- `riceos-auth` : 로그인 비밀번호 저장과 확인 (root 전용, sudo 로 호출).
- `make_image.sh` : debootstrap으로 Debian + X + Openbox + NetworkManager + PipeWire + RICEOS UI 이미지 생성.
- `plymouth/` : 부팅 화면 테마 (제조사 로고 + 바 형태 로딩바).
- `wallpapers/` : 배경화면 그림 (이미지의 `/usr/share/riceos/wallpapers`로 복사).
- `fetch_debian.sh` : Debian 설치 ISO 받기.
- `legacy/` : 예전 framebuffer 버전 (`main_linux.c`, `backend.c`, `login.c`, `term.c` 등). 이미지에 포함되지 않습니다. 빌드는 `legacy/build.sh`.

## 만드는 방법 (Windows: WSL2의 Ubuntu / 리눅스 공통)
```
sudo apt install debootstrap parted dosfstools e2fsprogs util-linux
cd riceos/linux
sudo ./make_image.sh 6G   # riceos.img 생성 (인터넷 필요, 수 분 소요)
```
- 이미지 생성에는 C 컴파일러가 필요 없습니다. RICEOS UI는 Python(GTK 4)입니다.
- 예전 framebuffer 버전을 빌드하려면 `legacy/build.sh` 를 씁니다 (gcc, 최초 1회 인터넷 필요).

## 리눅스 실행 파일 실행 (새 기능)
- `run 경로 [인자]` : ELF 실행 파일을 실행합니다. 실행 전에 형식(32/64비트, CPU 종류, 동적/정적 링크)을 확인하고, 이 컴퓨터의 CPU와 맞지 않거나 실행 권한이 없으면 이유를 알려줍니다.
- `file 경로` : ELF 파일 정보만 봅니다.
- `mount 번호` : 파티션을 읽기/쓰기로 `/mnt/riceosN`에 붙입니다 (실행 허용). USB 메모리에 있는 프로그램을 쓸 때 사용합니다.
- 실행 중에는 명령 창이 멈추지 않습니다. 출력은 실시간으로 나오고, 입력 줄은 프로그램 표준 입력으로 전달됩니다.
- Ctrl+C: 실행 중인 프로그램 중단 (두 번 누르면 강제 종료). ESC는 시작 메뉴입니다.
- 권한: `chmod +x 경로` 로 실행 권한을 준 뒤 실행합니다. FAT/exFAT는 권한 개념이 없어 기본적으로 실행 가능합니다.
- 그 밖의 명령은 `/bin/sh -c`로 실행되므로 파이프(`|`)와 `;`도 사용할 수 있습니다. `cd`는 명령마다 초기화됩니다.

### 한계
- 같은 CPU 구조(x86_64)의 프로그램만 실행됩니다. ARM 등 다른 구조의 바이너리는 `file`로 확인만 됩니다.
- 프로그램은 파이프로 연결되어 있어 터미널(TTY)이 아닙니다. 색 출력이나 전체 화면 프로그램(vi, top 등)은 제대로 동작하지 않습니다.
- X11/Wayland 그래픽 프로그램은 실행되지 않습니다 (RICEOS가 /dev/fb0을 직접 씁니다).
- 동적 링크 프로그램은 필요한 라이브러리가 이미지에 있어야 합니다 (`ldd 경로`로 확인).

## 다른 운영체제 파일
Windows(.exe), macOS, Android(.apk) 등 다른 OS의 실행 파일은 실행하지 않고 "이것은 Windows 전용 파일입니다." 처럼 알려줍니다. MS-DOS(16비트 MZ) 파일도 같은 방식으로 표시합니다.

## Debian 설치 이미지 받기
`./fetch_debian.sh [폴더]` 는 Debian 12 netinst ISO를 받아 SHA512로 검증합니다 (약 700MB).

## 무선 인터넷 (Wi-Fi)
- 바탕화면의 **네트워크** 화면에서 주변 무선망 목록(신호 세기, 보안 방식)을 보고, 이름을 눌러 연결합니다. 암호가 있는 망은 암호 입력창이 뜹니다. 내부적으로는 `nmcli`를 호출합니다.
- 연결 정보와 IP 주소(DHCP)는 NetworkManager가 관리합니다. 유선은 `en*` 장치가 자동으로 DHCP를 받습니다.
- 지원 범위: WPA2/WPA3 개인용, 암호 없는 네트워크. 기업용(802.1X)은 화면에서 설정하지 않습니다.
- 한계: 암호는 `nmcli` 명령 인자로 전달되어 같은 PC의 `ps` 목록에 잠깐 보일 수 있습니다. 무선랜 칩 펌웨어는 이미지에 포함된 firmware 패키지로 제공됩니다 (칩별로 빠진 경우 apt로 추가).

## 드라이버와 펌웨어
- 이미지에는 무선랜·CPU·AMD 그래픽·사운드(SOF) 펌웨어, Mesa(OpenGL/Vulkan, VA-API 도구), ALSA, BlueZ(블루투스)가 들어 있습니다.
- 미구현: `driver` 명령(상태 보기, 설치, NVIDIA, USB 무선랜 DKMS)은 아직 없습니다. 이전 문서에 적혀 있었지만 실제 명령은 만들지 않았습니다.
- USB 무선랜(Realtek RTL8812/8821 계열 등)은 커널에 기본 드라이버가 없어서 이미지에서 인식되지 않을 수 있습니다. 이 경우 별도 드라이버를 이미지 빌드 때 넣어야 합니다 (아직 구현하지 않음).

## 임시 모드와 설치 (USB 부팅)
- **USB로 부팅하면 임시 모드**입니다. 시스템은 squashfs(읽기 전용)이고, 그 위에 RAM 오버레이를 씌웁니다 (`live-boot`). 그래서 파일을 만들거나 설정을 바꿔도 **재부팅하면 모두 사라집니다**. 바탕화면 위쪽에 임시 모드 안내가 표시됩니다.
- **저장하려면 하드디스크에 설치**해야 합니다: 바탕화면의 **RICEOS 설치** 또는 `riceos-ui --install`. 설치 화면은 임시 모드에서만 설치를 시작할 수 있습니다.
  1. 설치할 디스크를 고릅니다. 지금 부팅한 USB는 목록에 나오지 않습니다.
  2. 디스크 이름(예: `sda`, `nvme0n1`)을 정확히 입력해야 **설치** 단추가 켜집니다.
  3. 디스크를 전부 지우고 GPT 파티션(EFI 512MB + ext4 나머지)을 만든 뒤 시스템을 복사하고 UEFI 부트로더를 설치합니다.
  4. 끝나면 USB를 빼고 다시 시작합니다. 처음 부팅하면 로그인 비밀번호를 정하는 화면이 뜹니다.
- 설치 프로그램: `/usr/local/sbin/riceos-install` (`list`, `install 디스크 확인이름`). 화면은 이 스크립트를 sudo 로 부르고, 결과 줄 (`STEP`, `ERROR`, `DONE`)을 번역해서 보여 줍니다.
- 설치 안전장치: 임시 모드가 아니면 거부, 지금 부팅한 USB가 있는 디스크는 거부, 디스크 이름이 맞지 않으면 거부, 마운트된 파티션은 먼저 풉니다.
- 한계:
  - 설치는 **디스크 전체를 지웁니다.** 되돌릴 수 없습니다.
  - UEFI 부팅만 지원합니다 (BIOS/Legacy 는 아님). 보안 부팅(Secure Boot)은 설정하지 않았습니다.
  - 임시 모드의 쓰기는 RAM에 저장되므로 큰 파일을 많이 만들면 메모리가 부족해질 수 있습니다.
  - 설치된 시스템에서는 설치 화면이 디스크를 지우지 않습니다 (안내만 표시).
  - 실제 PC에서 설치를 끝까지 확인하지 못했습니다. 첫 설치는 빈 디스크로 테스트하세요.

## 로그인
- 부팅하면 로그인 화면이 먼저 뜹니다 (`riceos-ui --login`, 전체 화면이며 X 단추로 닫히지 않습니다).
- **처음 설정**: 비밀번호를 두 번 입력하면 저장됩니다. 이 비밀번호는 로그인 화면과 리눅스 계정 `riceos`(콘솔 로그인, sudo)에 같이 쓰입니다.
- 이후에는 비밀번호를 입력해 로그인합니다. 틀리면 입력칸을 비우고 다시 묻습니다.
- 비밀번호 바꾸기: 바탕화면의 **개인 설정** 화면 (현재 비밀번호 확인 후 변경), 또는 터미널에서 `sudo riceos-setpw`.
- 저장 위치: `/etc/riceos/login` (솔트와 SHA-256 해시, 권한 600, 디렉터리 700). 비밀번호 원문은 저장하지 않습니다.
- 비밀번호는 명령줄 인자가 아니라 표준 입력으로만 헬퍼(`/usr/local/sbin/riceos-auth`)에 전달됩니다. riceos 계정은 이 헬퍼 하나만 sudo 없이 부를 수 있습니다.
- 잊었을 때: 콘솔을 쓸 수 없으므로 디스크를 다른 PC에 연결해 `/etc/riceos/login`을 지우고 다시 부팅하면 처음 설정 화면이 뜹니다.
- 한계: 이것은 시작 관문입니다. 로그인 창 뒤의 Openbox 바탕화면은 Alt+Tab 등으로 접근할 수 있으므로 강한 보안 잠금이 아닙니다. 무차별 대입을 막는 횟수 제한은 아직 없습니다. 처음 설정 전에는 콘솔 로그인이 되지 않습니다 (root 계정도 잠겨 있습니다).

## 브라우저: Chromium
- Debian의 `chromium` 패키지입니다. 시작 메뉴 "Chromium 브라우저", 작업 표시줄 "Chromium" 단추, 트레이 패널 "브라우저 열기", **Alt+B** 로 엽니다. 이미지에 X 서버(Xorg), Openbox, 한글 글꼴(Noto CJK)이 들어 있습니다.
  - `riceos-chrome` 을 실행하면 RICEOS 바탕화면이 잠시 멈추고 Chromium 전체 화면이 뜹니다. Chromium을 닫으면 바탕화면으로 돌아옵니다.
  - Chromium은 `riceos` 사용자(비밀번호 `riceos`)로 실행해서 샌드박스를 유지합니다. 로그: `/var/log/riceos-x.log`
  - 한계: 세션 전환 방식이라 Chromium 실행 중에는 RICEOS 바탕화면과 트레이를 쓸 수 없습니다. 그래픽 드라이버가 fbdev 방식이라 일부 GPU에서는 화면이 안 나올 수 있습니다.

## 작업 표시줄: 트레이와 빠른 실행
- **빠른 실행 단추**: 작업 표시줄의 **터미널**, **Chromium**.
- **트레이 아이콘** (시계 왼쪽): 무선랜 신호 막대(연결되면 초록 점), 블루투스 `B`, 소리 스피커(음소거면 빨간 점). 아이콘을 누르면 패널이 열립니다.
- **트레이 패널**: Wi-Fi 켜기/끄기, 블루투스 켜기/끄기, 소리 음소거/켜기, Wi-Fi 목록 보기(터미널), 블루투스 설정(터미널), Chromium 열기.
- 무선 상태는 약 3초마다 갱신됩니다. 명령은 `riceos radio wifi|bt on|off` 로도 실행할 수 있습니다 (`rfkill`, `bluetoothctl` 사용).
- 블루투스 기기 연결(페어링)은 패널의 "블루투스 설정"으로 `bluetoothctl` 을 열어서 합니다.
- 한계: 무선 장치가 없으면 "없음"으로 표시되고, 드라이버는 `driver install` 로 설치합니다. 블루투스 페어링은 터미널에서만 됩니다.

## 단축키
| 키 | 동작 |
|---|---|
| ESC 또는 Win 키 | 시작 메뉴 열기/닫기 |
| Alt+B | Chromium 열기 |
| Alt+T | 터미널 열기 |
| Alt+W | Wi-Fi 켜기/끄기 |
| Alt+K | 블루투스 켜기/끄기 |
| Alt+M | 소리 음소거/켜기 |
| F11 | 전체 화면 전환 |
| F1 | 단축키 도움말 |
| PgUp / PgDn | 터미널: 지난 출력 보기 |

## 부팅 화면
- GRUB: 그래픽 화면을 쓰고 메뉴는 숨깁니다 (`timeout=0`). 텍스트 콘솔 대신 검은 바탕 그래픽 화면입니다.
- 커널 명령줄: `quiet splash loglevel=3 ... systemd.show_status=false` 로 콘솔 메시지를 숨깁니다.
- Plymouth 테마 `riceos` (소스: `linux/plymouth/riceos/`, 모듈 `two-step`): 펌웨어 BGRT 표의 제조사 로고를 가운데에 보여 주고, 아래 상자에 가로 로딩바를 그립니다.
- 순서: Plymouth는 `riceos-ui.service`(X 데스크톱)가 시작된 뒤에 내려갑니다. 그래서 로딩바가 중간에 끊기고 빈 화면이 나오지 않습니다.
- 로고가 없는 PC(BGRT가 없는 펌웨어, 대부분의 가상 머신)에서는 검은 화면에 로딩바만 보입니다.
- 바꾸기: `riceos.plymouth`의 `DialogVerticalAlignment`(바 위치), `progress_box.png`/`progress_bar.png`(바 그림)를 고친 뒤 `make_image.sh`를 다시 실행합니다.
- 한계: 실제 PC에서는 아직 테스트하지 않았습니다. 로고가 안 보이면 펌웨어에 BGRT가 있는지(`ls /sys/firmware/acpi/bgrt`) 먼저 확인하세요.

## 마우스, 전체 화면, 사운드
- **마우스**: 상대 이동(USB 마우스)과 절대 좌표(태블릿, 가상 머신 포인터)를 모두 지원합니다. 왼쪽 클릭으로 시작 단추, 메뉴 항목, 전체 화면 단추(□)를 누를 수 있습니다.
- **전체 화면**: 창 제목 표시줄의 □ 단추 또는 F11 키로 전환합니다. 전체 화면에서도 터미널 글자 칸 수는 96칸으로 고정입니다.
- **닫기(X)** 단추는 바탕화면을 끄지 않습니다. 끄려면 시작 메뉴의 "시스템 종료"를 쓰세요.
- **사운드**: PipeWire와 WirePlumber가 소리를 맡습니다. 바탕화면의 **소리** 화면에서 볼륨 슬라이더와 음소거를 바꾸며, 내부적으로 `wpctl`을 호출합니다. 고급 설정은 `pavucontrol`.
- **기본으로 켜져 있음**: 세션이 시작하면 `riceos-audio-init`이 음소거를 풀고 볼륨을 70%로 맞춥니다 (`wpctl`, PipeWire가 준비될 때까지 최대 20초 기다림). 부팅 때 `riceos-sound.service`도 ALSA 음소거를 풉니다 (`amixer`).
- **모니터 스피커 우선순위를 낮춤**: `/etc/wireplumber/main.lua.d/51-riceos-sound.lua`가 HDMI·DisplayPort 출력의 `priority.session`을 100으로 낮춥니다 (기본은 약 1000). 그래서 본체 소리 장치가 있으면 모니터 대신 그쪽이 기본 출력이 됩니다. 모니터만 있으면 모니터로 소리가 납니다.
- 한계: 소리 서버가 없으면 소리 화면에 그 이유가 표시됩니다. 사운드 카드 펌웨어는 이미지의 firmware 패키지에 포함되어 있습니다. 우선순위 규칙은 WirePlumber 0.4 (Lua) 형식입니다. 실제 PC에서는 아직 확인하지 못했습니다. 블루투스 스피커는 설정이 따로 필요할 수 있습니다.

## 마우스 커서 모양
- 화살표: 기본
- I 모양: 터미널 글 영역 위 (글 입력 위치를 알려 줌)
- 손 모양: 누를 수 있는 곳 (시작 단추, 메뉴 항목, □ 단추)

## USB에 쓰기
1. `riceos.img`를 Windows로 가져옵니다 (WSL: `\\wsl$\Ubuntu\...`).
2. Rufus에서 USB를 고르고 부팅 선택에 `riceos.img`를 지정해 시작합니다 (DD 이미지 모드).
   **USB 전체가 지워집니다.**
3. PC를 재부팅하고 부팅 메뉴에서 `UEFI: USB 이름`을 고릅니다.

## 사용
- 부팅하면 RICEOS 바탕화면이 뜨고 창 안에 **실제 리눅스 bash 터미널**이 열립니다. `uname -a`, `ip a`, `vim` 등 리눅스 명령을 그대로 씁니다.
- RICEOS 명령은 터미널에서 바로 입력합니다: `devices`, `volumes`, `hw`, `net`, `wifi ...`, `driver ...`, `run 경로`, `riceos ls 번호`, `riceos mount 번호`, `riceos file 경로`.
- 터미널 키: 방향키, Home/End, Delete, Tab, Ctrl+C(중단), Ctrl+D 등 일반 리눅스 키 그대로. PgUp/PgDn으로 지난 출력을 봅니다.
- ESC: 시작 메뉴 (시스템 종료 포함). vim 같은 전체 화면 프로그램이 켜져 있으면 ESC는 그 프로그램으로 갑니다.
- 비상용 콘솔: Ctrl+Alt+F2 → 아이디 `riceos`, 비밀번호는 로그인 화면에서 정한 것. root 계정은 잠겨 있습니다 (기본 비밀번호 없음).

## 배경화면과 효과음
- **배경화면** (시작 메뉴 "배경화면 바꾸기" 또는 터미널 명령)
  - `riceos wallpaper status` : 현재 배경화면
  - `riceos wallpaper next` : 기본 테마(기본, 밤, 민트)와 `/usr/share/riceos/wallpapers`의 그림을 순서대로 바꿉니다
  - `riceos wallpaper set 경로` : PNG 또는 BMP 그림을 지정합니다 (공백 없는 경로, 화면 크기에 맞춰 가운데 기준으로 채움)
  - `riceos wallpaper default` : 처음 배경으로 되돌립니다
- **효과음** (시작 메뉴 "효과음 켜기/끄기" 또는 터미널 명령)
  - `riceos sfx status|on|off|toggle` : 효과음 상태 확인과 켜기/끄기
  - `riceos sfx test` : 클릭음을 한 번 재생합니다
  - 소리: 시작음(부팅 때 한 번), 클릭, 메뉴 열기, 종료음. 음원 파일 없이 코드로 만들며 `aplay`(alsa-utils)로 재생합니다. 볼륨은 `riceos sound`로 조절합니다.
- **설정 파일**: `/etc/riceos/ui.conf` (`wallpaper=`, `sfx=`). 파일을 고치면 화면이 1초 안에 반영됩니다.
- **빌드 요구**: gcc, make, 그리고 최초 빌드 때 인터넷(curl 또는 wget, tar, xz).
  - 라이브러리 선택 순서: (1) `third_party/` 소스가 있으면 그것을 컴파일 → (2) `RICEOS_SYSTEM_LIBS=1` 이면 시스템 라이브러리 → (3) 그 밖에는 최초 1회 인터넷에서 받아 빌드 (`deps/fetch_build.sh`)
  - 주소와 SHA256 고정 값: `deps/versions.conf` (비어 있으면 받은 파일의 해시를 출력하고 계속)
  - 다시 받기: `sh deps/fetch_build.sh --force`
- **한계**: JPEG는 지원하지 않습니다 (PNG, BMP만). 그림 경로에 공백이 있으면 `set`을 쓸 수 없습니다. 효과음은 여러 소리가 겹칠 수 있고, 장치가 없으면 조용히 넘어갑니다.

## 알려진 한계
- 이미지 생성 스크립트는 작성 환경에서 실행해 보지 못했습니다. 첫 실행에서 오류가 나면 메시지를 알려주세요.
- 키보드는 영문 자판 입력만 지원합니다 (한글 입력 없음). 한글 출력은 표시됩니다.
- 화면 출력은 /dev/fb0(32비트)를 쓰므로 그래픽 드라이버가 fbdev를 제공해야 합니다 (Debian 기본 커널은 대부분 제공).

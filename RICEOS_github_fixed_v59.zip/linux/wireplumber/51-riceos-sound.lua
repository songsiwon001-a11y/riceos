-- RICEOS 기본 출력 우선순위 (WirePlumber 0.4, Debian 12). 값이 클수록 먼저 기본 출력으로 고른다.
--   1순위: USB 오디오 장치 (외장 DAC, USB 스피커/헤드셋)
--   2순위: 블루투스 헤드셋/이어폰
--   3순위: 본체 스피커 (3.5mm 잭 포함, 아날로그 출력)
--   최하위: 모니터 스피커 (HDMI, DisplayPort)
-- 참고: 3.5mm 이어폰과 본체 스피커는 같은 아날로그 출력이라 노드 이름으로는 구분되지 않는다.
-- 이 경우 둘 다 3순위다. 구분하려면 UCM 포트 설정이 필요하다.
table.insert(alsa_monitor.rules,
  {
    matches = {
      { { "node.name", "matches", "alsa_output.usb*" } },
    },
    apply_properties = { ["priority.session"] = 4000, ["priority.driver"] = 4000 },
  })
table.insert(alsa_monitor.rules,
  {
    matches = {
      { { "node.name", "matches", "bluez_output.*" } },
    },
    apply_properties = { ["priority.session"] = 3000, ["priority.driver"] = 3000 },
  })
table.insert(alsa_monitor.rules,
  {
    matches = {
      { { "node.name", "matches", "alsa_output.*analog*" } },
    },
    apply_properties = { ["priority.session"] = 2000, ["priority.driver"] = 2000 },
  })
table.insert(alsa_monitor.rules,
  {
    matches = {
      { { "node.name", "matches", "alsa_output.*hdmi*" } },
      { { "node.name", "matches", "alsa_output.*displayport*" } },
    },
    apply_properties = { ["priority.session"] = 100, ["priority.driver"] = 100 },
  })

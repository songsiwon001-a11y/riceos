#!/bin/sh
# MSYS2 MINGW64 셸에서 실행. 결과: BOOTX64.EFI
# (Bold 폰트 · 시작음 내장 / FAT·exFAT·NTFS / 윈도우 7 스타일 화면)
set -e
CC=x86_64-w64-mingw32-gcc
CFLAGS="-ffreestanding -fno-stack-protector -fno-builtin -nostdlib -Wall -Wextra -mno-red-zone -fshort-wchar -mno-stack-arg-probe"
MODS="main boot sysreq device fs fs_exfat fs_ntfs gfx ui pci net"

$CC -c riceos_font.S -o riceos_font.o
$CC -c sound_data.S  -o sound_data.o
OBJS="riceos_font.o sound_data.o"
for m in $MODS; do
  $CC $CFLAGS -c $m.c -o $m.o
  OBJS="$OBJS $m.o"
done
$CC -nostdlib -Wl,--subsystem,10 -Wl,-e,efi_main -o BOOTX64.EFI $OBJS
echo "built BOOTX64.EFI"

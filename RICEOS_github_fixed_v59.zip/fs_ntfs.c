/* NTFS 읽기 전용 드라이버
 * - 부트 섹터 -> $MFT(레코드 0) -> 레코드 번호로 파일 찾기
 * - 업데이트 시퀀스(fixup), 런 리스트(비연속 클러스터), 상주/비상주 속성
 * - 루트 디렉터리: $INDEX_ROOT + $INDEX_ALLOCATION (B-트리 노드)
 * 쓰기는 지원하지 않는다.
 */
#include "fs_ntfs.h"

#define SECT      512
#define REC_MAX   4096
#define MAX_RUNS  64

typedef struct {
    UINT32 bps;
    UINT32 cluster;   /* 클러스터 크기 */
    UINT64 mft_lcn;   /* $MFT 시작 클러스터 */
    UINT32 rec;       /* MFT 레코드 크기 */
} geo_t;

typedef struct {
    UINT64 lcn;
    UINT64 len;       /* 클러스터 수 */
    int sparse;
} run_t;

typedef struct {
    run_t r[MAX_RUNS];
    UINT32 n;
} runs_t;

typedef struct {
    int nonres;
    const UINT8 *val;  /* 상주 값 */
    UINT32 vlen;
    runs_t runs;       /* 비상주 런 리스트 */
    UINT64 real;       /* 실제 크기 */
} stream_t;

static int load_geo(const volume_t *v, geo_t *g)
{
    UINT8 b[512];
    if (vol_read(v, 0, b, sizeof(b))) return 1;
    if (!memeq_n(b + 3, "NTFS    ", 8)) return 1;
    g->bps = rd16(b + 0x0B);
    UINT32 spc = b[0x0D];
    if (g->bps < 512 || g->bps > 4096 || spc == 0) return 1;
    g->cluster = g->bps * spc;
    g->mft_lcn = rd64(b + 0x30);
    int c = (signed char)b[0x40];
    if (c > 0) g->rec = (UINT32)c * g->cluster;
    else if (c < 0 && -c <= 16) g->rec = 1u << (-c);
    else return 1;
    if (g->rec < 512 || g->rec > REC_MAX) return 1;
    return 0;
}

/* 런 리스트 해석. 헤더 바이트: 하위 4비트 = 길이 바이트 수, 상위 4비트 = 오프셋 바이트 수 */
static int decode_runs(const UINT8 *p, const UINT8 *end, runs_t *rs)
{
    INT64 lcn = 0;
    rs->n = 0;
    while (p < end && *p) {
        UINT8 h = *p++;
        UINT32 ll = h & 0x0F, ol = h >> 4;
        if (ll == 0 || ll > 8 || ol > 8 || p + ll + ol > end) return 1;

        UINT64 len = 0;
        for (UINT32 k = 0; k < ll; k++) len |= (UINT64)p[k] << (8 * k);
        p += ll;

        int sparse = (ol == 0);
        if (!sparse) {
            UINT64 off = 0;
            for (UINT32 k = 0; k < ol; k++) off |= (UINT64)p[k] << (8 * k);
            if (ol < 8 && (p[ol - 1] & 0x80)) off |= ~0ULL << (8 * ol);   /* 부호 확장 */
            lcn += (INT64)off;
            p += ol;
        }
        if (rs->n >= MAX_RUNS) return 1;
        rs->r[rs->n].lcn = sparse ? 0 : (UINT64)lcn;
        rs->r[rs->n].len = len;
        rs->r[rs->n].sparse = sparse;
        rs->n++;
    }
    return 0;
}

/* 비상주 데이터의 가상 위치 pos부터 len 바이트 읽기 */
static int vread(const volume_t *v, const geo_t *g, const runs_t *rs,
                 UINT64 pos, UINT8 *out, UINT32 len)
{
    UINT64 base = 0;
    for (UINT32 i = 0; i < rs->n && len; i++) {
        UINT64 rlen = rs->r[i].len * g->cluster;
        if (pos >= base + rlen) { base += rlen; continue; }
        UINT64 in = pos - base;
        UINT64 chunk = rlen - in;
        if (chunk > len) chunk = len;
        if (rs->r[i].sparse) {
            for (UINT64 k = 0; k < chunk; k++) out[k] = 0;
        } else if (vol_read(v, rs->r[i].lcn * g->cluster + in, out, (UINT32)chunk)) {
            return 1;
        }
        out += chunk;
        pos += chunk;
        len -= (UINT32)chunk;
        base += rlen;
    }
    return len ? 1 : 0;
}

/* 업데이트 시퀀스 복원: 각 512바이트 섹터 끝의 2바이트를 원래 값으로 되돌림 */
static int fixup(UINT8 *rec, UINT32 size)
{
    UINT32 uoff = rd16(rec + 4), ucnt = rd16(rec + 6);
    if (ucnt < 2 || uoff + 2 * ucnt > size) return 1;
    UINT8 u0 = rec[uoff], u1 = rec[uoff + 1];
    for (UINT32 i = 1; i < ucnt; i++) {
        UINT32 end = i * SECT;
        if (end > size) return 1;
        if (rec[end - 2] != u0 || rec[end - 1] != u1) return 1;
        rec[end - 2] = rec[uoff + 2 * i];
        rec[end - 1] = rec[uoff + 2 * i + 1];
    }
    return 0;
}

/* 이름 없는 속성 찾기 */
static const UINT8 *find_attr(const UINT8 *rec, UINT32 rsize, UINT32 type)
{
    UINT32 off = rd16(rec + 0x14);
    while (off + 24 <= rsize) {
        const UINT8 *a = rec + off;
        UINT32 t = rd32(a);
        UINT32 alen = rd32(a + 4);
        if (t == 0xFFFFFFFFu || alen == 0 || off + alen > rsize) break;
        if (t == type && a[9] == 0) return a;
        off += alen;
    }
    return 0;
}

static int attr_stream(const UINT8 *a, stream_t *s, runs_t *runs_out)
{
    UINT32 alen = rd32(a + 4);
    s->nonres = a[8] != 0;
    if (!s->nonres) {
        UINT32 vlen = rd32(a + 16), voff = rd16(a + 20);
        if (voff + vlen > alen) return 1;
        s->val = a + voff;
        s->vlen = vlen;
        s->real = vlen;
        return 0;
    }
    UINT32 roff = rd16(a + 32);
    if (roff >= alen) return 1;
    s->real = rd64(a + 48);
    return decode_runs(a + roff, a + alen, runs_out);
}

static int read_all(const volume_t *v, const geo_t *g, const stream_t *s, const runs_t *runs,
                    UINT8 *out, UINT32 cap, UINT32 *len)
{
    if (!s->nonres) {
        if (s->vlen > cap) return 1;
        for (UINT32 i = 0; i < s->vlen; i++) out[i] = s->val[i];
        *len = s->vlen;
        return 0;
    }
    if (s->real > cap) return 1;
    if (s->real && vread(v, g, runs, 0, out, (UINT32)s->real)) return 1;
    *len = (UINT32)s->real;
    return 0;
}

/* $MFT 자체 읽기 (레코드 0은 디스크 위치로 직접 읽는다) */
static int load_mft(const volume_t *v, const geo_t *g, runs_t *mft, UINT8 *rec)
{
    if (vol_read(v, g->mft_lcn * g->cluster, rec, g->rec)) return 1;
    if (!memeq_n(rec, "FILE", 4) || fixup(rec, g->rec)) return 1;
    const UINT8 *a = find_attr(rec, g->rec, 0x80);
    if (!a || a[8] == 0) return 1;
    return decode_runs(a + rd16(a + 32), a + rd32(a + 4), mft);
}

static int read_record(const volume_t *v, const geo_t *g, const runs_t *mft, UINT64 n, UINT8 *rec)
{
    if (vread(v, g, mft, n * g->rec, rec, g->rec)) return 1;
    if (!memeq_n(rec, "FILE", 4)) return 1;
    return fixup(rec, g->rec);
}

/* 인덱스 엔트리 순회 (루트 노드와 INDX 레코드 공통) */
typedef struct { dir_cb cb; void *ctx; } sink_t;

static void emit(const UINT8 *p, const UINT8 *end, sink_t *s)
{
    while (p + 16 <= end) {
        UINT16 elen = rd16(p + 8), klen = rd16(p + 10), flags = rd16(p + 12);
        if (elen < 16 || p + elen > end) break;
        if (flags & 0x02) break;                           /* 마지막 엔트리 */
        if (klen >= 66 && p + 16 + klen <= end) {
            const UINT8 *k = p + 16;                       /* $FILE_NAME 값 */
            UINT32 nlen = k[64], ns = k[65];
            if (ns != 2 && nlen > 0 && 66 + 2 * nlen <= klen && rd16(k + 66) != '$') {
                dirent_t de;
                UINT32 n = nlen > 255 ? 255 : nlen;
                for (UINT32 i = 0; i < n; i++) de.name[i] = rd16(k + 66 + 2 * i);
                de.name[n] = 0;
                de.is_dir = (rd32(k + 56) & 0x10000000u) != 0;
                de.size = rd64(k + 48);
                de.ref = rd64(p) & 0xFFFFFFFFFFFFULL;
                s->cb(s->ctx, &de);
            }
        }
        p += elen;
    }
}

int ntfs_probe(const volume_t *v)
{
    static UINT8 rec[REC_MAX];
    geo_t g;
    runs_t mft;
    if (load_geo(v, &g)) return 1;
    return load_mft(v, &g, &mft, rec);
}

int ntfs_list_root(const volume_t *v, dir_cb cb, void *ctx)
{
    static UINT8 rec[REC_MAX];
    static UINT8 ib[REC_MAX];
    geo_t g;
    runs_t mft;
    sink_t s = { cb, ctx };

    if (load_geo(v, &g) || load_mft(v, &g, &mft, rec)) return 1;
    if (read_record(v, &g, &mft, 5, rec)) return 1;          /* 레코드 5 = 루트 */

    /* $INDEX_ROOT: 상주 */
    const UINT8 *ir = find_attr(rec, g.rec, 0x90);
    if (!ir || ir[8]) return 1;
    UINT32 vlen = rd32(ir + 16), voff = rd16(ir + 20);
    if (voff + vlen > rd32(ir + 4)) return 1;
    const UINT8 *val = ir + voff;
    UINT32 ibsz = rd32(val + 8);
    const UINT8 *ih = val + 16;
    UINT32 eoff = rd32(ih), isz = rd32(ih + 4);
    if (eoff > isz || 16 + (UINT64)isz > vlen) return 1;
    emit(ih + eoff, ih + isz, &s);

    /* $INDEX_ALLOCATION: 비상주 INDX 레코드들 */
    const UINT8 *aa = find_attr(rec, g.rec, 0xA0);
    if (aa && aa[8] && ibsz >= SECT && ibsz <= REC_MAX) {
        stream_t as;
        runs_t ar;
        if (attr_stream(aa, &as, &ar)) return 1;
        for (UINT64 p = 0; p < as.real; p += ibsz) {
            if (vread(v, &g, &ar, p, ib, ibsz)) break;
            if (!memeq_n(ib, "INDX", 4) || fixup(ib, ibsz)) continue;
            const UINT8 *h = ib + 0x18;
            UINT32 e = rd32(h), sz = rd32(h + 4);
            if (e > sz || 0x18 + (UINT64)sz > ibsz) continue;
            emit(h + e, h + sz, &s);
        }
    }
    return 0;
}

struct finder {
    const CHAR16 *want;
    dirent_t got;
    int found;
};

static void find_cb(void *c, const dirent_t *e)
{
    struct finder *f = (struct finder *)c;
    if (!f->found && name_ieq(e->name, f->want)) {
        dirent_copy(&f->got, e);
        f->found = 1;
    }
}

int ntfs_read_root_file(const volume_t *v, const CHAR16 *name, UINT8 *out, UINT32 cap, UINT32 *len)
{
    static UINT8 rec[REC_MAX];
    geo_t g;
    runs_t mft, fr;
    stream_t s;
    struct finder f;

    if (load_geo(v, &g) || load_mft(v, &g, &mft, rec)) return 1;
    f.want = name;
    f.found = 0;
    if (ntfs_list_root(v, find_cb, &f)) return 1;
    if (!f.found || f.got.is_dir) return 1;

    if (read_record(v, &g, &mft, f.got.ref, rec)) return 1;
    const UINT8 *a = find_attr(rec, g.rec, 0x80);
    if (!a) return 1;
    if (attr_stream(a, &s, &fr)) return 1;
    return read_all(v, &g, &s, &fr, out, cap, len);
}

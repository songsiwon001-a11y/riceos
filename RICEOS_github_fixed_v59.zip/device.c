/* RICEOS 저장 장치 감지: USB, CD/DVD, 플로피, SATA, NVMe, 하드디스크 */
#include "device.h"

static EFI_GUID blockio_guid = {
    0x964e5b21, 0x6459, 0x11d2, { 0x8e, 0x39, 0x00, 0xa0, 0xc9, 0x69, 0x72, 0x3b }
};
static EFI_GUID devpath_guid = {
    0x09576e91, 0x6d3f, 0x11d2, { 0x8e, 0x39, 0x00, 0xa0, 0xc9, 0x69, 0x72, 0x3b }
};

enum { K_USB, K_CD, K_FLOPPY, K_SATA, K_NVME, K_OTHER };
static const char *kind_name[] = {
    "USB 저장장치", "광학 드라이브(CD/DVD)", "플로피 디스크",
    "SATA 디스크", "NVMe 디스크", "기타 블록 장치"
};

#define MAX_DEV 32

typedef struct {
    EFI_HANDLE handle;
    UINT8 kind;
    UINT8 present;     /* 미디어 삽입 여부 */
    UINT8 removable;
    UINT32 block;
    UINT64 blocks;
} device_t;

static EFI_BOOT_SERVICES *bs;
static device_t devs[MAX_DEV];
static UINT32 ndev;
static EFI_HANDLE raw[MAX_DEV];

/* ---- 문자열 도우미 ---- */
static char *app(char *d, const char *s)
{
    while (*s) *d++ = *s++;
    return d;
}

static char *app_u(char *d, UINT64 v)
{
    char tmp[24];
    int n = 0;
    do { tmp[n++] = (char)('0' + v % 10); v /= 10; } while (v);
    while (n) *d++ = tmp[--n];
    return d;
}

/* 장치 경로를 읽어 종류 판별 */
static UINT8 classify(EFI_HANDLE h, UINT32 block)
{
    UINT8 *p = 0;
    UINT8 kind = K_OTHER;

    if (bs->HandleProtocol(h, &devpath_guid, (void **)&p) != EFI_SUCCESS || !p)
        return K_OTHER;

    for (;;) {
        UINT8 type = p[0], sub = p[1];
        UINT16 len = (UINT16)(p[2] | (p[3] << 8));

        if (type == 0x7F) break;                       /* 경로 끝 */

        if (type == 3 && sub == 0x05)      kind = K_USB;     /* USB */
        else if (type == 3 && sub == 0x12) kind = K_SATA;    /* SATA */
        else if (type == 3 && sub == 0x17) kind = K_NVME;    /* NVMe */
        else if (type == 3 && sub == 0x01) kind = (block == 2048) ? K_CD : K_OTHER; /* ATAPI */
        else if (type == 2 && sub == 0x01) {           /* ACPI: 플로피 컨트롤러 */
            UINT32 hid = (UINT32)p[4] | ((UINT32)p[5] << 8) |
                         ((UINT32)p[6] << 16) | ((UINT32)p[7] << 24);
            if (hid == 0x41D00604u || hid == 0x41D00700u) kind = K_FLOPPY;
        }

        if (len < 4) break;
        p += len;
    }

    if (kind == K_SATA && block == 2048) kind = K_CD;  /* SATA에 물린 광학 드라이브 */
    return kind;
}

static EFI_BLOCK_IO *bio_of(EFI_HANDLE h)
{
    EFI_BLOCK_IO *bio = 0;
    if (bs->HandleProtocol(h, &blockio_guid, (void **)&bio) != EFI_SUCCESS)
        return 0;
    return bio;
}

/* 전체 Block I/O 핸들 목록 (파티션 제외) */
static UINT32 find_disks(void)
{
    UINTN size = sizeof(raw);
    UINT32 n = 0;
    if (bs->LocateHandle(EFI_LOCATE_BY_PROTOCOL, &blockio_guid, 0, &size, raw) != EFI_SUCCESS)
        return 0;
    for (UINT32 i = 0; i < size / sizeof(EFI_HANDLE); i++) {
        EFI_BLOCK_IO *bio = bio_of(raw[i]);
        if (bio && !bio->Media->LogicalPartition)
            raw[n++] = raw[i];
    }
    return n;
}

static BOOLEAN in_list(EFI_HANDLE h, EFI_HANDLE *list, UINT32 n)
{
    for (UINT32 i = 0; i < n; i++)
        if (list[i] == h) return 1;
    return 0;
}

/* 한 줄 설명 만들기: [번호] 종류  크기  상태 */
static void describe(char *buf, UINT32 index, const device_t *d)
{
    char *p = buf;
    p = app(p, "  [");
    p = app_u(p, index);
    p = app(p, "] ");
    p = app(p, kind_name[d->kind]);
    p = app(p, "  ");
    if (!d->present) {
        p = app(p, "(미디어 없음)");
    } else {
        UINT64 mb = (UINT64)d->block * (d->blocks + 1) / (1024 * 1024);
        p = app_u(p, mb);
        p = app(p, " MB");
    }
    p = app(p, d->removable ? "  [이동식]" : "  [고정]");
    *p++ = '\n';
    *p = 0;
}

static void fill_device(device_t *d, EFI_HANDLE h, EFI_BLOCK_IO *bio)
{
    d->handle    = h;
    d->block     = bio->Media->BlockSize;
    d->blocks    = bio->Media->LastBlock;
    d->removable = bio->Media->RemovableMedia;
    d->present   = bio->Media->MediaPresent;
    d->kind      = classify(h, d->block);
}

void device_init(EFI_BOOT_SERVICES *boot)
{
    bs = boot;
    ndev = 0;
    UINT32 n = find_disks();
    for (UINT32 i = 0; i < n && ndev < MAX_DEV; i++) {
        EFI_BLOCK_IO *bio = bio_of(raw[i]);
        if (!bio) continue;
        fill_device(&devs[ndev++], raw[i], bio);
    }
}

void device_list(out_fn out)
{
    char line[160];
    UINT32 n = find_disks();
    out("연결된 저장 장치:\n");
    if (n == 0) { out("  (없음)\n"); return; }
    for (UINT32 i = 0; i < n; i++) {
        EFI_BLOCK_IO *bio = bio_of(raw[i]);
        device_t d;
        if (!bio) continue;
        fill_device(&d, raw[i], bio);
        describe(line, i + 1, &d);
        out(line);
    }
}

void device_poll(out_fn out)
{
    char line[160];
    char head[64];
    UINT32 n = find_disks();

    /* 1) 분리된 장치 제거 */
    for (UINT32 i = 0; i < ndev; ) {
        if (in_list(devs[i].handle, raw, n)) { i++; continue; }
        char *p = app(head, "장치 분리: ");
        *p = 0;
        out(head);
        describe(line, i + 1, &devs[i]);
        out(line);
        for (UINT32 j = i; j + 1 < ndev; j++) devs[j] = devs[j + 1];
        ndev--;
    }

    /* 2) 새 장치 추가, 3) 미디어 삽입/제거 감지 */
    for (UINT32 i = 0; i < n; i++) {
        EFI_BLOCK_IO *bio = bio_of(raw[i]);
        UINT32 found = ndev;
        if (!bio) continue;

        for (UINT32 j = 0; j < ndev; j++)
            if (devs[j].handle == raw[i]) { found = j; break; }

        if (found == ndev) {
            if (ndev >= MAX_DEV) continue;
            fill_device(&devs[ndev], raw[i], bio);
            ndev++;
            out("새 장치 연결:\n");
            describe(line, ndev, &devs[ndev - 1]);
            out(line);
        } else {
            BOOLEAN now = bio->Media->MediaPresent;
            if (now != devs[found].present) {
                devs[found].present = now;
                fill_device(&devs[found], raw[i], bio);
                out(now ? "미디어 삽입:\n" : "미디어 제거:\n");
                describe(line, found + 1, &devs[found]);
                out(line);
            }
        }
    }
}

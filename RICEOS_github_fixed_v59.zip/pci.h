#ifndef RICEOS_PCI_H
#define RICEOS_PCI_H
#include "efi.h"
typedef void (*pci_out_fn)(const char *s);
/* PCI 장치 목록 출력 (설정 공간 포트 0xCF8/0xCFC 사용) */
void pci_list(pci_out_fn out);
#endif

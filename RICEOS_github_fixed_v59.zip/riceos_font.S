/* 폰트 바이너리를 실행 파일(.rdata)에 그대로 포함한다. */
    .section .rdata,"dr"
    .balign 16
    .globl riceos_font
riceos_font:
    .incbin "RICEOS_FONT.BIN"
    .globl riceos_font_end
riceos_font_end:

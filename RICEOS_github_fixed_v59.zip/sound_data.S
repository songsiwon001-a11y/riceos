/* 시작음 원시 PCM (22050Hz, 16bit, mono, signed little-endian) */
    .section .rdata,"dr"
    .balign 16
    .globl startup_pcm
startup_pcm:
    .incbin "startup.pcm"
    .globl startup_pcm_end
startup_pcm_end:

/* RICEOS: 직접 정의한 최소 UEFI 타입과 함수 테이블 (x86-64) */
#ifndef RICEOS_EFI_H
#define RICEOS_EFI_H

typedef unsigned char      UINT8;
typedef unsigned short     UINT16;
typedef unsigned int       UINT32;
typedef unsigned long long UINT64;
typedef UINT64             UINTN;
typedef long long          INT64;
typedef short              INT16;
typedef UINT8              BOOLEAN;
typedef UINT16             CHAR16;
typedef void              *EFI_HANDLE;
typedef UINTN              EFI_STATUS;

#define EFI_SUCCESS             0
#define EFI_BUFFER_TOO_SMALL    0x8000000000000005ULL
#define EFI_LOCATE_BY_PROTOCOL  2

typedef struct { UINT32 Data1; UINT16 Data2; UINT16 Data3; UINT8 Data4[8]; } EFI_GUID;

typedef struct {
    UINT64 Signature;
    UINT32 Revision;
    UINT32 HeaderSize;
    UINT32 CRC32;
    UINT32 Reserved;
} EFI_TABLE_HEADER;

typedef struct {
    UINT16 ScanCode;
    CHAR16 UnicodeChar;
} EFI_INPUT_KEY;

typedef struct EFI_SIMPLE_TEXT_INPUT_PROTOCOL {
    void *Reset;
    EFI_STATUS (*ReadKeyStroke)(struct EFI_SIMPLE_TEXT_INPUT_PROTOCOL *This, EFI_INPUT_KEY *Key);
    void *WaitForKey;
} EFI_SIMPLE_TEXT_INPUT_PROTOCOL;

typedef struct EFI_SIMPLE_TEXT_OUTPUT_PROTOCOL {
    void *Reset;
    void *OutputString;
    void *TestString;
    void *QueryMode;
    void *SetMode;
    void *SetAttribute;
    void *ClearScreen;
} EFI_SIMPLE_TEXT_OUTPUT_PROTOCOL;

/* EFI_BOOT_SERVICES: 38개 함수 포인터를 UEFI 명세 순서대로 나열 */
typedef struct {
    EFI_TABLE_HEADER Hdr;
    void *RaiseTPL;
    void *RestoreTPL;
    void *AllocatePages;
    void *FreePages;
    void *GetMemoryMap;
    void *AllocatePool;
    void *FreePool;
    void *CreateEvent;
    void *SetTimer;
    void *WaitForEvent;
    void *SignalEvent;
    void *CloseEvent;
    void *CheckEvent;
    void *InstallProtocolInterface;
    void *ReinstallProtocolInterface;
    void *UninstallProtocolInterface;
    EFI_STATUS (*HandleProtocol)(EFI_HANDLE Handle, EFI_GUID *Protocol, void **Interface);
    void *Reserved;
    void *RegisterProtocolNotify;
    EFI_STATUS (*LocateHandle)(UINT32 SearchType, EFI_GUID *Protocol, void *SearchKey,
                               UINTN *BufferSize, EFI_HANDLE *Buffer);
    void *LocateDevicePath;
    void *InstallConfigurationTable;
    void *LoadImage;
    void *StartImage;
    void *Exit;
    void *UnloadImage;
    void *ExitBootServices;
    void *GetNextMonotonicCount;
    EFI_STATUS (*Stall)(UINTN Microseconds);
    EFI_STATUS (*SetWatchdogTimer)(UINTN Timeout, UINT64 WatchdogCode, UINTN DataSize, CHAR16 *WatchdogData);
    void *ConnectController;
    void *DisconnectController;
    void *OpenProtocol;
    void *CloseProtocol;
    void *OpenProtocolInformation;
    void *ProtocolsPerHandle;
    void *LocateHandleBuffer;
    EFI_STATUS (*LocateProtocol)(EFI_GUID *Protocol, void *Registration, void **Interface);
} EFI_BOOT_SERVICES;

typedef struct {
    EFI_TABLE_HEADER Hdr;
    CHAR16 *FirmwareVendor;
    UINT32 FirmwareRevision;
    EFI_HANDLE ConsoleInHandle;
    EFI_SIMPLE_TEXT_INPUT_PROTOCOL *ConIn;
    EFI_HANDLE ConsoleOutHandle;
    EFI_SIMPLE_TEXT_OUTPUT_PROTOCOL *ConOut;
    EFI_HANDLE StandardErrorHandle;
    EFI_SIMPLE_TEXT_OUTPUT_PROTOCOL *StdErr;
    struct EFI_RUNTIME_SERVICES *RuntimeServices;
    EFI_BOOT_SERVICES *BootServices;
    UINTN NumberOfTableEntries;
    void *ConfigurationTable;
} EFI_SYSTEM_TABLE;

typedef struct {
    UINT32 Version;
    UINT32 HorizontalResolution;
    UINT32 VerticalResolution;
    UINT32 PixelFormat;          /* 0 = RGB, 1 = BGR */
    UINT32 PixelInformation[4];
    UINT32 PixelsPerScanLine;
} EFI_GFX_MODE_INFO;

typedef struct {
    UINT32 MaxMode;
    UINT32 Mode;
    EFI_GFX_MODE_INFO *Info;
    UINTN SizeOfInfo;
    UINT64 FrameBufferBase;
    UINTN FrameBufferSize;
} EFI_GFX_MODE;

typedef struct {
    void *QueryMode;
    void *SetMode;
    void *Blt;
    EFI_GFX_MODE *Mode;
} EFI_GRAPHICS_OUTPUT_PROTOCOL;

typedef struct {
    UINT16 Year;
    UINT8 Month, Day, Hour, Minute, Second, Pad1;
    UINT32 Nanosecond;
    INT16 TimeZone;
    UINT8 Daylight, Pad2;
} EFI_TIME;

typedef struct EFI_RUNTIME_SERVICES {
    EFI_TABLE_HEADER Hdr;
    EFI_STATUS (*GetTime)(EFI_TIME *Time, void *Capabilities);
} EFI_RUNTIME_SERVICES;

/* EFI_BLOCK_IO_PROTOCOL: USB, CD, SATA, 플로피, 하드디스크 공통 */
typedef struct {
    UINT32 MediaId;
    BOOLEAN RemovableMedia;
    BOOLEAN MediaPresent;
    BOOLEAN LogicalPartition;
    BOOLEAN ReadOnly;
    BOOLEAN WriteCaching;
    UINT32 BlockSize;
    UINT32 IoAlign;
    UINT64 LastBlock;
} EFI_BLOCK_MEDIA;

typedef struct EFI_BLOCK_IO {
    UINT64 Revision;
    EFI_BLOCK_MEDIA *Media;
    void *Reset;
    EFI_STATUS (*ReadBlocks)(struct EFI_BLOCK_IO *This, UINT32 MediaId, UINT64 Lba,
                             UINTN BufferSize, void *Buffer);
    void *WriteBlocks;
    void *FlushBlocks;
} EFI_BLOCK_IO;

/* EFI_FILE_PROTOCOL (읽기 관련 함수만 타입 지정) */
typedef struct EFI_FILE {
    UINT64 Revision;
    EFI_STATUS (*Open)(struct EFI_FILE *This, struct EFI_FILE **New, CHAR16 *Name,
                       UINT64 Mode, UINT64 Attributes);
    EFI_STATUS (*Close)(struct EFI_FILE *This);
    void *Delete;
    EFI_STATUS (*Read)(struct EFI_FILE *This, UINTN *BufferSize, void *Buffer);
    void *Write;
    void *GetPosition;
    void *SetPosition;
    void *GetInfo;
    void *SetInfo;
    void *Flush;
} EFI_FILE;

/* EFI_SIMPLE_FILE_SYSTEM_PROTOCOL: FAT12/16/32 볼륨에 펌웨어가 제공 */
typedef struct {
    UINT64 Revision;
    EFI_STATUS (*OpenVolume)(void *This, EFI_FILE **Root);
} EFI_SIMPLE_FILE_SYSTEM;

/* EFI_SIMPLE_NETWORK_PROTOCOL (펌웨어가 제공하는 랜 드라이버) */
typedef struct {
    UINT32 State, HwAddressSize, MediaHeaderSize, MaxPacketSize;
    UINT32 NvRamSize, NvRamAccessSize, ReceiveFilterMask, ReceiveFilterSetting;
    UINT32 MaxMCastFilterCount, MCastFilterCount;
    UINT8 MCastFilter[16][32];
    UINT8 CurrentAddress[32];
    UINT8 BroadcastAddress[32];
    UINT8 PermanentAddress[32];
    UINT8 IfType;
    BOOLEAN MacAddressChangeable, MultipleTxSupported, MediaPresentSupported, MediaPresent;
} EFI_SNP_MODE;

typedef struct EFI_SNP {
    UINT64 Revision;
    EFI_STATUS (*Start)(struct EFI_SNP *This);
    EFI_STATUS (*Stop)(struct EFI_SNP *This);
    EFI_STATUS (*Initialize)(struct EFI_SNP *This, UINTN ExtraRx, UINTN ExtraTx);
    void *Reset;
    void *Shutdown;
    void *ReceiveFilters;
    void *StationAddress;
    void *Statistics;
    void *MCastIpToMac;
    void *NvData;
    void *GetStatus;
    void *Transmit;
    void *Receive;
    void *WaitForPacket;
    EFI_SNP_MODE *Mode;
} EFI_SIMPLE_NETWORK_PROTOCOL;

/* EFI_LOADED_IMAGE_PROTOCOL: 이 로더가 어느 장치에서 시작됐는지 알려준다 */
typedef struct {
    UINT32 Revision;
    EFI_HANDLE ParentHandle;
    EFI_SYSTEM_TABLE *SystemTable;
    EFI_HANDLE DeviceHandle;
} EFI_LOADED_IMAGE;

/* EFI_MP_SERVICES_PROTOCOL: 활성화된 논리 프로세서 수와 코어 위치 */
typedef struct {
    UINT64 ProcessorId;
    UINT32 StatusFlag;          /* 1 = BSP, 2 = 활성화, 4 = 정상 */
    UINT32 Package, Core, Thread;
    UINT32 Extended[6];         /* 확장 위치 정보 (사용 안 함, 버퍼 여유) */
} EFI_PROCESSOR_INFORMATION;

typedef struct EFI_MP_SERVICES {
    EFI_STATUS (*GetNumberOfProcessors)(struct EFI_MP_SERVICES *This, UINTN *Total, UINTN *Enabled);
    EFI_STATUS (*GetProcessorInfo)(struct EFI_MP_SERVICES *This, UINTN Num, EFI_PROCESSOR_INFORMATION *Info);
    void *StartupAllAPs;
    void *StartupThisAP;
    void *SwitchBSP;
    void *EnableDisableAP;
    void *WhoAmI;
} EFI_MP_SERVICES;

#endif

#ifndef RICEOS_NET_H
#define RICEOS_NET_H
#include "efi.h"
typedef void (*net_out_fn)(const char *s);
/* 펌웨어 네트워크 드라이버 연결 */
void net_init(EFI_BOOT_SERVICES *bs);
/* 랜 상태와 MAC 주소 출력 */
void net_info(net_out_fn out);
#endif

#ifndef RICEOS_DEVICE_H
#define RICEOS_DEVICE_H
#include "efi.h"

typedef void (*out_fn)(const char *s);

/* 부팅 시 한 번 호출: 현재 연결된 장치를 기록 */
void device_init(EFI_BOOT_SERVICES *bs);
/* 현재 장치 목록을 출력 */
void device_list(out_fn out);
/* 주기적으로 호출: 새로 연결/분리된 장치와 미디어 변화를 출력 */
void device_poll(out_fn out);

#endif

/* PCI 장치 나열: 버스 0~255를 훑어 공급사/장치 번호와 종류를 표시 */
#include "pci.h"

static inline void outl(UINT16 port, UINT32 v)
{
    __asm__ volatile ("outl %0, %1" : : "a"(v), "Nd"(port));
}
static inline UINT32 inl(UINT16 port)
{
    UINT32 v;
    __asm__ volatile ("inl %1, %0" : "=a"(v) : "Nd"(port));
    return v;
}

static UINT32 cfg_read(UINT32 bus, UINT32 dev, UINT32 fn, UINT32 off)
{
    outl(0xCF8, 0x80000000u | (bus << 16) | (dev << 11) | (fn << 8) | (off & 0xFC));
    return inl(0xCFC);
}

static const char *class_name(UINT32 cls, UINT32 sub, UINT32 pif)
{
    switch (cls) {
    case 0x00: return "구형 장치";
    case 0x01: return sub == 0x06 ? "SATA 컨트롤러" : (sub == 0x08 ? "NVMe 컨트롤러" : "저장장치 컨트롤러");
    case 0x02: return "네트워크 어댑터";
    case 0x03: return "그래픽 컨트롤러";
    case 0x04: return sub == 0x03 ? "오디오 장치(HDA)" : "멀티미디어 장치";
    case 0x06: return sub == 0x04 ? "PCI 브리지" : "브리지";
    case 0x07: return "통신 장치";
    case 0x08: return "시스템 주변장치";
    case 0x0C:
        if (sub == 0x03) return pif == 0x30 ? "USB 3.0 컨트롤러" : (pif == 0x20 ? "USB 2.0 컨트롤러" : "USB 컨트롤러");
        return "직렬 버스 컨트롤러";
    default: return "기타 장치";
    }
}

static void put_hex(char **p, UINT32 v, int digits)
{
    static const char hex[] = "0123456789ABCDEF";
    for (int i = digits - 1; i >= 0; i--) *(*p)++ = hex[(v >> (i * 4)) & 0xF];
}

static void put_dec(char **p, UINT32 v)
{
    char tmp[12]; int n = 0;
    do { tmp[n++] = (char)('0' + v % 10); v /= 10; } while (v);
    while (n) *(*p)++ = tmp[--n];
}

static void put_str(char **p, const char *s)
{
    while (*s) *(*p)++ = *s++;
}

void pci_list(pci_out_fn out)
{
    char line[160];
    int count = 0;
    out("PCI 장치 목록:\n");
    for (UINT32 bus = 0; bus < 256; bus++)
        for (UINT32 dev = 0; dev < 32; dev++)
            for (UINT32 fn = 0; fn < 8; fn++) {
                UINT32 id = cfg_read(bus, dev, fn, 0);
                if ((id & 0xFFFF) == 0xFFFF) {
                    if (fn == 0) break;             /* 장치 없음 */
                    continue;
                }
                UINT32 cc = cfg_read(bus, dev, fn, 0x08);
                char *p = line;
                put_str(&p, "  ");
                put_hex(&p, bus, 2); *p++ = ':';
                put_hex(&p, dev, 2); *p++ = '.';
                put_dec(&p, fn);
                put_str(&p, "  ");
                put_hex(&p, id & 0xFFFF, 4); *p++ = ':';
                put_hex(&p, id >> 16, 4);
                put_str(&p, "  ");
                put_str(&p, class_name(cc >> 24, (cc >> 16) & 0xFF, (cc >> 8) & 0xFF));
                *p++ = '\n';
                *p = 0;
                out(line);
                count++;
                if (fn == 0 && !(cfg_read(bus, dev, 0, 0x0C) & 0x00800000u)) break; /* 단일 기능 */
            }
    if (count == 0) out("  (장치를 찾지 못했습니다)\n");
}

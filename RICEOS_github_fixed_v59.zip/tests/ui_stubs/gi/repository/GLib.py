def idle_add(f, *a):
    f(*a); return None
def timeout_add_seconds(*a): return 0
def timeout_add(*a): return 0

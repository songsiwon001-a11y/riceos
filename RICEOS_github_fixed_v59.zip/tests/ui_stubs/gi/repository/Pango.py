class EllipsizeMode: END=3

class Meta(type):
    def __getattr__(cls, n):
        if n.startswith("__"): raise AttributeError(n)
        return Magic
class Magic(metaclass=Meta):
    def __init__(self, *a, **k):
        self.calls = []
    def __getattr__(self, n):
        if n.startswith("__"): raise AttributeError(n)
        def f(*a, **k):
            self.calls.append((n, a, k))
            return Magic()
        return f
    def __call__(self, *a, **k):
        return Magic()
    def __iter__(self):
        return iter([])
def __getattr__(n):
    if n.startswith("__"): raise AttributeError(n)
    return Magic

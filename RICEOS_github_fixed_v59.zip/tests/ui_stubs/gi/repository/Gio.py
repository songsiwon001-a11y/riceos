class _F: NON_UNIQUE=0
class ApplicationFlags: NON_UNIQUE=0
class AppInfo:
    @staticmethod
    def get_all(): return []

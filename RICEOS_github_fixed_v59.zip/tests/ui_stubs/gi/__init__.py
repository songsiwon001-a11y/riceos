def require_version(*a, **k): pass

"""exFAT / NTFS 테스트 이미지 생성 (스펙 구조대로 직접 작성).
출력: exfat.img, ntfs.img
"""
import os, struct

HERE = os.path.dirname(os.path.abspath(__file__))
END = 0xFFFFFFFF

# ---------------- exFAT ----------------
SEC, SPC = 512, 8
CL = SEC * SPC                       # 클러스터 4096
FAT_SEC, FAT_LEN, HEAP_SEC, CCOUNT = 24, 8, 32, 100
TOTAL = HEAP_SEC + CCOUNT * SPC

def heap(c):
    return (HEAP_SEC + (c - 2) * SPC) * SEC

def efile_set(name, attr, first, size, nofat):
    u = name.encode('utf-16-le')
    nlen = len(name)
    nname = (nlen + 14) // 15
    sec = 1 + nname
    out = bytearray()
    e = bytearray(32); e[0] = 0x85; e[1] = sec; struct.pack_into('<H', e, 4, attr); out += e
    s = bytearray(32); s[0] = 0xC0; s[1] = 0x03 if nofat else 0x01; s[3] = nlen
    struct.pack_into('<Q', s, 8, size); struct.pack_into('<I', s, 20, first)
    struct.pack_into('<Q', s, 24, size); out += s
    for i in range(nname):
        c = bytearray(32); c[0] = 0xC1
        chunk = u[i * 30:(i + 1) * 30]
        c[2:2 + len(chunk)] = chunk
        out += c
    return bytes(out)

def make_exfat(path):
    img = bytearray(TOTAL * SEC)
    b = bytearray(512)
    b[0:3] = b'\xEB\x76\x90'
    b[3:11] = b'EXFAT   '
    struct.pack_into('<Q', b, 72, TOTAL)
    struct.pack_into('<I', b, 80, FAT_SEC)
    struct.pack_into('<I', b, 84, FAT_LEN)
    struct.pack_into('<I', b, 88, HEAP_SEC)
    struct.pack_into('<I', b, 92, CCOUNT)
    struct.pack_into('<I', b, 96, 2)            # 루트 클러스터
    b[108] = 9; b[109] = 3; b[110] = 1           # 512B 섹터, 4KB 클러스터, FAT 1개
    b[510] = 0x55; b[511] = 0xAA
    img[0:512] = b

    fat = [0] * (FAT_LEN * SEC // 4)
    fat[0] = 0xFFFFFFF8; fat[1] = END
    fat[2] = END          # 루트
    fat[3] = END          # 파일 1 (FAT 체인)
    fat[4] = 5; fat[5] = END   # 파일 2 (연속 저장이라 실제로는 FAT 미사용)
    img[FAT_SEC * SEC:FAT_SEC * SEC + len(fat) * 4] = struct.pack('<%dI' % len(fat), *fat)

    txt = '안녕 exFAT'.encode('utf-8')
    data = bytes(i % 251 for i in range(6000))
    root = (efile_set('한글.txt', 0x20, 3, len(txt), False)
            + efile_set('data.bin', 0x20, 4, len(data), True))
    img[heap(2):heap(2) + len(root)] = root
    img[heap(3):heap(3) + len(txt)] = txt
    img[heap(4):heap(4) + len(data)] = data          # 클러스터 4,5 연속
    open(path, 'wb').write(img)
    return txt, data

# ---------------- NTFS ----------------
NCL = 4096
REC = 1024
MFT_LCN = 4
NTFS_CL = 32

def fixup_write(rec):
    usn = 0x0001
    rec[0x30:0x32] = struct.pack('<H', usn)
    rec[0x32:0x34] = rec[510:512]
    rec[0x34:0x36] = rec[1022:1024]
    rec[510:512] = struct.pack('<H', usn)
    rec[1022:1024] = struct.pack('<H', usn)

def make_record(flags, attrs):
    rec = bytearray(REC)
    rec[0:4] = b'FILE'
    struct.pack_into('<H', rec, 4, 0x30)     # USA 오프셋
    struct.pack_into('<H', rec, 6, 3)        # USA 개수 (USN + 섹터 2개)
    struct.pack_into('<H', rec, 0x10, 1)
    struct.pack_into('<H', rec, 0x14, 0x38)  # 첫 속성 오프셋
    struct.pack_into('<H', rec, 0x16, flags)
    body = bytearray(attrs) + struct.pack('<I', 0xFFFFFFFF)
    rec[0x38:0x38 + len(body)] = body
    struct.pack_into('<I', rec, 0x18, 0x38 + len(body))
    struct.pack_into('<I', rec, 0x1C, REC)
    fixup_write(rec)
    return rec

def attr_resident(atype, value):
    alen = (0x18 + len(value) + 7) // 8 * 8
    a = bytearray(alen)
    struct.pack_into('<I', a, 0, atype)
    struct.pack_into('<I', a, 4, alen)
    struct.pack_into('<H', a, 10, 0x18)
    struct.pack_into('<I', a, 16, len(value))
    struct.pack_into('<H', a, 20, 0x18)
    a[0x18:0x18 + len(value)] = value
    return bytes(a)

def attr_nonres_data(runs, lastvcn, alloc, real):
    alen = (0x40 + len(runs) + 7) // 8 * 8
    a = bytearray(alen)
    struct.pack_into('<I', a, 0, 0x80)
    struct.pack_into('<I', a, 4, alen)
    a[8] = 1
    struct.pack_into('<Q', a, 24, lastvcn)
    struct.pack_into('<H', a, 32, 0x40)
    struct.pack_into('<Q', a, 40, alloc)
    struct.pack_into('<Q', a, 48, real)
    struct.pack_into('<Q', a, 56, real)
    a[0x40:0x40 + len(runs)] = runs
    return bytes(a)

def filename_value(parent, name, ns, real, flags):
    n = name.encode('utf-16-le')
    v = bytearray(66 + len(n))
    struct.pack_into('<Q', v, 0, parent)
    struct.pack_into('<Q', v, 48, real)
    struct.pack_into('<I', v, 56, flags)
    v[64] = len(name)
    v[65] = ns
    v[66:] = n
    return bytes(v)

def make_ntfs(path):
    img = bytearray(NTFS_CL * NCL)
    b = bytearray(512)
    b[3:11] = b'NTFS    '
    struct.pack_into('<H', b, 0x0B, 512)
    b[0x0D] = SPC
    struct.pack_into('<Q', b, 0x28, NTFS_CL * SPC)
    struct.pack_into('<Q', b, 0x30, MFT_LCN)
    struct.pack_into('<Q', b, 0x38, 16)
    b[0x40] = (-10) & 0xFF                   # 레코드 크기 = 2^10 = 1024
    b[510] = 0x55; b[511] = 0xAA
    img[0:512] = b

    # 레코드 0: $MFT (2클러스터, LCN 4부터 연속)
    rec0 = make_record(0x01, attr_nonres_data(bytes([0x11, 0x02, 0x04, 0x00]), 1, 8192, 8192))

    # 레코드 5: 루트 디렉터리 (인덱스 루트에 readme 한 개)
    fn = filename_value(5 | (5 << 48), 'readme', 1, 9, 0)
    elen = (16 + len(fn) + 7) // 8 * 8
    entry = bytearray(elen)
    struct.pack_into('<Q', entry, 0, 6 | (1 << 48))
    struct.pack_into('<H', entry, 8, elen)
    struct.pack_into('<H', entry, 10, len(fn))
    entry[16:16 + len(fn)] = fn
    last = bytearray(16)
    struct.pack_into('<H', last, 8, 16)
    struct.pack_into('<H', last, 12, 0x02)
    entries = bytes(entry) + bytes(last)
    isz = 16 + len(entries)
    iroot = bytearray(32 + len(entries))
    struct.pack_into('<I', iroot, 0, 0x30)
    struct.pack_into('<I', iroot, 4, 1)
    struct.pack_into('<I', iroot, 8, 4096)
    iroot[12] = 1
    struct.pack_into('<I', iroot, 16, 16)        # 엔트리 오프셋 (인덱스 헤더 기준)
    struct.pack_into('<I', iroot, 20, isz)
    struct.pack_into('<I', iroot, 24, isz)
    iroot[32:32 + len(entries)] = entries
    rec5 = make_record(0x03, attr_resident(0x90, bytes(iroot)))

    # 레코드 6: readme (상주 데이터)
    rec6 = make_record(0x01, attr_resident(0x30, fn) + attr_resident(0x80, b'NTFS data'))

    base = MFT_LCN * NCL
    img[base:base + REC] = rec0
    img[base + 5 * REC:base + 6 * REC] = rec5
    img[base + 6 * REC:base + 7 * REC] = rec6
    open(path, 'wb').write(img)
    return b'NTFS data'

if __name__ == '__main__':
    t, d = make_exfat(os.path.join(HERE, 'exfat.img'))
    print('exfat.img: 파일 2개 (한글.txt %d B, data.bin %d B)' % (len(t), len(d)))
    n = make_ntfs(os.path.join(HERE, 'ntfs.img'))
    print('ntfs.img: 파일 1개 (readme %d B)' % len(n))

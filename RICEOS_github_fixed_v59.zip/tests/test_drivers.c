/* exFAT / NTFS 드라이버 호스트 테스트: 메모리 이미지를 실제로 읽어 확인 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "../fs_exfat.h"
#include "../fs_ntfs.h"
#include "../fs.h"

static UINT8 *img;
static UINT64 imgsz;
static int fails;

static int mem_read(void *ctx, UINT64 off, void *buf, UINT32 len)
{
    (void)ctx;
    if (off + len > imgsz) return 1;
    memcpy(buf, img + off, len);
    return 0;
}

static int load(const char *path)
{
    FILE *f = fopen(path, "rb");
    if (!f) return 1;
    fseek(f, 0, SEEK_END);
    imgsz = (UINT64)ftell(f);
    fseek(f, 0, SEEK_SET);
    free(img);
    img = malloc((size_t)imgsz);
    if (!img || fread(img, 1, (size_t)imgsz, f) != (size_t)imgsz) { fclose(f); return 1; }
    fclose(f);
    return 0;
}

static void check(int ok, const char *msg)
{
    printf("%s %s\n", ok ? "PASS" : "FAIL", msg);
    if (!ok) fails++;
}

struct collect {
    int n;
    char names[8][256];
    UINT64 sizes[8];
    int dirs[8];
};

static void collect_cb(void *c, const dirent_t *e)
{
    struct collect *k = (struct collect *)c;
    if (k->n < 8) {
        utf16_to_utf8(e->name, k->names[k->n], 256);
        k->sizes[k->n] = e->size;
        k->dirs[k->n] = e->is_dir;
        k->n++;
    }
}

int main(int argc, char **argv)
{
    volume_t v = { mem_read, 0 };
    struct collect c;
    UINT8 buf[8192];
    UINT32 len = 0;

    if (argc < 3) { fprintf(stderr, "사용법: test_drivers exfat.img ntfs.img\n"); return 2; }

    /* ---- exFAT ---- */
    if (load(argv[1])) { printf("이미지 열기 실패\n"); return 2; }
    check(exfat_probe(&v) == 0, "exFAT 부트 섹터 인식");
    check(ntfs_probe(&v) != 0, "exFAT 이미지는 NTFS로 인식되지 않음");

    memset(&c, 0, sizeof(c));
    check(exfat_list_root(&v, collect_cb, &c) == 0, "exFAT 루트 목록 읽기");
    check(c.n == 2, "exFAT 항목 2개");
    if (c.n == 2) {
        check(strcmp(c.names[0], "한글.txt") == 0, "exFAT 한글 파일 이름");
        check(strcmp(c.names[1], "data.bin") == 0, "exFAT 연속 저장 파일 이름");
        check(c.sizes[0] == 12 && c.sizes[1] == 6000, "exFAT 파일 크기");
        check(!c.dirs[0] && !c.dirs[1], "exFAT 파일 종류 (파일)");
    }

    CHAR16 kor[] = { 0xD55C, 0xAE00, '.', 't', 'x', 't', 0 };
    CHAR16 bin[] = { 'd', 'a', 't', 'a', '.', 'b', 'i', 'n', 0 };
    const char *want_txt = "안녕 exFAT";
    check(exfat_read_root_file(&v, kor, buf, sizeof(buf), &len) == 0 && len == 12 &&
          memcmp(buf, want_txt, 12) == 0, "exFAT FAT 체인 파일 읽기 (한글 이름)");

    check(exfat_read_root_file(&v, bin, buf, sizeof(buf), &len) == 0 && len == 6000, "exFAT 연속 파일 읽기 (두 클러스터 걸침)");
    int ok = 1;
    for (UINT32 i = 0; i < len && ok; i++) if (buf[i] != (UINT8)(i % 251)) ok = 0;
    check(ok, "exFAT 연속 파일 내용 검증");

    /* ---- NTFS ---- */
    if (load(argv[2])) { printf("이미지 열기 실패\n"); return 2; }
    check(ntfs_probe(&v) == 0, "NTFS 부트 섹터와 $MFT 인식 (fixup 포함)");
    check(exfat_probe(&v) != 0, "NTFS 이미지는 exFAT로 인식되지 않음");

    memset(&c, 0, sizeof(c));
    check(ntfs_list_root(&v, collect_cb, &c) == 0, "NTFS 루트 목록 읽기 ($INDEX_ROOT)");
    check(c.n == 1, "NTFS 항목 1개");
    if (c.n == 1) {
        check(strcmp(c.names[0], "readme") == 0, "NTFS 파일 이름");
        check(c.sizes[0] == 9, "NTFS 파일 크기");
    }

    CHAR16 readme[] = { 'r', 'e', 'a', 'd', 'm', 'e', 0 };
    check(ntfs_read_root_file(&v, readme, buf, sizeof(buf), &len) == 0 &&
          len == 9 && memcmp(buf, "NTFS data", 9) == 0, "NTFS 상주 데이터 읽기");

    /* ---- 식별 ---- */
    UINT8 bs[512];
    check(vol_read(&v, 0, bs, 512) == 0 && fs_identify(bs) == FS_NTFS, "fs_identify가 NTFS 판별");

    printf(fails ? "\n%d개 실패\n" : "\n모두 통과\n", fails);
    free(img);
    return fails ? 1 : 0;
}

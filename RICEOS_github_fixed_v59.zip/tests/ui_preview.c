/* 호스트 미리보기: 같은 그리기 코드로 화면을 메모리에 그려 파일로 저장 */
#include <stdio.h>
#include <stdlib.h>
#include "../gfx.h"
#include "../ui.h"

#define W 1024
#define H 768

static void noop(void) {}

static void dump(const char *path, const UINT32 *px)
{
    FILE *f = fopen(path, "wb");
    if (!f) return;
    fwrite(px, 4, (size_t)W * H, f);   /* 바이트 순서: R,G,B,0 (bgr=0) */
    fclose(f);
}

int main(void)
{
    UINT32 *buf = calloc((size_t)W * H, 4);
    gfx_t g = { buf, W, W, H, 0 };

    ui_init(&g, noop);
    ui_set_clock("14:32", "2026-11-22");
    ui_print("연결된 저장 장치:\n");
    ui_print("  [1] USB 저장장치  7456 MB  [이동식]\n");
    ui_print("  [2] SATA 디스크  953869 MB  [고정]\n");
    ui_print("\n");
    ui_print("파티션 목록:\n");
    ui_print("  [1] FAT32  (읽기 가능)\n");
    ui_print("  [2] NTFS  (읽기 가능)\n");
    ui_print("  [3] exFAT  (읽기 가능)\n");

    /* 시작 메뉴 열고 두 번째 항목 선택 */
    ui_handle_key(0x17, 0);
    ui_handle_key(0x02, 0);
    ui_render();
    dump("/tmp/desk.raw", buf);

    /* 메뉴 닫고 블루스크린 */
    ui_handle_key(0x17, 0);
    ui_bsod(0x00000001);
    dump("/tmp/bsod.raw", buf);

    free(buf);
    return 0;
}

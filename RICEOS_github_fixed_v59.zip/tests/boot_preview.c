#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "../gfx.h"
#include "../boot.h"
#define W 1024
#define H 768
/* 가짜 제조사 로고: 300x90, 24비트 BMP (아래→위 순서) */
static UINT8 *fake_bmp(void){
    int w=300,h=90,stride=w*3; stride=(stride+3)&~3;
    UINT8 *b=calloc(1,54+stride*h);
    b[0]='B';b[1]='M'; *(UINT32*)(b+10)=54; *(UINT32*)(b+14)=40;
    *(int*)(b+18)=w; *(int*)(b+22)=h; b[26]=1; b[28]=24;
    for(int y=0;y<h;y++)for(int x=0;x<w;x++){
        UINT8 *p=b+54+(h-1-y)*stride+x*3; int in=(x>20&&x<280&&y>20&&y<70);
        p[0]=p[1]=p[2]=in?0xE0:0; if(in&&x<90){p[0]=0x30;p[1]=0x30;p[2]=0xE0;}
    }
    return b;
}
int main(int argc,char**argv){
    UINT32 *buf = calloc((size_t)W*H,4);
    gfx_t g = { buf, W, W, H, 0 };
    if(argc>1) boot_set_logo(fake_bmp(),0,0,0);
    boot_draw(&g, 0);
    boot_draw(&g, 60);
    FILE *f=fopen("/tmp/boot.raw","wb"); fwrite(buf,4,(size_t)W*H,f); fclose(f);
    return 0;
}

#!/bin/bash
# RICEOS 디스크 이미지 만들기 (Debian 13 trixie 최소 설치 (RICEOS_SUITE=bookworm 으로 12 도 가능) + RICEOS UI)
# 실행 환경: Debian/Ubuntu 리눅스 또는 Windows의 WSL2 (root 권한, 인터넷 필요)
# 결과: riceos.img  (GPT: EFI 512MB FAT32 + 나머지 ext4)
# 사용: sudo ./make_image.sh [크기, 기본 6G]
set -euo pipefail

# 빌드 서버 디스크 확보: 깃허브 러너에는 쓰지 않는 큰 도구가 많이 들어 있다. 지우면 수십 GB가 생긴다
echo "[디스크] 정리 전: $(df -BG --output=avail / | tail -1 | tr -d ' ')"
for d in /usr/share/dotnet /usr/local/lib/android /opt/ghc /usr/local/share/boost /opt/hostedtoolcache/CodeQL /usr/share/swift; do
  [ -e "$d" ] && rm -rf "$d" 2>/dev/null || true
done
command -v docker >/dev/null 2>&1 && docker system prune -af >/dev/null 2>&1 || true
apt-get clean 2>/dev/null || true
echo "[디스크] 정리 후: $(df -BG --output=avail / | tail -1 | tr -d ' ')"

SIZE="${1:-6G}"
IMG="$(pwd)/riceos.img"
MNT="$(mktemp -d /tmp/riceos-root.XXXXXX)"
HERE="$(cd "$(dirname "$0")" && pwd)"
MIRROR="http://deb.debian.org/debian"
SUITE="${RICEOS_SUITE:-trixie}"
# 커널 명령줄: 콘솔 글자(도스 같은 부팅 메시지)를 숨기고 Plymouth 부팅 화면을 쓴다
KCMD="ro quiet splash loglevel=3 udev.log_level=3 rd.udev.log_level=3 systemd.show_status=false vt.global_cursor_default=0"

[ "$(id -u)" = 0 ] || { echo "root 권한이 필요합니다: sudo $0"; exit 1; }
for t in debootstrap parted losetup mkfs.vfat mkfs.ext4 blkid chroot mksquashfs; do
  command -v "$t" >/dev/null || { echo "필요한 도구가 없습니다: $t"
    echo "설치: apt install debootstrap parted dosfstools e2fsprogs util-linux squashfs-tools"; exit 1; }
done
[ -f "$HERE/riceos-ui.py" ] || { echo "riceos-ui.py 가 없습니다"; exit 1; }
[ -f "$HERE/riceos-sysinfo" ] || { echo "riceos-sysinfo 가 없습니다"; exit 1; }
[ -f "$HERE/riceos-auth" ] || { echo "riceos-auth 가 없습니다"; exit 1; }
[ -f "$HERE/riceos-audio-init" ] || { echo "riceos-audio-init 가 없습니다"; exit 1; }
[ -f "$HERE/riceos-install" ] || { echo "riceos-install 가 없습니다"; exit 1; }
[ -f "$HERE/wireplumber/51-riceos-sound.lua" ] && [ -f "$HERE/wireplumber/51-riceos-sound.conf" ] || { echo "wireplumber 설정 파일이 없습니다"; exit 1; }

LOOP1=""; LOOP2=""
cleanup() {
  set +e
  for m in dev/pts dev proc sys boot/efi; do umount "$MNT/$m" 2>/dev/null; done
  umount "$MNT" 2>/dev/null
  [ -n "$LOOP1" ] && losetup -d "$LOOP1" 2>/dev/null
  [ -n "$LOOP2" ] && losetup -d "$LOOP2" 2>/dev/null
  rmdir "$MNT" 2>/dev/null
}
trap cleanup EXIT

echo "[1/7] 빈 이미지와 파티션 만들기 ($SIZE)"
rm -f "$IMG"
truncate -s "$SIZE" "$IMG"
parted -s "$IMG" mklabel gpt \
  mkpart ESP fat32 1MiB 513MiB set 1 esp on \
  mkpart riceos-root ext4 513MiB 100%
TOTAL=$(stat -c %s "$IMG")
# 파티션 노드(loopNp1)가 없는 환경(WSL2 등)을 위해 오프셋으로 각각 연결
LOOP1=$(losetup --find --show -o $((1*1024*1024)) --sizelimit $((512*1024*1024)) "$IMG")
LOOP2=$(losetup --find --show -o $((513*1024*1024)) --sizelimit $((TOTAL - 513*1024*1024 - 1024*1024)) "$IMG")

echo "[2/7] 파일 시스템 만들기"
mkfs.vfat -F32 -n RICEOS-EFI "$LOOP1" >/dev/null
mkfs.ext4 -q -L riceos-root "$LOOP2"
mount "$LOOP2" "$MNT"
mkdir -p "$MNT/boot/efi"
mount "$LOOP1" "$MNT/boot/efi"

echo "[3/7] Debian 기본 시스템 설치 (몇 분 걸립니다)"
# 받은 .deb 파일은 캐시 폴더에 남긴다 (같은 폴더를 다음 빌드에서 쓰면 다시 받지 않는다)
DEBCACHE="${RICEOS_DEBCACHE:-/var/cache/riceos-deb}"
mkdir -p "$DEBCACHE"
debootstrap --arch=amd64 --cache-dir="$DEBCACHE" --components=main,contrib,non-free,non-free-firmware \
  --include=linux-image-amd64,grub-efi-amd64,sudo,shim-signed,grub-efi-amd64-signed,systemd-sysv,udev,kmod,locales,tzdata,ca-certificates,curl,xserver-xorg-core,xinit,openbox \
  "$SUITE" "$MNT" "$MIRROR"

echo "[4/7] 기본 설정"
ROOT_UUID=$(blkid -s UUID -o value "$LOOP2")
EFI_UUID=$(blkid -s UUID -o value "$LOOP1")
cat > "$MNT/etc/fstab" <<FSTAB
UUID=$ROOT_UUID / ext4 defaults,noatime 0 1
UUID=$EFI_UUID /boot/efi vfat umask=0077 0 2
FSTAB
echo riceos > "$MNT/etc/hostname"
echo "Asia/Seoul" > "$MNT/etc/timezone"
ln -sf /usr/share/zoneinfo/Asia/Seoul "$MNT/etc/localtime"
# 지원 언어: 한국어(기본), English, 日本語, 中文(简体), Français, Español. 모두 UTF-8
cat > "$MNT/etc/locale.gen" <<LOCALES
ko_KR.UTF-8 UTF-8
en_US.UTF-8 UTF-8
ja_JP.UTF-8 UTF-8
zh_CN.UTF-8 UTF-8
fr_FR.UTF-8 UTF-8
es_ES.UTF-8 UTF-8
LOCALES
echo "LANG=ko_KR.UTF-8" > "$MNT/etc/default/locale"
mkdir -p "$MNT/etc/systemd/network"
cat > "$MNT/etc/systemd/network/20-wired.network" <<NET
[Match]
Name=en*
[Network]
DHCP=yes
NET

# 네트워크 관리는 NetworkManager 가 맡는다 (유선·무선·연결 목록은 트레이 아이콘에서)
mkdir -p "$MNT/etc/NetworkManager/conf.d"
cat > "$MNT/etc/NetworkManager/conf.d/10-riceos.conf" <<NMCONF
[main]
dns=systemd-resolved
NMCONF

# apt 저장소: 펌웨어와 non-free 드라이버를 나중에 인터넷에서 받을 수 있도록 설정
cat > "$MNT/etc/apt/sources.list" <<APT
deb http://deb.debian.org/debian $SUITE main contrib non-free non-free-firmware
deb http://deb.debian.org/debian $SUITE-updates main contrib non-free non-free-firmware
deb http://security.debian.org/debian-security $SUITE-security main contrib non-free non-free-firmware
APT

echo "[5/7] RICEOS UI 설치와 자동 실행 설정"
install -m 755 "$HERE/riceos-ui.py" "$MNT/usr/local/bin/riceos-ui"
# 시스템 일(네트워크, 소리, 장치)은 리눅스 도구가 하고, riceos-ui 는 화면만 담당한다
# 시스템 정보 수집도 리눅스 도구 스크립트가 맡고, riceos-ui 는 그 결과를 보여 준다
install -m 755 "$HERE/riceos-sysinfo" "$MNT/usr/local/bin/riceos-sysinfo"
# 로그인 비밀번호 헬퍼 (root 전용). riceos 계정은 sudo 로 이 한 가지만 NOPASSWD 로 부를 수 있다
install -m 755 "$HERE/riceos-auth" "$MNT/usr/local/sbin/riceos-auth"
# 소리: 세션 시작 때 음소거 해제와 볼륨 70%, 모니터 스피커(HDMI·DP)는 우선순위를 낮춘다
install -m 755 "$HERE/riceos-audio-init" "$MNT/usr/local/bin/riceos-audio-init"
[ -f "$HERE/riceos-usb" ] && [ -f "$HERE/riceos-usb-watch" ] || { echo "riceos-usb 파일이 없습니다"; exit 1; }
install -m 755 "$HERE/riceos-usb" "$MNT/usr/local/sbin/riceos-usb"
install -m 755 "$HERE/riceos-usb-watch" "$MNT/usr/local/bin/riceos-usb-watch"
[ -f "$HERE/riceos-archive" ] || { echo "riceos-archive 파일이 없습니다"; exit 1; }
install -m 755 "$HERE/riceos-archive" "$MNT/usr/local/bin/riceos-archive"
[ -f "$HERE/riceos-game-tools" ] || { echo "riceos-game-tools 파일이 없습니다"; exit 1; }
mkdir -p "$MNT/usr/local/share/applications" "$MNT/usr/local/bin"
install -m 755 "$HERE/riceos-game-tools" "$MNT/usr/local/bin/riceos-game-tools"
install -m 644 "$HERE/riceos-game-tools.desktop" "$MNT/usr/local/share/applications/riceos-game-tools.desktop"
# 기본 입력기: 영어 + 한국어(한글). 전환은 Shift+Space 또는 한/영 키
mkdir -p "$MNT/etc/dconf/profile" "$MNT/etc/dconf/db/local.d"
printf 'user-db:user\nsystem-db:local\n' > "$MNT/etc/dconf/profile/user"
cat > "$MNT/etc/dconf/db/local.d/00-riceos-ibus" <<'DCONF'
[desktop/ibus/general]
preload-engines=['xkb:us::eng', 'hangul']
engines-order=['xkb:us::eng', 'hangul']

[desktop/ibus/general/hotkey]
triggers=['<Super>space', '<Shift>space', 'Hangul']
DCONF
# 파일 관리자 우클릭 메뉴: 압축, 압축 풀기 (libfm 액션 규격)
mkdir -p "$MNT/usr/share/file-manager/actions"
for f in "$HERE"/file-manager-actions/*.desktop; do install -m 644 "$f" "$MNT/usr/share/file-manager/actions/"; done
# USB 연결/분리 효과음 (두 음을 이어 붙인 짧은 소리, 표준 라이브러리로 생성)
mkdir -p "$MNT/usr/local/share/riceos"
python3 - "$MNT/usr/local/share/riceos" <<'PYSND'
import sys, wave, struct, math, os
rate = 44100
def tones(seq):
    out = bytearray()
    for freq, dur in seq:
        n = int(rate * dur)
        for i in range(n):
            t = i / rate
            env = min(1.0, t / 0.005) * math.exp(-5.0 * t)
            v = 0.45 * env * math.sin(2 * math.pi * freq * t)
            out += struct.pack('<h', int(v * 32000))
    return bytes(out)
def save(path, data):
    with wave.open(path, 'wb') as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(rate); w.writeframes(data)
d = sys.argv[1]
save(os.path.join(d, 'connect.wav'), tones([(880, 0.10), (1320, 0.16)]))
save(os.path.join(d, 'disconnect.wav'), tones([(1320, 0.10), (880, 0.16)]))
PYSND
[ -s "$MNT/usr/local/share/riceos/connect.wav" ] || echo "경고: USB 효과음 생성 실패"
# 시작음: 프로젝트에 들어 있는 mp3 를 이미지에 넣는다
mkdir -p "$MNT/usr/local/share/riceos"
[ -f "$HERE/sounds/startup.mp3" ] || { echo "sounds/startup.mp3 가 없습니다"; exit 1; }
install -m 644 "$HERE/sounds/startup.mp3" "$MNT/usr/local/share/riceos/startup.mp3"
# 설치 프로그램 (USB 임시 모드에서 하드디스크로 설치). 설명은 linux/README.md
install -m 755 "$HERE/riceos-install" "$MNT/usr/local/sbin/riceos-install"
if [ "$SUITE" = bookworm ]; then
  mkdir -p "$MNT/etc/wireplumber/main.lua.d"
  install -m 644 "$HERE/wireplumber/51-riceos-sound.lua" "$MNT/etc/wireplumber/main.lua.d/51-riceos-sound.lua"
else
  mkdir -p "$MNT/etc/wireplumber/wireplumber.conf.d"
  install -m 644 "$HERE/wireplumber/51-riceos-sound.conf" "$MNT/etc/wireplumber/wireplumber.conf.d/51-riceos-sound.conf"
fi
mkdir -p "$MNT/etc/sudoers.d"
cat > "$MNT/etc/sudoers.d/riceos-auth" <<'SUDO'
riceos ALL=(root) NOPASSWD: /usr/local/sbin/riceos-auth
riceos ALL=(root) PASSWD: /usr/local/sbin/riceos-install
SUDO
chmod 440 "$MNT/etc/sudoers.d/riceos-auth"
# 부팅 시 소리 켜기: 많은 마더보드가 음소거 상태로 시작한다
cat > "$MNT/etc/systemd/system/riceos-sound.service" <<'UNIT'
[Unit]
Description=RICEOS 기본 소리 설정
After=alsa-restore.service sound.target
Wants=alsa-restore.service

[Service]
Type=oneshot
RemainAfterExit=yes
ExecStart=/bin/sh -c 'for c in Master PCM Headphone Speaker; do amixer -q sset "$c" unmute 70% >/dev/null 2>&1; done; exit 0'

[Install]
WantedBy=multi-user.target
UNIT

cat > "$MNT/etc/systemd/system/riceos-ui.service" <<UNIT
[Unit]
Description=RICEOS 데스크톱 (X: Openbox, Mesa, libinput)
After=systemd-user-sessions.service systemd-udev-settle.service riceos-sound.service plymouth-start.service
# 부팅 화면(Plymouth)은 데스크톱 세션이 시작된 뒤에 내린다. 그래야 로딩바가 중간에 끊기지 않는다
Before=plymouth-quit.service plymouth-quit-wait.service
Wants=riceos-sound.service
Conflicts=getty@tty1.service
After=getty@tty1.service

[Service]
Environment=TZ=Asia/Seoul
ExecStart=/usr/bin/xinit /usr/local/bin/riceos-chrome-session -- :1 vt8 -nolisten tcp
Restart=always
RestartSec=1
StandardInput=null
StandardOutput=journal
StandardError=journal

[Install]
WantedBy=multi-user.target
UNIT

# 데스크톱 세션: 일반 사용자(riceos)로 창 관리자와 바탕화면을 X 화면에서 띄운다 (앱은 자동으로 켜지지 않는다)
cat > "$MNT/usr/local/bin/riceos-chrome" <<'SH'
#!/bin/sh
# RICEOS 데스크톱(X)을 연다. 나가면 RICEOS 화면으로 돌아온다. 앱은 자동으로 켜지지 않는다.
if systemctl is-active --quiet riceos-x.service; then
  echo "데스크톱이 이미 실행 중입니다."
  exit 0
fi
systemd-run --unit=riceos-x --collect --description="RICEOS 데스크톱" \
  /bin/sh -c 'systemctl stop riceos-ui.service; xinit /usr/local/bin/riceos-chrome-session -- :1 vt8 -nolisten tcp >/var/log/riceos-x.log 2>&1; systemctl start riceos-ui.service'
SH
chmod 755 "$MNT/usr/local/bin/riceos-chrome"

cat > "$MNT/usr/local/bin/riceos-chrome-session" <<'SH'
#!/bin/sh
# X 세션 안에서 xinit이 실행한다. 창 관리자와 바탕화면 아이콘 관리를 riceos 사용자로 띄운다.
# 창 관리자(Openbox)를 끝내면 이 스크립트가 끝나고, xinit이 X 서버를 내린다.
xhost +SI:localuser:riceos >/dev/null 2>&1
# 바탕화면 색 (pcmanfm 이 그리기 전에도 같은 색이 보이게)
xsetroot -solid "#F5B52E" 2>/dev/null || true

# 모든 연결된 모니터를 켠다. 각 모니터는 자기 해상도에서 가장 높은 주사율로 돌고,
# 첫 번째 모니터를 기준(주 모니터)으로 나머지를 오른쪽에 가로로 배치한다.
riceos_layout() {
  prev=""
  # 해상도 고르기: 모니터가 알려 준 권장(+) 해상도 → 현재(*) 해상도 → 첫 줄 순서.
  # xrandr 의 첫 줄은 가장 큰 해상도라서 작은 모니터가 신호를 못 받아 검게 될 수 있다.
  xrandr -q | awk '
    function emit(   c) {
      if (out == "") return
      c = pref != "" ? pref : (cur != "" ? cur : first)
      if (c != "") print out, c
    }
    /^[^ ]/ {
      emit(); out = ""; pref = ""; cur = ""; first = ""
      if ($0 ~ / connected/ && $0 !~ / disconnected/) out = $1
      next
    }
    out != "" && /^ +[0-9]+x[0-9]+/ {
      # 주사율 칸 중 * (현재)와 + (권장) 이 붙은 칸의 값을 쓴다
      p = ""; c = ""; r = ""
      for (i = 2; i <= NF; i++) {
        v = $i; if (r == "") { r = v; gsub(/[*+]/, "", r) }
        if (v ~ /\+/ && p == "") { p = v; gsub(/[*+]/, "", p) }
        if (v ~ /\*/ && c == "") { c = v; gsub(/[*+]/, "", c) }
      }
      if (first == "") first = $1 " " r
      if (p != "" && pref == "") pref = $1 " " p
      if (c != "" && cur == "") cur = $1 " " c
    }
    END { emit() }
  ' | while read out res rate; do
    if [ -z "$prev" ]; then pos="--pos 0x0 --primary"; else pos="--right-of $prev"; fi
    xrandr --output "$out" --mode "$res" --rate "$rate" $pos
    prev="$out"
  done
}
# 디스플레이 설정(arandr)에서 저장한 배치가 있으면 그것을 쓰고, 없으면 위의 자동 배치를 쓴다
echo "[디스플레이] 시작 상태:"; xrandr -q 2>&1 | grep -E " connected|\*" || true
# 모든 연결된 모니터를 먼저 켜고, 저장된 배치가 있으면 그 위에 덮어쓴다
riceos_layout
# 연결됐지만 모드 목록이 안 잡혀서 위에서 빠진 모니터(EDID 실패 등)를 자동 모드로 켠다
last=$(xrandr -q | awk '/ connected/ && !/ disconnected/ && /[0-9]+x[0-9]+\+/ {n=$1} END{print n}')
xrandr -q | awk '/ connected/ && !/ disconnected/ && !/[0-9]+x[0-9]+\+/ {print $1}' | while read -r out; do
  echo "[디스플레이] 모드 없이 연결된 출력을 자동으로 켬: $out"
  if [ -n "$last" ]; then xrandr --output "$out" --auto --right-of "$last"; else xrandr --output "$out" --auto; fi
  last="$out"
done
SAVED=$(ls -t /home/riceos/.screenlayout/*.sh 2>/dev/null | head -1)
if [ -n "$SAVED" ]; then echo "[디스플레이] 저장된 배치 적용: $SAVED"; sh "$SAVED" || echo "[디스플레이] 저장된 배치 적용 실패"; fi
echo "[디스플레이] 적용 후:"; xrandr -q 2>&1 | grep -E " connected|\*" || true
/usr/local/bin/riceos-sync-desktop
# 로그인 세션이 없으므로 앱들이 쓰는 런타임 폴더를 직접 만든다 (소리, 크롬 등에 필요)
RT=/run/user/$(id -u riceos)
mkdir -p "$RT"; chown riceos:riceos "$RT"; chmod 700 "$RT"
exec runuser -u riceos -- env DISPLAY="$DISPLAY" HOME=/home/riceos XDG_RUNTIME_DIR="$RT" GTK_IM_MODULE=ibus QT_IM_MODULE=ibus XMODIFIERS=@im=ibus GTK_CSD=0 dbus-run-session -- openbox --startup 'sh -c "ibus-daemon -drx & pipewire & sleep 1; wireplumber & pipewire-pulse & sleep 2; pasystray & nm-applet & copyq & riceos-audio-init & riceos-usb-watch & riceos-ui --login &"'
SH
chmod 755 "$MNT/usr/local/bin/riceos-chrome-session"

# 부팅 화면 (Plymouth): 제조사 로고(ACPI BGRT) 위에 바 형태 로딩바. 테마 파일은 linux/plymouth/ 에 있다
mkdir -p "$MNT/usr/share/plymouth/themes/riceos" "$MNT/etc/plymouth"
install -m 644 "$HERE"/plymouth/riceos/* "$MNT/usr/share/plymouth/themes/riceos/"
install -m 644 "$HERE/plymouth/plymouthd.conf" "$MNT/etc/plymouth/plymouthd.conf"

# 배경화면 그림 폴더: linux/wallpapers/ 에 넣은 PNG/BMP 파일이 'riceos wallpaper next' 순환에 들어간다
mkdir -p "$MNT/usr/share/riceos/wallpapers"
if [ -d "$HERE/wallpapers" ]; then
  cp "$HERE"/wallpapers/*.png "$HERE"/wallpapers/*.bmp "$MNT/usr/share/riceos/wallpapers/" 2>/dev/null || true
fi

echo "[6/7] 부트로더(GRUB)와 서비스 활성화"
mount --bind /dev "$MNT/dev"
mount --bind /dev/pts "$MNT/dev/pts"
mount -t proc proc "$MNT/proc"
mount -t sysfs sys "$MNT/sys"

echo "bluez 설치 (서비스 자동 시작은 막음)"
# 빌드 중 DNS: 호스트의 127.0.0.53 같은 로컬 스텁은 chroot 안에서 못 쓴다. 공용 DNS를 직접 적는다
printf 'nameserver 8.8.8.8\nnameserver 1.1.1.1\n' > "$MNT/etc/resolv.conf"
printf '#!/bin/sh\nexit 101\n' > "$MNT/usr/sbin/policy-rc.d"
chmod +x "$MNT/usr/sbin/policy-rc.d"
# 로그인 비밀번호 바꾸기 (아이디는 Admin). 처음 비밀번호는 부팅 때 화면에서 정한다
cat > "$MNT/usr/local/bin/riceos-setpw" <<'SH'
#!/bin/sh
# RICEOS 로그인 비밀번호 바꾸기 (아이디 riceos). 사용법: sudo riceos-setpw
[ "$(id -u)" = 0 ] || { echo "root 권한으로 실행하세요: sudo riceos-setpw"; exit 1; }
printf '새 비밀번호: '; stty -echo; read -r PW1; stty echo; echo
printf '비밀번호 확인: '; stty -echo; read -r PW2; stty echo; echo
[ -n "$PW1" ] || { echo "비어 있으면 안 됩니다"; exit 1; }
[ "$PW1" = "$PW2" ] || { echo "두 비밀번호가 서로 다릅니다"; exit 1; }
printf '%s\n' "$PW1" | /usr/local/sbin/riceos-auth set && echo "비밀번호를 바꿨습니다. 로그인과 콘솔(riceos)에 같은 비밀번호가 쓰입니다."
SH
chmod +x "$MNT/usr/local/bin/riceos-setpw"

chroot "$MNT" apt-get update -qq
# 패키지 설치: 필수는 하나라도 없으면 중단하고, 선택은 "a|b" 순서대로 되는 것을 골라 쓴다 (없으면 경고만)
REQ_PKGS="live-boot squashfs-tools plymouth python3-gi gir1.2-gtk-4.0 pipewire pipewire-pulse wireplumber pcmanfm network-manager network-manager-gnome tint2 udisks2 xauth x11-xserver-utils xserver-xorg-input-libinput alsa-utils wpasupplicant iw rfkill iproute2 dosfstools e2fsprogs parted sudo systemd-resolved bluez"
OPT_PKGS="gdisk copyq catfish gnome-calculator|galculator|qalculate-gtk 7zip|p7zip-full plymouth-themes chromium|firefox-esr mpv|vlc zathura|evince gthumb|ristretto|feh gdebi|gdebi-core pavucontrol lxappearance|lxappearance-obconf cups system-config-printer|system-config-printer-common printer-driver-gutenprint pasystray|pavucontrol flameshot|scrot pigz zstd x11-utils ibus ibus-hangul ibus-mozc|ibus-anthy ibus-libpinyin dconf-cli dconf-service arandr mousepad|leafpad|nano feh|nitrogen xarchiver|file-roller lxterminal|xterm man-db manpages bash-completion htop unzip zip git wget file tree gvfs gvfs-backends xdg-utils xdg-user-dirs fonts-noto-color-emoji|fonts-symbola fonts-nanum fonts-dejavu-core exfatprogs ntfs-3g pciutils usbutils iputils-ping less nano procps firmware-linux firmware-linux-nonfree|firmware-misc-nonfree firmware-misc-nonfree firmware-realtek firmware-iwlwifi firmware-atheros firmware-brcm80211 firmware-amd-graphics firmware-sof-signed intel-microcode amd64-microcode libgl1-mesa-dri mesa-vulkan-drivers vulkan-tools vainfo fonts-noto-cjk xserver-xorg-video-amdgpu xserver-xorg-video-intel firmware-intel-graphics mesa-va-drivers intel-media-va-driver-non-free"
cat > "$MNT/tmp/riceos-pkgs.sh" <<'PKGSH'
#!/bin/bash
export DEBIAN_FRONTEND=noninteractive
have() { [ -n "$(apt-cache policy "$1" 2>/dev/null | sed -n 's/^  Candidate: //p' | grep -v '(none)')" ]; }
WANT=""
for p in $REQ_PKGS; do
  if have "$p"; then WANT="$WANT $p"; else echo "오류: 필수 패키지 $p 를 이 배포판에서 찾을 수 없습니다"; exit 1; fi
done
for g in $OPT_PKGS; do
  ok=""
  IFS='|' read -ra CAND <<< "$g"
  for p in "${CAND[@]}"; do
    if have "$p"; then ok="$p"; break; fi
  done
  if [ -z "$ok" ]; then echo "경고: 선택 패키지 [$g] 를 찾을 수 없어 건너뜁니다";
  else
    [ "$ok" = "${CAND[0]}" ] || echo "[대체] ${CAND[0]} 대신 $ok 사용"
    WANT="$WANT $ok"
  fi
done
if ! apt-get install -y -o Dpkg::Options::=--force-confold -o Dpkg::Options::=--force-confdef -qq $WANT; then
  echo "경고: 한 번에 설치하지 못했습니다. 하나씩 다시 시도합니다"
  for p in $WANT; do
    apt-get install -y -o Dpkg::Options::=--force-confold -o Dpkg::Options::=--force-confdef -qq "$p" || { echo "경고: $p 설치 실패"; apt-get -f install -y -qq || true; apt-get install -y -o Dpkg::Options::=--force-confold -o Dpkg::Options::=--force-confdef "$p" 2>&1 | grep -E "^(E|W):|Setting up|dpkg:" | head -30; case " $REQ_PKGS " in *" $p "*) echo "오류: 필수 패키지 $p 실패"; exit 1;; esac; }
  done
fi
PKGSH
chmod +x "$MNT/tmp/riceos-pkgs.sh"
chroot "$MNT" env REQ_PKGS="$REQ_PKGS" OPT_PKGS="$OPT_PKGS" /tmp/riceos-pkgs.sh
rm -f "$MNT/tmp/riceos-pkgs.sh"
rm -f "$MNT/usr/sbin/policy-rc.d"

# grub-probe 가 루트 장치를 못 찾는 문제 방지: mtab 연결 + 루트 UUID 직접 지정
ln -sf /proc/self/mounts "$MNT/etc/mtab"
echo "GRUB_DEVICE_UUID=$ROOT_UUID" >> "$MNT/etc/default/grub"

# 우클릭 메뉴에 설정 도구 항목 추가 (Openbox 루트 메뉴)
# 키 설정: 윈도우 키(Super)를 누르면 앱 목록이 열린다. W+E 파일 관리자, W+R 빠른 설정, 바탕 오른쪽 클릭은 메뉴
mkdir -p "$MNT/etc/xdg/openbox"
# 볼륨 단축키용: 5% 단위로 바꾸고, 바뀔 때 짧은 효과음 (윈도우처럼)
mkdir -p "$MNT/usr/local/share/riceos"
python3 - "$MNT/usr/local/share/riceos/tick.wav" <<'PYTICK'
import sys, wave, struct, math
rate = 44100
n = int(rate * 0.06)
out = bytearray()
for i in range(n):
    t = i / rate
    env = math.exp(-60.0 * t)
    v = 0.5 * env * math.sin(2 * math.pi * 1500.0 * t)
    out += struct.pack('<h', int(v * 32000))
with wave.open(sys.argv[1], 'wb') as w:
    w.setnchannels(1); w.setsampwidth(2); w.setframerate(rate)
    w.writeframes(bytes(out))
PYTICK
cat > "$MNT/usr/local/bin/riceos-volume" <<'VOL'
#!/bin/sh
# RICEOS 볼륨 단축키: up / down / mute. 소리가 바뀔 때 효과음을 낸다.
case "$1" in
  up)   wpctl set-mute @DEFAULT_AUDIO_SINK@ 0; wpctl set-volume -l 1.0 @DEFAULT_AUDIO_SINK@ 5%+ ;;
  down) wpctl set-volume -l 1.0 @DEFAULT_AUDIO_SINK@ 5%- ;;
  mute) wpctl set-mute @DEFAULT_AUDIO_SINK@ toggle; exit 0 ;;
  *) exit 1 ;;
esac
mpv --no-video --really-quiet --volume=60 /usr/local/share/riceos/tick.wav >/dev/null 2>&1 &
VOL
chmod 755 "$MNT/usr/local/bin/riceos-volume"
cat > "$MNT/etc/xdg/openbox/rc.xml" <<'RCXML'
<?xml version="1.0" encoding="UTF-8"?>
<openbox_config xmlns="http://openbox.org/3.4/rc">
  <theme>
    <titleLayout>NLIMC</titleLayout>
    <keepBorder>yes</keepBorder>
  </theme>
  <keyboard>
    <keybind key="W-S-s">
      <action name="Execute"><command>flameshot gui</command></action>
    </keybind>
    <keybind key="Print">
      <action name="Execute"><command>sh -c 'mkdir -p "$HOME/Pictures" &amp;&amp; flameshot full -c -p "$HOME/Pictures"'</command></action>
    </keybind>
    <keybind key="XF86AudioRaiseVolume">
      <action name="Execute"><command>riceos-volume up</command></action>
    </keybind>
    <keybind key="XF86AudioLowerVolume">
      <action name="Execute"><command>riceos-volume down</command></action>
    </keybind>
    <keybind key="XF86AudioMute">
      <action name="Execute"><command>riceos-volume mute</command></action>
    </keybind>
    <keybind key="Super_L">
      <action name="Execute"><command>riceos-start-toggle</command></action>
    </keybind>
    <keybind key="A-F4">
      <action name="Close"/>
    </keybind>
    <keybind key="A-Tab">
      <action name="NextWindow"/>
    </keybind>
    <keybind key="W-v">
      <action name="Execute"><command>sh -c 'copyq toggle || copyq show'</command></action>
    </keybind>
    <keybind key="W-s">
      <action name="Execute"><command>catfish</command></action>
    </keybind>
    <keybind key="W-c">
      <action name="Execute"><command>sh -c 'gnome-calculator || galculator || qalculate-gtk'</command></action>
    </keybind>
    <keybind key="W-n">
      <action name="Execute"><command>sh -c 'mousepad || leafpad'</command></action>
    </keybind>
    <keybind key="W-e">
      <action name="Execute"><command>pcmanfm</command></action>
    </keybind>
    <keybind key="W-r">
      <action name="Execute"><command>riceos-ui --quick</command></action>
    </keybind>
  </keyboard>
  <mouse>
    <dragThreshold>1</dragThreshold>
    <doubleClickTime>500</doubleClickTime>
    <context name="Frame">
      <mousebind button="A-Left" action="Press"><action name="Focus"/><action name="Raise"/></mousebind>
      <mousebind button="A-Left" action="Drag"><action name="Move"/></mousebind>
      <mousebind button="A-Right" action="Press"><action name="Focus"/><action name="Raise"/><action name="Unshade"/></mousebind>
      <mousebind button="A-Right" action="Drag"><action name="Resize"/></mousebind>
    </context>
    <context name="Titlebar">
      <mousebind button="Left" action="Drag"><action name="Move"/></mousebind>
      <mousebind button="Left" action="DoubleClick"><action name="ToggleMaximize"/></mousebind>
    </context>
    <context name="Titlebar Top Right Bottom Left TLCorner TRCorner BRCorner BLCorner">
      <mousebind button="Left" action="Press"><action name="Focus"/><action name="Raise"/><action name="Unshade"/></mousebind>
      <mousebind button="Middle" action="Press"><action name="Lower"/><action name="FocusToBottom"/><action name="Unfocus"/></mousebind>
      <mousebind button="Right" action="Press"><action name="Focus"/><action name="Raise"/><action name="ShowMenu"><menu>client-menu</menu></action></mousebind>
    </context>
    <context name="Top">
      <mousebind button="Left" action="Drag"><action name="Resize"><edge>top</edge></action></mousebind>
    </context>
    <context name="Left">
      <mousebind button="Left" action="Drag"><action name="Resize"><edge>left</edge></action></mousebind>
    </context>
    <context name="Right">
      <mousebind button="Left" action="Drag"><action name="Resize"><edge>right</edge></action></mousebind>
    </context>
    <context name="Bottom">
      <mousebind button="Left" action="Drag"><action name="Resize"><edge>bottom</edge></action></mousebind>
    </context>
    <context name="TLCorner">
      <mousebind button="Left" action="Drag"><action name="Resize"><edge>topleft</edge></action></mousebind>
    </context>
    <context name="TRCorner">
      <mousebind button="Left" action="Drag"><action name="Resize"><edge>topright</edge></action></mousebind>
    </context>
    <context name="BLCorner">
      <mousebind button="Left" action="Drag"><action name="Resize"><edge>bottomleft</edge></action></mousebind>
    </context>
    <context name="BRCorner">
      <mousebind button="Left" action="Drag"><action name="Resize"><edge>bottomright</edge></action></mousebind>
    </context>
    <context name="Client">
      <mousebind button="Left" action="Press"><action name="Focus"/><action name="Raise"/></mousebind>
      <mousebind button="Middle" action="Press"><action name="Focus"/><action name="Raise"/></mousebind>
      <mousebind button="Right" action="Press"><action name="Focus"/><action name="Raise"/></mousebind>
    </context>
    <context name="Icon">
      <mousebind button="Left" action="Press"><action name="Focus"/><action name="Raise"/><action name="ShowMenu"><menu>client-menu</menu></action></mousebind>
      <mousebind button="Right" action="Press"><action name="Focus"/><action name="Raise"/><action name="ShowMenu"><menu>client-menu</menu></action></mousebind>
    </context>
    <context name="AllDesktops">
      <mousebind button="Left" action="Press"><action name="Focus"/><action name="Raise"/><action name="Unshade"/></mousebind>
      <mousebind button="Left" action="Click"><action name="ToggleOmnipresent"/></mousebind>
    </context>
    <context name="Shade">
      <mousebind button="Left" action="Press"><action name="Focus"/><action name="Raise"/></mousebind>
      <mousebind button="Left" action="Click"><action name="ToggleShade"/></mousebind>
    </context>
    <context name="Iconify">
      <mousebind button="Left" action="Press"><action name="Focus"/><action name="Raise"/></mousebind>
      <mousebind button="Left" action="Click"><action name="Iconify"/></mousebind>
    </context>
    <context name="Maximize">
      <mousebind button="Left" action="Press"><action name="Focus"/><action name="Raise"/><action name="Unshade"/></mousebind>
      <mousebind button="Left" action="Click"><action name="ToggleMaximize"/></mousebind>
    </context>
    <context name="Close">
      <mousebind button="Left" action="Press"><action name="Focus"/><action name="Raise"/><action name="Unshade"/></mousebind>
      <mousebind button="Left" action="Click"><action name="Close"/></mousebind>
    </context>
    <context name="Root">
      <mousebind button="Right" action="Press">
        <action name="ShowMenu"><menu>root-menu</menu></action>
      </mousebind>
    </context>
  </mouse>
  <applications>
    <application title="riceos-start">
      <decor>no</decor>
      <skip_taskbar>yes</skip_taskbar>
      <layer>above</layer>
      <focus>yes</focus>
      <position force="yes"><x>0</x><y>-44</y></position>
    </application>
  </applications>
</openbox_config>
RCXML
MENU="$MNT/etc/xdg/openbox/menu.xml"
if grep -q 'id="root-menu"' "$MENU" 2>/dev/null; then
  # 항목들을 한 덩어리로 모아 한 번에 넣는다 (한 줄씩 넣으면 순서가 거꾸로 된다)
  SNIP="$(mktemp)"
  for item in \
    '디스플레이 설정|riceos-ui --display' \
    '소리 설정|pavucontrol' \
    '개인 설정 (테마)|lxappearance' \
    '프린터 설정|system-config-printer' \
    '파일 관리자|pcmanfm' \
    '문서 보기|zathura' \
    '이미지 보기|gthumb' \
    '동영상 재생|mpv' \
    'RICEOS 설정|riceos-ui' \
    '빠른 설정|riceos-ui --quick' \
    'RICEOS 설치|riceos-ui --install' \
    '앱 목록|riceos-ui --menu'; do
    label="${item%%|*}"; cmd="${item##*|}"
    printf '    <item label="%s"><action name="Execute"><command>%s</command></action></item>\n' "$label" "$cmd" >> "$SNIP"
  done
  sed -i "/<menu id=\"root-menu\"/r $SNIP" "$MENU"
  rm -f "$SNIP"
else
  echo "참고: 우클릭 메뉴(root-menu)를 찾지 못해 설정 항목을 건너뜁니다"
fi

# 설치한 앱의 바로가기를 바탕화면에 자동으로 만든다 (apt 설치/삭제 뒤, 그리고 세션 시작 때)
cat > "$MNT/usr/local/bin/riceos-sync-desktop" <<'SYNC'
#!/bin/sh
D=/home/riceos/Desktop
A="$D/보조프로그램"
mkdir -p "$D" "$A"
# 바탕화면 맨 위에는 RICEOS 기본 아이콘(riceos-*)만 두고, 나머지 앱은 "보조프로그램" 폴더에 모은다
for f in /usr/share/applications/*.desktop; do
  [ -f "$f" ] || continue
  grep -qi '^NoDisplay=true' "$f" && continue
  n=$(basename "$f")
  case "$n" in
    riceos-*) ln -sf "$f" "$D/$n"; rm -f "$A/$n" ;;
    *) ln -sf "$f" "$A/$n"; rm -f "$D/$n" ;;
  esac
done
for l in "$D"/*.desktop "$A"/*.desktop; do [ -L "$l" ] && [ ! -e "$l" ] && rm -f "$l"; done
chown -R riceos:riceos "$D" 2>/dev/null || true
exit 0
SYNC
chmod 755 "$MNT/usr/local/bin/riceos-sync-desktop"
mkdir -p "$MNT/etc/apt/apt.conf.d"
cat > "$MNT/etc/apt/apt.conf.d/99riceos-desktop" <<'HOOK'
DPkg::Post-Invoke { "/usr/local/bin/riceos-sync-desktop || true"; };
HOOK

# 표준 X 설정: 커널 DRM(modesetting) 과 libinput 사용, 커서는 그래픽 카드 하드웨어 커서
mkdir -p "$MNT/etc/X11/xorg.conf.d"
cat > "$MNT/etc/X11/xorg.conf.d/10-riceos.conf" <<'XCONF'
Section "Device"
    Identifier "riceos-gpu"
    Driver "modesetting"
    Option "AccelMethod" "glamor"
    Option "SWcursor" "off"
EndSection

Section "InputClass"
    Identifier "riceos-input"
    MatchIsPointer "on"
    Driver "libinput"
EndSection
XCONF

# Chromium 기본 플래그: GPU 가속을 끈다. X(fbdev/모드세팅) 환경에서 GPU 렌더링이 실패하면 창이 검게 나온다.
# Debian 의 chromium 실행기는 /etc/chromium.d/ 를 읽어 CHROMIUM_FLAGS 를 붙인다 (메뉴와 바로가기 모두 적용).
mkdir -p "$MNT/etc/chromium.d"
cat > "$MNT/etc/chromium.d/riceos" <<'CHFLAGS'
# RICEOS: 검은 창을 막기 위해 GPU 가속을 끈다 (소프트웨어 렌더링)
CHROMIUM_FLAGS="$CHROMIUM_FLAGS --disable-gpu --disable-gpu-compositing"
CHFLAGS
# Chromium 이 화면을 검게 만들 때 쓰는 안전 모드 실행 항목 (GPU 가속 끔)
mkdir -p "$MNT/usr/local/share/applications"
cat > "$MNT/usr/local/share/applications/riceos-chromium-safe.desktop" <<'DESK'
[Desktop Entry]
Type=Application
Name=Chromium (안전 모드)
Name[ko]=Chromium (안전 모드)
Comment=GPU 가속을 끄고 실행 (화면이 검게 나올 때)
Exec=dbus-run-session -- chromium --disable-gpu --disable-gpu-compositing %U
Icon=chromium
Terminal=false
Categories=Network;WebBrowser;
DESK

# RICEOS 설정 / 앱 목록 바로가기
mkdir -p "$MNT/usr/share/applications"
cat > "$MNT/usr/share/applications/riceos-settings.desktop" <<'DESK'
[Desktop Entry]
Type=Application
Name=RICEOS Settings
Name[ko]=RICEOS 설정
Name[ja]=RICEOS 設定
Name[zh]=RICEOS 设置
Name[fr]=Réglages RICEOS
Name[es]=Ajustes de RICEOS
Comment=네트워크, 소리, 디스플레이, 프린터 설정
Exec=riceos-ui
Icon=preferences-system
Terminal=false
Categories=Settings;
DESK
cat > "$MNT/usr/share/applications/riceos-quick.desktop" <<'DESK'
[Desktop Entry]
Type=Application
Name=Quick Settings
Name[ko]=빠른 설정
Name[ja]=クイック設定
Name[zh]=快速设置
Name[fr]=Réglages rapides
Name[es]=Ajustes rápidos
Comment=무선과 소리를 빠르게 조절
Exec=riceos-ui --quick
Icon=preferences-system
Terminal=false
Categories=Settings;
DESK
cat > "$MNT/usr/share/applications/riceos-install.desktop" <<'DESK'
[Desktop Entry]
Type=Application
Name=Install RICEOS
Name[ko]=RICEOS 설치
Name[ja]=RICEOS のインストール
Name[zh]=安装 RICEOS
Name[fr]=Installer RICEOS
Name[es]=Instalar RICEOS
Comment=USB 임시 모드에서 하드디스크에 설치
Exec=riceos-ui --install
Icon=system-software-install
Terminal=false
Categories=System;
DESK
cat > "$MNT/usr/share/applications/riceos-apps.desktop" <<'DESK'
[Desktop Entry]
Type=Application
Name=Apps
Name[ko]=앱 목록
Name[ja]=アプリ一覧
Name[zh]=应用列表
Name[fr]=Applications
Name[es]=Aplicaciones
Comment=설치된 앱 보기
Exec=riceos-ui --menu
Icon=view-app-grid-symbolic
Terminal=false
Categories=Utility;
DESK

# riceos 사용자는 관리자(root 권한)다. 대부분의 명령은 묻지 않고 실행한다.
# 하드디스크 설치(riceos-install)만 riceos 비밀번호를 다시 묻는다 (riceos-auth 파일의 PASSWD 규칙).
# sudoers.d 는 이름 순서대로 읽고 뒤의 규칙이 이기므로, 이 파일 이름은 riceos-auth 보다 앞이어야 한다.
cat > "$MNT/etc/sudoers.d/riceos-admin" <<'ADMIN'
riceos ALL=(ALL:ALL) NOPASSWD: ALL
ADMIN
chmod 440 "$MNT/etc/sudoers.d/riceos-admin"

# 와이파이 연결 권한: 화면은 로그인 세션 없이 riceos 사용자로 뜨므로, NetworkManager 가 연결 추가를 막는다
# ("Not authorized to control networking"). riceos 사용자에게만 네트워크 설정 권한을 준다.
mkdir -p "$MNT/etc/polkit-1/rules.d"
cat > "$MNT/etc/polkit-1/rules.d/49-riceos-network.rules" <<'POLKIT'
polkit.addRule(function(action, subject) {
    if (subject.user == "riceos" && (
        action.id == "org.freedesktop.NetworkManager.network-control" ||
        action.id == "org.freedesktop.NetworkManager.settings.modify.system" ||
        action.id == "org.freedesktop.NetworkManager.settings.modify.own" ||
        action.id == "org.freedesktop.NetworkManager.wifi.share.protected" ||
        action.id == "org.freedesktop.NetworkManager.wifi.share.open")) {
        return polkit.Result.YES;
    }
});
POLKIT

# 리눅스 실행 파일(ELF)을 더블클릭하면 텍스트로 열지 않고 바로 실행한다
cat > "$MNT/usr/local/bin/riceos-run" <<'RUN'
#!/bin/sh
# RICEOS: 실행 파일을 연다. 실행 권한이 없으면 먼저 준다 (USB 같은 곳의 파일 대비)
f="$1"
[ -f "$f" ] || exit 1
[ -x "$f" ] || chmod +x "$f" 2>/dev/null
exec "$f"
RUN
chmod 755 "$MNT/usr/local/bin/riceos-run"
cat > "$MNT/usr/share/applications/riceos-run.desktop" <<'DESK'
[Desktop Entry]
Type=Application
Name=RICEOS 실행
Exec=/usr/local/bin/riceos-run %f
MimeType=application/x-executable;application/x-pie-executable;application/x-sharedlib;
NoDisplay=true
DESK
mkdir -p "$MNT/etc/xdg"
cat > "$MNT/etc/xdg/mimeapps.list" <<'MIME'
[Default Applications]
application/x-executable=riceos-run.desktop
application/x-pie-executable=riceos-run.desktop
application/x-sharedlib=riceos-run.desktop
MIME

chroot "$MNT" /bin/bash -e <<'CHROOT'
locale-gen
id riceos >/dev/null 2>&1 || useradd -m -s /bin/bash -G audio,video,input,sudo,lpadmin riceos
# 기본 비밀번호는 두지 않는다: root 는 잠그고, riceos 는 처음 설정(로그인 화면)에서 정한 비밀번호로 열린다
passwd -l root || true
passwd -l riceos || true
dconf update 2>/dev/null || true
sed -i 's/^GRUB_TIMEOUT=.*/GRUB_TIMEOUT=0/' /etc/default/grub
sed -i 's/^GRUB_CMDLINE_LINUX_DEFAULT=.*/GRUB_CMDLINE_LINUX_DEFAULT="quiet splash loglevel=3 udev.log_level=3 rd.udev.log_level=3 systemd.show_status=false vt.global_cursor_default=0"/' /etc/default/grub
grep -q GRUB_TIMEOUT_STYLE /etc/default/grub || echo 'GRUB_TIMEOUT_STYLE=hidden' >> /etc/default/grub
# --removable: EFI/BOOT/BOOTX64.EFI 로 설치 (어느 PC에서든 USB로 부팅)
grub-install --target=x86_64-efi --efi-directory=/boot/efi --removable --no-nvram
# Secure Boot 이 켜진 PC 에서도 뜨도록 서명된 shim/grub 을 EFI/BOOT 에 넣는다 (미서명 grub 은 거부되어 Windows 로 넘어감)
mkdir -p /boot/efi/EFI/BOOT
if [ -f /usr/lib/shim/shimx64.efi.signed ] && [ -f /usr/lib/grub/x86_64-efi-signed/grubx64.efi.signed ]; then
  cp /usr/lib/shim/shimx64.efi.signed /boot/efi/EFI/BOOT/BOOTX64.EFI
  cp /usr/lib/grub/x86_64-efi-signed/grubx64.efi.signed /boot/efi/EFI/BOOT/grubx64.efi
  [ -f /usr/lib/shim/mmx64.efi ] && cp /usr/lib/shim/mmx64.efi /boot/efi/EFI/BOOT/mmx64.efi || true
  # 설정 찾기: 루트 파티션의 grub.cfg 를 찾아 읽는다 (UUID 를 몰라도 됨)
  cat > /boot/efi/EFI/BOOT/grub.cfg <<'EOG'
search --no-floppy --file --set=root /boot/grub/grub.cfg
configfile ($root)/boot/grub/grub.cfg
EOG
  echo "[부팅] 서명된 shim/grub 을 EFI/BOOT 에 넣었습니다 (Secure Boot 지원)"
else
  echo "경고: 서명된 shim/grub 이 없어 미서명 부트로더만 쓰입니다 (Secure Boot 가 켜진 PC에서 Windows 로 넘어갈 수 있음)"
fi
# 부팅 설정 파일(/boot/grub/grub.cfg) 만들기: 이게 없으면 USB 가 검은 화면에 커서만 깜박인다
systemctl disable systemd-networkd.service systemd-networkd.socket 2>/dev/null || true
systemctl enable riceos-ui.service NetworkManager.service systemd-resolved.service riceos-sound.service
systemctl enable alsa-restore.service 2>/dev/null || true
systemctl mask getty@tty1.service
# 부팅 화면 테마를 기본으로 정하고 initramfs에 넣는다 (부팅 초기부터 로고와 바가 보이게)
# 부팅 화면 기본값 지정. 실패해도 이미지 만들기는 계속한다 (부팅 화면은 꾸밈이라서)
# two-step 플러그인이 어느 패키지에 있는지 빌드 로그에 남긴다 (진단용)
echo "[진단] plymouth 플러그인:"; ls /usr/lib/x86_64-linux-gnu/plymouth/ 2>/dev/null | head -40 || true
echo "[진단] plymouth 패키지 안의 two-step:"; dpkg -L plymouth plymouth-themes 2>/dev/null | grep -i "two-step" || echo "[진단] 두 패키지 어디에도 two-step 없음"
dpkg -S two-step.so 2>/dev/null || echo "[진단] two-step.so 를 가진 설치된 패키지 없음"
# two-step 플러그인이 있으면 riceos 화면을 쓰고, 없으면 plymouth 기본 text 화면으로 바꾼다.
# (플러그인이 없는 채로 두면 부팅 화면이 떴다가 바로 사라진다)
TWO=$(ls /usr/lib/x86_64-linux-gnu/plymouth/two-step.so 2>/dev/null || true)
if [ -n "$TWO" ] && plymouth-set-default-theme riceos; then
  echo "[부팅 화면] riceos 테마 사용"
else
  echo "경고: two-step 플러그인이 없어 기본 text 부팅 화면을 씁니다"
  plymouth-set-default-theme text || echo "경고: text 부팅 화면도 설정하지 못했습니다"
  sed -i 's/^Theme=.*/Theme=text/' /etc/plymouth/plymouthd.conf 2>/dev/null || true
fi
# USB 무선랜 드라이버 (커널에 없는 Realtek 계열). 각 드라이버는 이 이미지 커널에 맞춰 따로 빌드한다.
# 한 개가 실패해도 나머지와 이미지 생성은 계속한다 (경고만 남김).
# 앞 단계에서 systemd-resolved 가 설치되며 resolv.conf 가 127.0.0.53 스텁으로 바뀔 수 있다.
# chroot 안에는 그 스텁을 받아 줄 서비스가 없으므로, 여기서 DNS 를 다시 쓴다.
rm -f /etc/resolv.conf
printf 'nameserver 8.8.8.8\nnameserver 1.1.1.1\n' > /etc/resolv.conf
apt-get update -qq || echo "경고: apt 목록 갱신 실패"
# 설치 기록은 파일에 남기고, 실패하면 E:/W: 줄을 빌드 로그에 그대로 찍는다
if ! apt-get install -y -o Dpkg::Options::=--force-confold -o Dpkg::Options::=--force-confdef build-essential git dkms linux-headers-amd64 >/var/log/riceos-apt-driver.log 2>&1; then
  echo "경고: 빌드 도구 설치 실패 (무선랜 드라이버 빌드 생략)"
  grep -E "^(E|W):" /var/log/riceos-apt-driver.log | head -40 || true
  tail -n 40 /var/log/riceos-apt-driver.log || true
fi
echo "[디스크] 드라이버 단계 전: $(df -BG --output=avail "$MNT" | tail -1 | tr -d ' ')"
# NVIDIA 드라이버는 기본적으로 받지 않는다 (RICEOS_NVIDIA=1 을 주면 받는다)
if [ "${RICEOS_NVIDIA:-0}" = 1 ]; then
  chroot "$MNT" apt-get clean 2>/dev/null || true
  rm -rf "$MNT/var/lib/apt/lists/"* 2>/dev/null || true
  chroot "$MNT" apt-get update -qq || echo "경고: 드라이버 단계 apt 목록 갱신 실패"
# NVIDIA 그래픽 (GeForce RTX 3060 등): 공식 드라이버를 이 이미지의 커널에 맞춰 빌드한다 (non-free)
# 헤더가 준비된 뒤에 설치해야 DKMS 가 모듈을 만든다. 실패해도 이미지 만들기는 계속한다.
# chroot 안의 uname -r 은 빌드 서버(호스트)의 커널을 돌려주므로, DKMS 가 엉뚱한 커널용으로 빌드한다.
# 그래서 설치하는 동안만 uname -r 이 이미지 커널 이름을 돌려주게 한다.
KVN=$(ls /lib/modules | sort -V | tail -1)
printf '#!/bin/sh\nif [ "$1" = "-r" ]; then echo "%s"; else exec /bin/uname "$@"; fi\n' "$KVN" > /usr/local/bin/uname
chmod +x /usr/local/bin/uname
if apt-get install -y -qq -o Dpkg::Options::=--force-confold -o Dpkg::Options::=--force-confdef nvidia-driver >/var/log/riceos-nvidia.log 2>&1; then
  echo "[그래픽] NVIDIA 드라이버 설치 완료 ($KVN)"
else
  echo "경고: NVIDIA 드라이버 설치 실패 (로그: /var/log/riceos-nvidia.log). 기본 nouveau 드라이버로 뜹니다"
  echo "경고: [진단] nvidia 설치 로그 마지막 줄:"; tail -n 25 /var/log/riceos-nvidia.log | sed 's/^/경고: [nvidia] /' || true
  for ml in /var/lib/dkms/nvidia-current/*/build/make.log; do
    [ -f "$ml" ] && { echo "경고: [진단] DKMS 빌드 로그 $ml:"; grep -E "error|Error|No such" "$ml" | head -15 | sed 's/^/경고: [dkms] /'; }
  done
fi
rm -f /usr/local/bin/uname
fi
KV=$(ls /lib/modules | sort -V | tail -1)
[ -d "/lib/modules/$KV/build" ] || echo "경고: $KV 커널 헤더가 없습니다 (드라이버 빌드가 실패할 수 있음)"
for repo in \
    https://github.com/morrownr/88x2bu-20210702 \
    https://github.com/RinCat/RTL88x2BU-Linux-Driver \
    https://github.com/morrownr/8821au-20210708; do
  name=$(basename "$repo")
  # 같은 칩(RTL8812BU/8822BU)용 두 번째 드라이버는 첫 번째가 실패했을 때만 받는다
  if [ "$name" = "RTL88x2BU-Linux-Driver" ] && [ -f "/lib/modules/$KV/kernel/drivers/net/wireless/88x2bu.ko" ]; then
    continue
  fi
  src="/usr/src/$name-src"
  rm -rf "$src"
  owner=$(basename "$(dirname "$repo")")
  # 1) git 으로 받기 → 2) 5초 뒤 다시 → 3) 같은 저장소의 압축 파일(codeload)로 받기
  if ! { git clone --depth 1 "$repo" "$src" \
      || { sleep 5; rm -rf "$src"; git clone --depth 1 "$repo" "$src"; } \
      || { echo "[무선랜] $name: git 이 안 돼 압축 파일로 받습니다"; rm -rf "$src"; mkdir -p "$src" \
           && curl -fsSL --retry 3 "https://codeload.github.com/$owner/$name/tar.gz/HEAD" | tar xz --strip-components=1 -C "$src"; }; }; then
    echo "경고: $name 소스를 받지 못했습니다. 이 칩의 USB 무선랜은 동작하지 않을 수 있습니다"
    continue
  fi
  # 빌드 오류는 워크플로 로그에 그대로 남긴다 (실패 원인 확인용)
  LOG="/var/log/riceos-build-$name.log"
  if make -C "$src" KVER="$KV" KSRC="/lib/modules/$KV/build" -j"$(nproc)" >"$LOG" 2>&1; then
    for ko in $(find "$src" -name "*.ko"); do
      install -D -m 644 "$ko" "/lib/modules/$KV/kernel/drivers/net/wireless/$(basename "$ko")"
    done
    echo "[무선랜] $name 빌드 완료 ($KV)"
    # 같은 칩을 커널 내장 드라이버(rtw88)와 중복 바인딩하지 않도록, 직접 빌드가 성공한 칩만 내장 쪽을 막는다
    case "$name" in
      88x2bu*|RTL88x2BU*) echo "blacklist rtw88_8822bu" >> /etc/modprobe.d/riceos-wifi.conf ;;
      8821cu*) echo "blacklist rtw88_8821cu" >> /etc/modprobe.d/riceos-wifi.conf ;;
    esac
  else
    echo "경고: $name 빌드 실패 (커널 $KV)"; echo "경고: [진단] $name 오류 줄:"; grep -E "error|Error" "$LOG" | head -8 | sed "s/^/경고: [$name] /"
  fi
done
depmod "$KV" || true
# 설치된 시스템은 systemd-resolved 를 쓴다 (빌드가 끝난 뒤에 연결)
ln -sf /run/systemd/resolve/stub-resolv.conf /etc/resolv.conf
update-initramfs -u -k all
apt-get clean
CHROOT
# 운영체제 이름: Linux Sunnix (시스템 정보, lsb_release 등에 표시). ID 는 데비안 그대로 둬서 패키지 관리가 깨지지 않게 한다
cat > "$MNT/usr/lib/os-release" <<'OSREL'
PRETTY_NAME="Linux Sunnix"
NAME="Linux Sunnix"
VERSION_ID="13"
VERSION="13 (trixie)"
VERSION_CODENAME=trixie
ID=debian
ID_LIKE=debian
LOGO=linux-sunnix
HOME_URL="https://github.com/songsiwon001-a11y/riceos"
OSREL
ln -sf ../usr/lib/os-release "$MNT/etc/os-release"
# 부팅 설정 파일을 직접 쓴다 (chroot 안의 update-grub 은 장치 확인에서 실패하는 경우가 있다)
mkdir -p "$MNT/boot/grub"
cat > "$MNT/boot/grub/grub.cfg" <<GRUBCFG
set timeout=0
set default=0
insmod part_gpt
insmod ext2
insmod png
search --no-floppy --fs-uuid --set=root $ROOT_UUID
background_image /boot/grub/linux-sunnix-bg.png
menuentry "Linux Sunnix" {
    linux /vmlinuz root=UUID=$ROOT_UUID $KCMD
    initrd /initrd.img
}
GRUBCFG
if grep -q "/vmlinuz" "$MNT/boot/grub/grub.cfg" && [ -e "$MNT/vmlinuz" ] && [ -e "$MNT/initrd.img" ]; then
  echo "[부팅] grub.cfg 작성 완료"
else
  echo "오류: 커널 또는 initrd 가 없어 부팅 설정을 만들지 못했습니다"
fi

# 아래 막대(tint2): 왼쪽 시작 버튼(RICEOS 아이콘) → 시작 화면, 가운데 작업 목록, 오른쪽 트레이와 시계
install -D -m 644 "$HERE/branding/riceos_start.png" "$MNT/usr/share/pixmaps/riceos-start.png"
# Linux Sunnix 로고 (직접 그린 것): 시스템 아이콘 테마와 pixmaps 에 넣는다
install -D -m 644 "$HERE/branding/linux-sunnix.svg" "$MNT/usr/share/icons/hicolor/scalable/apps/linux-sunnix.svg"
install -D -m 644 "$HERE/branding/linux-sunnix-256.png" "$MNT/usr/share/pixmaps/linux-sunnix.png"
install -D -m 644 "$HERE/branding/linux-sunnix-48.png" "$MNT/usr/share/icons/hicolor/48x48/apps/linux-sunnix.png"
install -D -m 644 "$HERE/branding/grub-background.png" "$MNT/boot/grub/linux-sunnix-bg.png"
cat > "$MNT/usr/local/share/applications/riceos-start.desktop" <<'STARTDESK'
[Desktop Entry]
Type=Application
Name=시작
Exec=riceos-start-toggle
Icon=/usr/share/pixmaps/linux-sunnix.png
NoDisplay=true
STARTDESK
cat > "$MNT/usr/local/bin/riceos-start-toggle" <<'TOGGLE'
#!/bin/sh
# 시작 메뉴 토글: 열려 있으면 닫고, 닫혀 있으면 연다 (윈도우 키와 시작 버튼이 같이 쓴다)
if pkill -f "riceos-ui --start" 2>/dev/null; then exit 0; fi
exec riceos-ui --start
TOGGLE
chmod 755 "$MNT/usr/local/bin/riceos-start-toggle"
cat > "$MNT/usr/local/bin/riceos-panel" <<'PANEL'
#!/bin/sh
# RICEOS 아래 막대 실행. 설정 파일이 잘못되면 tint2 기본 설정으로 띄운다
tint2 -c "$HOME/.config/tint2/tint2rc" || exec tint2
PANEL
chmod 755 "$MNT/usr/local/bin/riceos-panel"
mkdir -p "$MNT/home/riceos/.config/tint2"
cat > "$MNT/home/riceos/.config/tint2/tint2rc" <<'TINT'
# RICEOS 아래 막대
rounded = 0
border_width = 0
background_color = #000000 85
border_color = #000000 0

#---- Background 2 (작업 목록 항목)
rounded = 0
border_width = 0
background_color = #ffffff 15
border_color = #000000 0

panel_monitor = all
panel_position = bottom center horizontal
panel_size = 100% 40
panel_margin = 0 0
panel_padding = 6 0 6
panel_background_id = 1
wm_menu = 0
panel_dock = 0
panel_layer = top
panel_items = LTSC
autohide = 0

taskbar_mode = single_desktop
taskbar_padding = 4 2 4
taskbar_background_id = 0
taskbar_active_background_id = 0
task_icon = 1
task_text = 1
task_maximum_size = 180 35
task_font = sans 10
task_font_color = #ffffff 100
task_active_font_color = #ffffff 100
task_background_id = 2
task_active_background_id = 2

launcher_padding = 6 4 6
launcher_background_id = 0
launcher_icon_size = 28
launcher_item_app = /usr/local/share/applications/riceos-start.desktop

time1_format = %H:%M
time1_font = sans 10
clock_font_color = #ffffff 100
clock_padding = 8 0
clock_background_id = 0

systray = 1
systray_padding = 4 4 4
systray_background_id = 0
systray_sort = ascending
systray_icon_size = 22
TINT
chroot "$MNT" chown -R riceos:riceos /home/riceos/.config/tint2 || true
# 클립보드 기록(Win+V): 최근 20개만 보관 (CopyQ 설정)
mkdir -p "$MNT/home/riceos/.config/copyq"
cat > "$MNT/home/riceos/.config/copyq/copyq.conf" <<'CQ'
[General]
maxitems=20
CQ
chroot "$MNT" chown -R riceos:riceos /home/riceos/.config
# 바탕화면: 단색 계란 노른자색 (노란색과 주황색 사이). pcmanfm 설정 + 세션 시작 때 X 루트 창 색
YOLK="#F5B52E"
PCM="$MNT/home/riceos/.config/pcmanfm/default"
mkdir -p "$PCM"
cat > "$PCM/desktop-items-0.conf" <<PCMDESK
[*]
wallpaper_common=1
wallpaper=
wallpaper_mode=color
desktop_bg=$YOLK
desktop_fg=#000000
desktop_shadow=#000000
PCMDESK
cat > "$PCM/pcmanfm.conf" <<PCMCONF
[desktop]
wallpaper_mode=color
bg_color=$YOLK
PCMCONF
chroot "$MNT" chown -R riceos:riceos /home/riceos/.config

# update-grub 대신 grub.cfg 직접 작성 (chroot 안 grub-probe 가 loop 장치를 찾지 못함)
mkdir -p "$MNT/boot/grub"
cat > "$MNT/boot/grub/grub.cfg" <<GRUBCFG
set timeout=0
set default=0
insmod part_gpt
insmod ext2
# 글 모드(DOS 같은 텍스트 화면) 대신 그래픽 화면을 쓴다: 검은 바탕
insmod all_video
insmod gfxterm
insmod png
set gfxmode=auto
set gfxpayload=keep
terminal_output gfxterm
set color_normal=white/black
set color_highlight=white/black
insmod png
search --no-floppy --fs-uuid --set=root $ROOT_UUID
background_image /boot/grub/linux-sunnix-bg.png
menuentry "Linux Sunnix (임시 모드: 저장되지 않음)" {
    linux /live/vmlinuz boot=live live-media-path=/live $KCMD
    initrd /live/initrd.img
}
GRUBCFG
test -e "$MNT/vmlinuz" && test -e "$MNT/initrd.img" || { echo "커널 또는 initrd 심볼릭 링크가 없습니다"; exit 1; }

echo "[7/7] 정리 (USB 임시 모드 자료 만들기)"
# 임시 모드: 루트 파일 시스템은 squashfs 로 읽기 전용이고, 부팅 때 RAM 오버레이를 씌운다.
# 그래서 USB 에서 바꾼 내용은 재부팅하면 사라진다. 저장하려면 설치 프로그램(riceos-install)을 쓴다.
for m in sys proc dev/pts dev; do umount "$MNT/$m" 2>/dev/null || true; done
WORK="$(mktemp -d /tmp/riceos-sq.XXXXXX)"
# 마운트 지점 폴더(proc, sys, dev, run, tmp, boot/efi)는 남기고 안의 내용만 뺀다.
# (-e proc 처럼 쓰면 폴더까지 빠져서, 부팅 때 /dev, /proc 이 없어 커널 패닉이 난다)
for d in proc sys dev run tmp boot/efi; do mkdir -p "$MNT/$d"; done
mksquashfs "$MNT" "$WORK/filesystem.squashfs" -noappend -comp xz -no-progress -wildcards \
  -e 'proc/*' -e 'sys/*' -e 'dev/*' -e 'run/*' -e 'tmp/*' -e 'boot/efi/*'
mkdir -p "$MNT/live"
mv "$WORK/filesystem.squashfs" "$MNT/live/filesystem.squashfs"
rmdir "$WORK" 2>/dev/null || true
# 커널과 initrd 를 USB 의 /live 로 복사한다 (심볼릭 링크를 실제 파일로)
cp -L "$(ls -v "$MNT"/boot/vmlinuz-* | tail -1)" "$MNT/live/vmlinuz"
cp -L "$(ls -v "$MNT"/boot/initrd.img-* | tail -1)" "$MNT/live/initrd.img"
# USB 에는 부트 자료와 squashfs 만 남기고 나머지 루트 파일 시스템은 지운다
for d in "$MNT"/*; do
  case "$(basename "$d")" in live|boot|lost+found) continue ;; esac
  rm -rf "$d"
done
for d in "$MNT"/boot/*; do
  case "$(basename "$d")" in grub|efi) continue ;; esac
  rm -rf "$d"
done
test -s "$MNT/live/filesystem.squashfs" && test -s "$MNT/live/vmlinuz" && test -s "$MNT/live/initrd.img" \
  || { echo "임시 모드 자료를 만들지 못했습니다"; exit 1; }
sync
echo
echo "완료: $IMG"
echo "USB에 쓰기: Rufus에서 이 .img 를 선택 (DD 이미지 모드) — USB 전체가 지워집니다."
echo "USB 부팅은 임시 모드입니다: 바꾼 내용은 재부팅하면 사라집니다. 저장하려면 바탕화면의 '설치'를 쓰세요."
echo "비상용 콘솔: 처음 설정 뒤에 Ctrl+Alt+F2 → riceos / 설정한 비밀번호 (root 는 잠겨 있습니다)"

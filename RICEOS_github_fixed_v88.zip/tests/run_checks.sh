#!/bin/bash
# RICEOS 로컬 검사: 이 환경에서 돌릴 수 있는 것만 확인한다 (데비안 저장소 접근이 없어도 됨)
# 사용: bash tests/run_checks.sh   (프로젝트 루트에서)
cd "$(dirname "$0")/.." || exit 1
PASS=0; FAIL=0
ok()   { PASS=$((PASS+1)); echo "  [통과] $1"; }
bad()  { FAIL=$((FAIL+1)); echo "  [실패] $1"; }
check(){ if eval "$2" >/dev/null 2>&1; then ok "$1"; else bad "$1"; fi; }
T=$(mktemp -d)
trap 'rm -rf "$T"' EXIT

echo "1. 셸 스크립트 문법"
for f in linux/make_image.sh linux/riceos-* tests/*.sh; do
  [ -f "$f" ] || continue
  case "$f" in *.py|*.desktop|*.lua|*.conf|*.txt) continue;; esac
  check "$f" "bash -n '$f'"
done

echo "2. 파이썬 문법 + 번역 테스트"
check "riceos-ui.py 문법" "python3 -m py_compile linux/riceos-ui.py"
check "번역 키 검사 (tests/test_ui_i18n.py)" "python3 tests/test_ui_i18n.py | tail -1 | grep -q '실패: 0'"

echo "3. 창 관리자 설정(rc.xml) 형식"
python3 - "$T/rc.xml" <<'PY'
import re,sys
s=open('linux/make_image.sh',encoding='utf-8').read()
m=re.search(r'<openbox_config.*?</openbox_config>',s,re.S)
open(sys.argv[1],'w',encoding='utf-8').write(m.group(0) if m else '')
PY
check "rc.xml 이 XML 형식으로 맞음" "xmllint --noout '$T/rc.xml'"
check "마우스 설정 컨텍스트 19개 이상" "[ \$(grep -c '<context name=' '$T/rc.xml') -ge 19 ]"

echo "4. 바로가기(.desktop) 파일"
for f in linux/riceos-game-tools.desktop linux/file-manager-actions/*.desktop; do
  [ -f "$f" ] || continue
  check "$f" "grep -q '^\[Desktop Entry\]' '$f' && grep -q '^Exec=' '$f' && grep -q '^Name=' '$f'"
done

echo "5. 설치 도구: 남는 공간 계산 (가짜 parted 사용)"
mkdir -p "$T/bin"
cat > "$T/bin/parted" <<'PA'
#!/bin/bash
# 가짜 출력: 1번 ESP, 2번 루트, 그 뒤 남는 공간 9GiB
echo "BYT;"
echo "/dev/fake:32212254720B:scsi:512:512:gpt:USB:;"
echo "1:1048576B:536870911B:535822336B:fat32::boot, esp;"
echo "2:536870912B:4831838207B:4295967296B:ext4::;"
echo "1:4831838208B:32212254207B:27380415999B:free;"
PA
chmod +x "$T/bin/parted"
sed -n '/^usb_free_region()/,/^}/p' linux/riceos-install > "$T/fn.sh"
REG=$(PATH="$T/bin:$PATH" bash -c "source '$T/fn.sh'; usb_free_region fake")
check "남는 공간 시작값이 4831838208" "[ \"\$(echo '$REG' | awk '{print \$1}')\" = 4831838208 ]"
check "남는 공간이 8GiB 이상으로 계산됨" "[ \$(echo '$REG' | awk '{print \$2}') -ge 8589934592 ]"

echo "6. 패키지 선택 로직 (가짜 apt 사용)"
sed -n '/^cat > "\$MNT\/tmp\/riceos-pkgs.sh"/,/^PKGSH$/p' linux/make_image.sh | sed '1d;$d' > "$T/pk.sh"
cat > "$T/bin/apt-cache" <<'AC'
#!/bin/bash
case "$2" in a|b2|r1) echo "$2:"; echo "  Candidate: 1.0";; *) echo "N: unable";; esac
AC
printf '#!/bin/bash\necho "APT-GET $*"\n' > "$T/bin/apt-get"
chmod +x "$T/bin/"*
OUT=$(PATH="$T/bin:$PATH" REQ_PKGS="a r1" OPT_PKGS="b1|b2 zz" bash "$T/pk.sh")
check "선택 패키지 대체 설치(b2)" "echo '$OUT' | grep -q 'b2'"
check "없는 선택 패키지는 설치 명령에서 빠짐" "! echo '$OUT' | grep 'APT-GET' | grep -q 'zz'"
OUT2=$(PATH="$T/bin:$PATH" REQ_PKGS="a missing" OPT_PKGS="" bash "$T/pk.sh"; echo "rc=$?")
check "필수 패키지가 없으면 중단" "echo '$OUT2' | grep -q 'rc=1'"

echo "7. 압축 도구 왕복 (zip, tar.gz, tar.xz)"
if [ -x linux/riceos-archive ] && command -v zip >/dev/null; then
  mkdir -p "$T/src" && echo hello > "$T/src/a.txt" && echo world > "$T/src/b.txt"
  (cd "$T/src" && zip -qr "$T/t.zip" .) && check "zip 풀기 명령 존재" "command -v unzip"
else
  echo "  [건너뜀] zip 또는 riceos-archive 없음"
fi

echo
echo "결과: 통과 $PASS, 실패 $FAIL"
[ "$FAIL" -eq 0 ]

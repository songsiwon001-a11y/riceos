"""RICEOS UI 번역과 인코딩 검사 (GTK 없이 실행한다).
실행: python3 tests/test_ui_i18n.py   (프로젝트 루트에서)
"""
import sys, os, re, json, tempfile, subprocess, importlib.util
HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, os.path.join(HERE, "ui_stubs"))
spec = importlib.util.spec_from_file_location("ui", os.path.join(ROOT, "linux", "riceos-ui.py"))
ui = importlib.util.module_from_spec(spec); spec.loader.exec_module(ui)
fails = []
def check(name, cond):
    print(("PASS " if cond else "FAIL ") + name)
    if not cond: fails.append(name)

# 1) 모든 키가 여섯 언어를 모두 가진다 (빈 문장 없음)
missing = [(k, l) for k, d in ui.STRINGS.items() for l in ui.LANGS if not d.get(l)]
check("모든 키에 6개 언어 문장이 있다 (%d개 키)" % len(ui.STRINGS), not missing)
extra = [(k, l) for k, d in ui.STRINGS.items() for l in d if l not in ui.LANGS]
check("알 수 없는 언어 코드가 없다", not extra)

# 2) 자리표시자 이름이 언어마다 같다 (번역이 값을 빠뜨리면 format 에서 죽는다)
bad = []
for k, d in ui.STRINGS.items():
    sets = {l: frozenset(re.findall(r"\{(\w+)\}", d[l])) for l in ui.LANGS}
    if len(set(sets.values())) != 1: bad.append((k, sets))
check("자리표시자가 모든 언어에서 같다", not bad)

# 3) 깨진 글자(치환 문자, 흔한 깨짐 패턴)가 없다
moj = [(k, l) for k, d in ui.STRINGS.items() for l, s in d.items()
       if "�" in s or re.search("[ÃÂ][\x80-\xbf]", s) or s.encode("utf-8", "strict") is None]
check("문장에 깨진 글자가 없다", not moj)

# 4) 실제 언어별 표시
ui.set_lang("ja"); check("ja 번역", ui.t("login_go") == "ログイン")
ui.set_lang("zh"); check("zh 번역", ui.t("pw_mismatch") == "两次输入的密码不一致")
ui.set_lang("fr"); check("fr 번역", ui.t("login_go") == "Se connecter")
ui.set_lang("es"); check("es 번역 (자리표시자)", ui.t("connecting", ssid="Casa") == "Conectando a Casa...")
ui.set_lang("en"); check("en 번역", ui.t("nav_network") == "Network")
ui.set_lang("ko"); check("ko 번역", ui.t("login_go") == "로그인")
ui.set_lang("xx"); check("없는 언어는 무시 (ko 유지)", ui.t("login_go") == "로그인")
check("없는 키는 키 이름 그대로", ui.t("no_such_key_zzz") == "no_such_key_zzz")

# 5) 언어 고르는 순서: RICEOS_LANG > ui.json > LANG > ko
def pick(env, home_json=None):
    saved = dict(os.environ)
    try:
        for k in ("RICEOS_LANG", "LANG", "LC_ALL", "LC_MESSAGES", "LANGUAGE"): os.environ.pop(k, None)
        os.environ.update(env)
        home = tempfile.mkdtemp()
        if home_json is not None:
            d = os.path.join(home, ".config", "riceos"); os.makedirs(d)
            with open(os.path.join(d, "ui.json"), "w", encoding="utf-8") as f: f.write(home_json)
        os.environ["HOME"] = home
        return ui._pick_lang()
    finally:
        os.environ.clear(); os.environ.update(saved)
check("RICEOS_LANG 이 가장 우선", pick({"RICEOS_LANG": "fr", "LANG": "ja_JP.UTF-8"}, '{"lang":"es"}') == "fr")
check("ui.json 이 LANG 보다 우선", pick({"LANG": "ja_JP.UTF-8"}, '{"lang":"es"}') == "es")
check("LANG 접두사 zh_CN", pick({"LANG": "zh_CN.UTF-8"}) == "zh")
check("LANG fr_FR", pick({"LANG": "fr_FR.UTF-8"}) == "fr")
check("LANG C 는 한국어 기본값", pick({"LANG": "C"}) == "ko")
check("잘못된 ui.json 은 무시", pick({"LANG": "es_ES.UTF-8"}, "not json") == "es")
check("지원 안 되는 RICEOS_LANG 은 무시", pick({"RICEOS_LANG": "de", "LANG": "en_US.UTF-8"}) == "en")

# 6) 저장: ui.json 을 UTF-8 로 쓰고 다시 읽는다
home = tempfile.mkdtemp(); os.environ["HOME"] = home
check("save_lang 성공", ui.save_lang("ja") is True)
check("save_lang 거부 (없는 언어)", ui.save_lang("de") is False)
data = open(os.path.join(home, ".config/riceos/ui.json"), encoding="utf-8").read()
check("ui.json 내용", json.loads(data) == {"lang": "ja"})

# 7) 깨진 바이트가 있어도 run() 이 죽지 않고 치환 문자로 돌려준다
rc, out = ui.run(["sh", "-c", "printf 'ab\\377cd'"])
check("깨진 UTF-8 출력도 예외 없이 처리", rc == 0 and "ab" in out and "cd" in out and "�" in out)
rc, out = ui.run(["no-such-program-riceos"])
check("없는 프로그램 메시지는 현재 언어", rc == 127 and out)

# 8) 일본어·중국어 SSID, 여러 언어 장치 이름 파싱
nets = ui.parse_wifi("*:80:WPA2:自宅のWi-Fi\n:60:--:カフェ\n")
check("일본어 SSID 파싱", [n["ssid"] for n in nets] == ["自宅のWi-Fi", "カフェ"] and nets[1]["security"] == "open")
ui.set_lang("ja")
check("장치 목록 일본어", "無線" in ui.parse_devices("wlan0:wifi:connected:家のAP\n"))
ui.set_lang("ko")
mons = ui.parse_xrandr("HDMI-1 disconnected\nDP-1 connected primary 1920x1080+0+0\n   1920x1080 60.00*+\neDP-2 connected\n")
check("모니터 해상도 없으면 빈 문자열", mons[1]["mode"] == "" and mons[0]["mode"] == "1920x1080")

# 9) 시스템 정보 스크립트 언어별 항목 이름
def sysinfo(lang):
    env = dict(os.environ, RICEOS_LANG=lang)
    return subprocess.run(["sh", os.path.join(ROOT, "linux", "riceos-sysinfo")], env=env, capture_output=True,
                          encoding="utf-8", errors="replace").stdout
for lang, word in (("ko", "시스템:"), ("en", "System:"), ("ja", "システム:"), ("zh", "系统:"), ("fr", "Système:"), ("es", "Sistema:")):
    out = sysinfo(lang)
    check("sysinfo %s 항목 이름" % lang, word in out)
check("sysinfo 알 수 없는 언어는 영어", "System:" in sysinfo("de"))

# 10) GTK 화면 흐름 (가짜 GTK)
import gi
from gi.repository import Gtk
class FakeEntry(Gtk.Magic):
    value = ""
    def get_text(self): return self.value
    def set_text(self, t): self.value = t
Gtk.PasswordEntry = FakeEntry
def last_msg(w):
    for n, a, k in reversed(w.msg.calls):
        if n == "set_text": return a[0]
ui.set_lang("ko")
calls = []
ui.auth_set = lambda pw: (calls.append(("set", pw)) or (True, ""))
ui.auth_check = lambda pw: (calls.append(("check", pw)) or (pw == "secret", ""))
done = []
g = ui.GateWindow(None, True, lambda: done.append(1))
g.entry.value = "a"; g.entry2.value = "b"; g.submit()
check("ko 설정 불일치 메시지", last_msg(g) == "두 비밀번호가 다릅니다" and calls == [])
ui.set_lang("ja")
g = ui.GateWindow(None, False, lambda: done.append(1))
g.entry.value = "wrong"; g.submit()
check("ja 로그인 실패 메시지", last_msg(g) == "パスワードが正しくありません")
g.entry.value = "secret"; g.submit()
check("ja 로그인 성공 후 열림", done == [1])
ui.set_lang("ko")
ui.run = lambda cmd, timeout=20, stdin_text=None: (1, "")
q = ui.QuickWindow(None)
check("빠른 설정 창 생성", q is not None)
ui.set_lang("ko")


# 11) 설치 프로그램: 오류 코드와 단계 이름이 모두 번역 키로 있다
inst = os.path.join(ROOT, "linux", "riceos-install")
src = open(inst, encoding="utf-8").read()
codes = set(re.findall(r"fail ([A-Z_]+)", src))
check("설치 오류 %d개가 모두 err_ 번역을 가진다" % len(codes),
      codes and all(("err_" + c) in ui.STRINGS for c in codes))
steps = set(re.findall(r'echo "STEP (\w+)"', src))
check("설치 단계 %d개가 모두 step_ 번역을 가진다" % len(steps),
      steps and all(("step_" + x) in ui.STRINGS for x in steps))
def inst_run(*args):
    r = subprocess.run(["sh", inst] + list(args), capture_output=True, encoding="utf-8", errors="replace")
    return r.stdout.strip()
check("확인 이름이 다르면 거부", inst_run("install", "sda", "sdb") == "ERROR CONFIRM_MISMATCH")
check("잘못된 디스크 이름 거부", inst_run("install", "../etc", "../etc") == "ERROR BAD_DISK")
check("임시 모드가 아니면 설치 거부", inst_run("install", "vda", "vda") in ("ERROR NOT_LIVE", "ERROR NOT_ROOT"))
check("알 수 없는 명령은 사용법", inst_run("bogus").startswith("사용법"))
check("is_live 는 bool", isinstance(ui.is_live(), bool))
check("용량 표시", ui.human_size(500e9) == "500.0 GB" and ui.human_size("x") == "?")

# 화면 설정: xrandr 해석, 권장 해상도/주사율, 위치 계산, 복제/확장 명령
XR = """Screen 0: minimum 320 x 200, current 2944 x 1080, maximum 16384 x 16384
HDMI-1 connected primary 1920x1080+0+0 (normal left inverted right x axis y axis) 527mm x 296mm
   3840x2160     30.00
   1920x1080     60.00*+  50.00
   1280x720      60.00
DP-1 connected 1024x768+1920+0 (normal left inverted right x axis y axis) 310mm x 230mm
   1280x1024     75.02    60.02
   1024x768      75.03*   60.00+
   800x600       60.32
VGA-1 disconnected (normal left inverted right x axis y axis)
"""
mons = ui.parse_xrandr_full(XR)
check("xrandr 해석: 연결된 모니터 2개 (끊긴 것 제외)", [m["name"] for m in mons] == ["HDMI-1", "DP-1"])
check("권장 해상도/주사율 (+) 을 고른다", mons[0]["pref_res"] == "1920x1080" and mons[0]["pref_rate"] == "60.00")
check("DP-1 권장 주사율 60.00 (현재 75.03 이 아님)", mons[1]["pref_res"] == "1024x768" and mons[1]["pref_rate"] == "60.00")
check("주사율 목록은 해상도별로", ui.rates_for(mons[0], "1920x1080") == ["60.00", "50.00"])
st = [{"name": "HDMI-1", "res": "1920x1080", "rate": "60.00"},
      {"name": "DP-1", "res": "1024x768", "rate": "60.00", "anchor": "HDMI-1", "side": "right"}]
check("오른쪽 배치: DP-1 은 x=1920", ui.plan_positions(st)["DP-1"] == (1920, 0))
st[1]["side"] = "left"
pl = ui.plan_positions(st)
check("왼쪽 배치: 음수 없이 옮김 (HDMI-1 이 x=1024)", pl == {"HDMI-1": (1024, 0), "DP-1": (0, 0)})
st[1]["side"] = "below"
check("아래 배치: y=1080", ui.plan_positions(st)["DP-1"] == (0, 1080) or ui.plan_positions(st)["DP-1"] == (0, 1080))
ext = ui.build_xrandr_args(st, "extend")
check("확장 명령: 각 모니터 mode/rate/pos 와 주 모니터 표시",
      ext[:2] == ["--output", "HDMI-1"] and "--primary" in ext and "--rate" in ext and "--pos" in ext)
cl = ui.build_xrandr_args(st, "clone")
check("복제 명령: 두 번째 모니터는 --same-as 주 모니터", "--same-as" in cl and cl[cl.index("--same-as") + 1] == "HDMI-1")

print("\n실패: %d" % len(fails))
sys.exit(1 if fails else 0)

/* 윈도우 7 스타일 화면: 하늘색 배경, 반투명 작업 표시줄, 녹색 시작 버튼,
 * 밝은 제목 표시줄의 창 (UEFI: 명령 프롬프트, 리눅스: 실제 bash 터미널),
 * 시작 메뉴 (Aero의 투명 효과 대신 알파 블렌딩과 그라데이션으로 표현)
 */
#include "ui.h"
#include "device.h"
#include "fs.h"
#include "pci.h"
#include "net.h"
#ifdef RICEOS_LINUX
#include "linux/term.h"
#define WIN_TITLE "RICEOS 터미널"
#else
#define WIN_TITLE "RICEOS 명령 프롬프트"
#endif

#define COLS      96
#define ROWS      200
#define LINE_MAX  60
#define TASKBAR_H 40
#ifdef RICEOS_LINUX
#define MENU_N    7
#else
#define MENU_N    5
#endif
#define MENU_ROW  40

static gfx_t *G;
static void (*wait_key_fn)(void);
static int menu_open, menu_sel, dirty = 1, exit_req;
static int fullscreen;
static int ptr_x, ptr_y;     /* 마우스 포인터 위치 */
static char clk_hm[16] = "--:--", clk_ymd[16] = "----";

static const char *menu_items[MENU_N] = {
    "터미널 열기", "장치 목록 보기", "파티션 목록 보기", "Chrome 실행",
#ifdef RICEOS_LINUX
    "배경화면 바꾸기", "효과음 켜기/끄기",
#endif
    "시스템 종료"
};

/* 배경화면(그라데이션 색 또는 그림)과 효과음 연결: main_linux가 설정한다 */
static UINT32 th_top = 0x2F7BC4, th_bot = 0xC9E8FA, th_gtop = 0x8DC26A, th_gbot = 0x4E8A3A;
static UINT32 *wp_img;
static UINT32 wp_w, wp_h;
static void (*sound_fn)(int kind);
static void snd(int kind) { if (sound_fn) sound_fn(kind); }

#ifndef RICEOS_LINUX
/* ---------- UEFI 전용: 간단한 명령 창 ---------- */
static UINT32 con[ROWS][COLS];
static UINT32 cur_r, cur_c;
static char input[LINE_MAX + 1];
static UINT32 input_len;

static void con_scroll(void)
{
    for (UINT32 r = 1; r < ROWS; r++)
        for (UINT32 c = 0; c < COLS; c++)
            con[r - 1][c] = con[r][c];
    for (UINT32 c = 0; c < COLS; c++) con[ROWS - 1][c] = 0;
}

static void con_newline(void)
{
    cur_c = 0;
    if (cur_r + 1 < ROWS) cur_r++;
    else con_scroll();
}

static void con_putcp(UINT32 cp)
{
    if (cp == '\n') { con_newline(); return; }
    if (cur_c >= COLS) con_newline();
    con[cur_r][cur_c++] = cp;
}

void ui_write(const char *s)
{
    while (*s) {
        UINT32 cp = utf8_next(&s);
        if (cp == 0) break;
        con_putcp(cp);
    }
    dirty = 1;
}

void ui_print(const char *s)
{
    if (cur_c > 0) con_newline();
    ui_write(s);
}

static int streq(const char *a, const char *b)
{
    while (*a && *a == *b) { a++; b++; }
    return *a == *b;
}

static void show_help(void)
{
    ui_print("명령:\n");
    ui_print("  devices  연결된 저장 장치 보기\n");
    ui_print("  volumes  파티션과 파일 시스템 보기\n");
    ui_print("  ls N     N번 파티션의 루트 디렉터리 보기\n");
    ui_print("  hw       PCI 장치 목록\n");
    ui_print("  net      유선 랜 상태와 MAC 주소\n");
    ui_print("  bsod     블루스크린 테스트\n");
    ui_print("  help     도움말 (ESC: 시작 메뉴)\n");
}

static void exec_line(void)
{
    input[input_len] = 0;
    con_newline();
    if (streq(input, "devices")) device_list(ui_print);
    else if (streq(input, "volumes")) fs_volumes(ui_print);
    else if (input[0] == 'l' && input[1] == 's' && input[2] == ' ') {
        UINT32 n = 0, i = 3;
        while (input[i] >= '0' && input[i] <= '9') n = n * 10 + (UINT32)(input[i++] - '0');
        if (n == 0) ui_print("사용법: ls 번호\n");
        else fs_ls(n, ui_print);
    }
    else if (streq(input, "help")) show_help();
    else if (streq(input, "hw")) pci_list(ui_print);
    else if (streq(input, "net")) net_info(ui_print);
    else if (streq(input, "bsod")) ui_bsod(0x00000001);
    else if (input_len > 0) ui_print("알 수 없는 명령입니다.\n");
    input_len = 0;
    dirty = 1;
}

static void run_text(const char *s)
{
    input_len = 0;
    while (*s && input_len < LINE_MAX) input[input_len++] = *s++;
    exec_line();
}

static void run_cmd(const char *s) { run_text(s); }
#else
/* ---------- 리눅스: 실제 셸 터미널 ---------- */
void ui_write(const char *s) { (void)s; dirty = 1; }
void ui_print(const char *s) { term_feed(s); dirty = 1; }

static void run_cmd(const char *s)
{
    term_type(s);
    term_type("\r");
}
#endif

/* ---------- 그리기 ---------- */
static void draw_wallpaper(void)
{
    if (wp_img && wp_w == G->w && wp_h == G->h) {     /* 그림 배경화면 */
        for (UINT32 y = 0; y < G->h; y++) {
            UINT32 *d = G->px + y * G->stride;
            const UINT32 *s = wp_img + y * wp_w;
            for (UINT32 x = 0; x < wp_w; x++) d[x] = s[x];
        }
        return;
    }
    gfx_vgrad(G, 0, 0, G->w, G->h, th_top, th_bot);
    /* 아래쪽 초원 느낌 */
    gfx_vgrad(G, 0, G->h * 3 / 4, G->w, G->h / 4, th_gtop, th_gbot);
}

/* 창 영역: 평소에는 가운데 창, 전체 화면이면 바탕 전체 (작업 표시줄 제외) */
static void win_rect(UINT32 *wx, UINT32 *wy, UINT32 *ww, UINT32 *wh)
{
    if (fullscreen) {
        *wx = 0; *wy = 0; *ww = G->w; *wh = G->h - TASKBAR_H;
        return;
    }
    *ww = G->w - 80;
    *wh = G->h - TASKBAR_H - 100;
#ifdef RICEOS_LINUX
    if (*ww > TERM_COLS * 8 + 24) *ww = TERM_COLS * 8 + 24;
    if (*wh > TERM_ROWS * 16 + 60) *wh = TERM_ROWS * 16 + 60;
#else
    if (*ww > 900) *ww = 900;
    if (*wh > 560) *wh = 560;
#endif
    *wx = (G->w - *ww) / 2;
    *wy = 40;
}

/* 제목 표시줄 단추: 닫기(X)와 전체 화면(□) */
static void btn_close(UINT32 wx, UINT32 wy, UINT32 ww, UINT32 *x, UINT32 *y)
{ *x = wx + ww - 42; *y = wy + 5; }
static void btn_full(UINT32 wx, UINT32 wy, UINT32 ww, UINT32 *x, UINT32 *y)
{ *x = wx + ww - 82; *y = wy + 5; }

static int in_rect(UINT32 px, UINT32 py, UINT32 x, UINT32 y, UINT32 w, UINT32 h)
{
    return px >= x && px < x + w && py >= y && py < y + h;
}

static void draw_window(void)
{
    UINT32 wx, wy, ww, wh, body_y, body_h, bx, by;
    rect_t clip;

    win_rect(&wx, &wy, &ww, &wh);

    /* 그림자 (전체 화면일 때는 생략) */
    if (!fullscreen) gfx_blend(G, wx + 4, wy + 6, ww, wh, 0x000000, 60);
    /* 바깥 테두리와 제목 표시줄 */
    gfx_round_rect(G, wx, wy, ww, wh, 8, 0xB8862B);
    gfx_vgrad(G, wx + 1, wy + 1, ww - 2, 30, 0xFFF6C4, 0xF2C230);
    gfx_text(G, WIN_TITLE, wx + 12, wy + 8, 1, 0x1B2B3B, 0);

    /* 전체 화면 단추 (□) */
    btn_full(wx, wy, ww, &bx, &by);
    gfx_round_rect(G, bx, by, 34, 22, 4, 0x3E7BC9);
    gfx_rect(G, bx + 9, by + 5, 16, 1, 0xFFFFFF);
    gfx_rect(G, bx + 9, by + 16, 16, 1, 0xFFFFFF);
    gfx_rect(G, bx + 9, by + 5, 1, 12, 0xFFFFFF);
    gfx_rect(G, bx + 24, by + 5, 1, 12, 0xFFFFFF);

    /* 닫기 단추 (X): 화면 표시만 */
    btn_close(wx, wy, ww, &bx, &by);
    gfx_round_rect(G, bx, by, 34, 22, 4, 0xC7463D);
    gfx_text(G, "X", bx + 9, by + 3, 1, 0xFFFFFF, 0);

    /* 본문 */
    body_y = wy + 32;
    body_h = wh - 36;
    gfx_rect(G, wx + 5, body_y, ww - 10, body_h, 0xFFFFFF);
    gfx_rect(G, wx + 5, body_y, ww - 10, 1, 0xD9B54A);

    clip.x0 = wx + 6; clip.y0 = body_y + 2;
    clip.x1 = wx + ww - 6; clip.y1 = body_y + body_h - 2;

#ifdef RICEOS_LINUX
    {
        UINT32 vis = (body_h - 8) / 16;
        int vr, vc;
        if (vis > TERM_ROWS) vis = TERM_ROWS;
        for (UINT32 r = 0; r < vis; r++) {
            const term_cell_t *row = term_row((int)r, (int)vis);
            UINT32 y = body_y + 6 + r * 16;
            for (UINT32 c = 0; c < TERM_COLS; c++) {
                UINT32 cx = wx + 12 + c * 8;
                if (!row[c].cp || row[c].wide == 2) continue;
                if (row[c].wide == 1)   /* 한글: 두 칸을 쓰는 16px 글자 */
                    gfx_char(G, row[c].cp, cx, y, 1, term_rgb(row[c].fg), &clip);
                else if (row[c].cp < 0x80)
                    gfx_char_half(G, row[c].cp, cx, y, term_rgb(row[c].fg), &clip);
            }
        }
        if (term_cursor((int)vis, &vr, &vc))
            gfx_rect(G, wx + 12 + (UINT32)vc * 8, body_y + 6 + (UINT32)vr * 16 + 14, 8, 2, 0x101820);
    }
#else
    {
        UINT32 visible = (body_h - 8) / 16;
        UINT32 start = cur_r + 1 > visible ? cur_r + 1 - visible : 0;
        for (UINT32 r = start; r <= cur_r; r++) {
            UINT32 y = body_y + 6 + (r - start) * 16;
            for (UINT32 c = 0; c < COLS; c++) {
                if (con[r][c]) gfx_char(G, con[r][c], wx + 12 + c * 16, y, 1, 0x101820, &clip);
            }
        }
        {
            UINT32 y = body_y + 6 + (cur_r - start) * 16;
            gfx_rect(G, wx + 12 + cur_c * 16, y + 14, 12, 2, 0x101820);
        }
    }
#endif
}

static void draw_taskbar(void)
{
    UINT32 y = G->h - TASKBAR_H;
    UINT32 tw, cx;

    gfx_blend(G, 0, y, G->w, TASKBAR_H, 0xF5C842, 225);
    gfx_rect(G, 0, y, G->w, 1, 0xFFE58A);

    /* 시작 버튼: 녹색 광택 원 */
    gfx_circle(G, 22, y + 20, 17, 0x1F5C2A);
    gfx_circle(G, 22, y + 20, 15, 0x3E9A4B);
    gfx_circle(G, 22, y + 20, 12, 0x6CC77F);
    gfx_circle(G, 22, y + 19, 7, 0xA5E8B6);

    /* 실행 중인 창 단추 */
    gfx_round_rect(G, 52, y + 5, 170, 30, 4, 0xE8B530);
    gfx_text(G, WIN_TITLE, 64, y + 12, 1, 0x2A1F00, 0);

    /* 시계 */
    tw = gfx_text_width(clk_hm, 1);
    if (gfx_text_width(clk_ymd, 1) > tw) tw = gfx_text_width(clk_ymd, 1);
    cx = G->w - tw - 14;
    gfx_text(G, clk_hm, cx, y + 3, 1, 0x2A1F00, 0);
    gfx_text(G, clk_ymd, cx, y + 20, 1, 0x4A3A00, 0);
}

static void draw_menu(void)
{
    UINT32 mw = 280, mh = MENU_N * MENU_ROW + 16;
    UINT32 mx = 6, my = G->h - TASKBAR_H - mh - 6;

    gfx_round_rect(G, mx - 1, my - 1, mw + 2, mh + 2, 7, 0x5C82AA);
    gfx_round_rect(G, mx, my, mw, mh, 6, 0xEEF5FC);
    for (UINT32 i = 0; i < MENU_N; i++) {
        UINT32 iy = my + 8 + i * MENU_ROW;
        if ((int)i == menu_sel) {
            gfx_round_rect(G, mx + 6, iy, mw - 12, MENU_ROW - 6, 4, 0x3B7DCA);
            gfx_text(G, menu_items[i], mx + 18, iy + 10, 1, 0xFFFFFF, 0);
        } else {
            gfx_text(G, menu_items[i], mx + 18, iy + 10, 1, 0x1B2B3B, 0);
        }
    }
}

static int menu_activate(void);

/* 커서 모양: 화살표(기본), I 모양(글 입력 영역), 손(누를 수 있는 곳) */
enum { CUR_ARROW, CUR_IBEAM, CUR_HAND };

static int cursor_kind(void)
{
    UINT32 wx, wy, ww, wh, bx, by;
    UINT32 px = (UINT32)ptr_x, py = (UINT32)ptr_y;
    UINT32 sy = G->h - TASKBAR_H;

    if (py >= sy && px < 60) return CUR_HAND;                 /* 시작 단추 */
    if (menu_open) {
        UINT32 mw = 280, mh = MENU_N * MENU_ROW + 16;
        UINT32 mx = 6, my = G->h - TASKBAR_H - mh - 6;
        if (in_rect(px, py, mx, my, mw, mh)) return CUR_HAND;
        return CUR_ARROW;
    }
    win_rect(&wx, &wy, &ww, &wh);
    btn_full(wx, wy, ww, &bx, &by);
    if (in_rect(px, py, bx, by, 34, 22)) return CUR_HAND;
    btn_close(wx, wy, ww, &bx, &by);
    if (in_rect(px, py, bx, by, 34, 22)) return CUR_HAND;
    /* 본문(글 영역) 위: I 모양 */
    if (in_rect(px, py, wx + 6, wy + 34, ww - 12, wh - 40)) return CUR_IBEAM;
    return CUR_ARROW;
}

static void draw_arrow(UINT32 x, UINT32 y)
{
    for (UINT32 r = 0; r < 14; r++) {
        UINT32 w = r < 8 ? r + 1 : 14 - r;
        if (x + w < G->w && y + r < G->h)
            gfx_rect(G, x, y + r, w, 1, 0x000000);
    }
}

/* I 모양: 위아래 가로 획 + 가운데 세로 획 (가운데 맞춤, 높이 18) */
static void draw_ibeam(UINT32 x, UINT32 y)
{
    if (x < 3 || y + 18 >= G->h || x + 4 >= G->w) return;
    gfx_rect(G, x - 3, y, 7, 1, 0x000000);
    gfx_rect(G, x - 3, y + 17, 7, 1, 0x000000);
    gfx_rect(G, x, y + 1, 1, 16, 0x000000);
}

/* 손 모양 (가리키는 손, 약 12x16): 검지, 나머지 손가락, 손바닥, 엄지 */
static void draw_hand(UINT32 x, UINT32 y)
{
    if (x + 12 >= G->w || y + 16 >= G->h) return;
    gfx_rect(G, x + 4, y, 3, 9, 0x000000);               /* 검지 */
    gfx_rect(G, x + 7, y + 5, 2, 4, 0x000000);           /* 중지 */
    gfx_rect(G, x + 9, y + 6, 2, 4, 0x000000);           /* 약지 */
    gfx_rect(G, x + 2, y + 8, 9, 7, 0x000000);           /* 손바닥 */
    gfx_rect(G, x, y + 9, 2, 4, 0x000000);               /* 엄지 */
    gfx_rect(G, x + 2, y + 15, 8, 1, 0x000000);
}

static void draw_pointer(void)
{
    UINT32 x = (UINT32)ptr_x, y = (UINT32)ptr_y;
    switch (cursor_kind()) {
    case CUR_IBEAM: draw_ibeam(x, y); break;
    case CUR_HAND:  draw_hand(x, y); break;
    default:        draw_arrow(x, y); break;
    }
}

void ui_render(void)
{
    draw_wallpaper();
    draw_window();
    draw_taskbar();
    if (menu_open) draw_menu();
    draw_pointer();
    dirty = 0;
}

/* ---------- 마우스 ---------- */
void ui_pointer_move(int dx, int dy)
{
    int x = ptr_x + dx, y = ptr_y + dy;
    if (x < 0) x = 0;
    if (y < 0) y = 0;
    if (x > (int)G->w - 1) x = (int)G->w - 1;
    if (y > (int)G->h - 1) y = (int)G->h - 1;
    ptr_x = x; ptr_y = y;
    dirty = 1;
}

/* 절대 좌표 장치(태블릿, 가상 머신의 포인터): 장치 범위를 화면 크기로 옮긴다 */
void ui_pointer_abs(int ax, int ay, int minx, int maxx, int miny, int maxy)
{
    long x = ax, y = ay;
    if (maxx > minx) x = (long)(ax - minx) * (long)G->w / (maxx - minx + 1);
    if (maxy > miny) y = (long)(ay - miny) * (long)G->h / (maxy - miny + 1);
    if (x < 0) x = 0;
    if (y < 0) y = 0;
    if (x > (long)G->w - 1) x = (long)G->w - 1;
    if (y > (long)G->h - 1) y = (long)G->h - 1;
    ptr_x = (int)x; ptr_y = (int)y;
    dirty = 1;
}

/* 포인터 위치에서 왼쪽 클릭 처리. 종료 요청이면 1 */
int ui_click(void)
{
    UINT32 wx, wy, ww, wh, bx, by;
    UINT32 px = (UINT32)ptr_x, py = (UINT32)ptr_y;
    UINT32 sy = G->h - TASKBAR_H;

    dirty = 1;
    /* 시작 단추: 작업 표시줄 왼쪽 */
    if (py >= sy && px < 60) {
        menu_open = !menu_open;
        snd(menu_open ? UI_SND_MENU : UI_SND_CLICK);
        return 0;
    }

    if (menu_open) {
        UINT32 mw = 280, mh = MENU_N * MENU_ROW + 16;
        UINT32 mx = 6, my = G->h - TASKBAR_H - mh - 6;
        if (in_rect(px, py, mx, my, mw, mh)) {
            for (UINT32 i = 0; i < MENU_N; i++) {
                UINT32 iy = my + 8 + i * MENU_ROW;
                if (in_rect(px, py, mx + 6, iy, mw - 12, MENU_ROW - 6)) {
                    menu_sel = (int)i;
                    menu_open = 0;
                    return menu_activate();
                }
            }
            return 0;
        }
        menu_open = 0;          /* 메뉴 바깥을 누르면 닫는다 */
        return 0;
    }

    win_rect(&wx, &wy, &ww, &wh);
    btn_full(wx, wy, ww, &bx, &by);
    if (in_rect(px, py, bx, by, 34, 22)) { fullscreen = !fullscreen; snd(UI_SND_CLICK); return 0; }
    /* 닫기(X) 단추는 바탕화면을 끄지 않는다: 종료는 시작 메뉴에서 */
    return 0;
}

/* ---------- 입력과 상태 ---------- */
void ui_init(gfx_t *g, void (*wait_key)(void))
{
    G = g;
    wait_key_fn = wait_key;
#ifdef RICEOS_LINUX
    term_init();
    term_feed("RICEOS 터미널 - 리눅스 bash 셸입니다. 명령 목록은 'riceos' 입력, 시작 메뉴는 ESC 또는 왼쪽 아래 버튼.\r\n");
    term_start();
#else
    ui_print("RICEOS 명령 프롬프트\n");
    show_help();
    ui_print("\n> ");
#endif
    dirty = 1;
}

void ui_set_clock(const char *hm, const char *ymd)
{
    UINT32 i;
    for (i = 0; i < 15 && hm[i]; i++) clk_hm[i] = hm[i];
    clk_hm[i] = 0;
    for (i = 0; i < 15 && ymd[i]; i++) clk_ymd[i] = ymd[i];
    clk_ymd[i] = 0;
    dirty = 1;
}

static int menu_activate(void)
{
    snd(UI_SND_CLICK);
    switch (menu_sel) {
    case 0: menu_open = 0; break;
    case 1: menu_open = 0; run_cmd("devices"); break;
    case 2: menu_open = 0; run_cmd("volumes"); break;
    case 3: menu_open = 0; run_cmd("riceos-chrome"); break;
#ifdef RICEOS_LINUX
    case 4: menu_open = 0; run_cmd("riceos wallpaper next"); break;
    case 5: menu_open = 0; run_cmd("riceos sfx toggle"); break;
    case 6: exit_req = 1; break;
#else
    case 4: exit_req = 1; break;
#endif
    }
    return exit_req;
}

int ui_handle_key(UINT16 scan, UINT16 uni)
{
#ifdef RICEOS_LINUX
    /* ESC: 시작 메뉴. 전체 화면 프로그램(vi 등)이 켜져 있으면 ESC는 그 프로그램으로 간다 */
    if (scan == 0x17 && !term_alt()) {
        menu_open = !menu_open;
        snd(menu_open ? UI_SND_MENU : UI_SND_CLICK);
        dirty = 1;
        return 0;
    }
    if (menu_open) {
        if (scan == 0x01)      menu_sel = (menu_sel + MENU_N - 1) % MENU_N;
        else if (scan == 0x02) menu_sel = (menu_sel + 1) % MENU_N;
        else if (uni == '\r')  return menu_activate();
        dirty = 1;
        return exit_req;
    }
    if (scan == 0x18) { fullscreen = !fullscreen; dirty = 1; return 0; }   /* F11 */
    /* PgUp/PgDn: 기록 보기 (전체 화면 프로그램이 아닐 때) */
    if ((scan == 0x15 || scan == 0x16) && !term_alt()) {
        term_scroll_view(scan == 0x15 ? 10 : -10);
        dirty = 1;
        return 0;
    }
    term_key(scan, uni);
    dirty = 1;
    return 0;
#else
    if (scan == 0x17) {                       /* ESC: 시작 메뉴 열기/닫기 */
        menu_open = !menu_open;
        snd(menu_open ? UI_SND_MENU : UI_SND_CLICK);
        dirty = 1;
        return 0;
    }
    if (menu_open) {
        if (scan == 0x01)      menu_sel = (menu_sel + MENU_N - 1) % MENU_N;   /* 위 */
        else if (scan == 0x02) menu_sel = (menu_sel + 1) % MENU_N;            /* 아래 */
        else if (uni == '\r')  return menu_activate();
        dirty = 1;
        return exit_req;
    }
    if (uni == '\r') {
        exec_line();
        ui_print("> ");
    } else if (uni == 0x08) {
        if (input_len > 0) {
            input_len--;
            if (cur_c > 0) { cur_c--; con[cur_r][cur_c] = 0; }
        }
    } else if (uni >= 0x20 && uni <= 0x7E && input_len < LINE_MAX) {
        input[input_len++] = (char)uni;
        con_putcp(uni);
    }
    dirty = 1;
    return 0;
#endif
}

void ui_bsod(UINT32 stop_code)
{
    static const char hex[] = "0123456789ABCDEF";
    char code[11] = "0x00000000";
    for (int i = 0; i < 8; i++) code[9 - i] = hex[(stop_code >> (i * 4)) & 0xF];

    gfx_rect(G, 0, 0, G->w, G->h, 0x0078D7);
    gfx_text(G, ":( RICEOS에 문제가 발생했습니다.", 80, 80, 2, 0xFFFFFF, 0);
    gfx_text(G, "컴퓨터를 다시 시작해 주세요.", 80, 150, 1, 0xFFFFFF, 0);
    gfx_text(G, "정지 코드:", 80, 200, 1, 0xFFFFFF, 0);
    gfx_text(G, code, 200, 200, 1, 0xFFFFFF, 0);
    gfx_text(G, "아무 키나 누르면 계속합니다.", 80, 260, 1, 0xFFFFFF, 0);
    if (wait_key_fn) wait_key_fn();
    dirty = 1;
}

void ui_set_theme(UINT32 top, UINT32 bot, UINT32 gtop, UINT32 gbot)
{
    th_top = top; th_bot = bot; th_gtop = gtop; th_gbot = gbot;
    dirty = 1;
}

UINT32 *ui_set_wallpaper(UINT32 *px, UINT32 w, UINT32 h)
{
    UINT32 *old = wp_img;
    wp_img = px; wp_w = w; wp_h = h;
    dirty = 1;
    return old;
}

void ui_set_sound(void (*fn)(int kind)) { sound_fn = fn; }

int ui_dirty(void) { return dirty; }
void ui_mark_dirty(void) { dirty = 1; }
void ui_clear_dirty(void) { dirty = 0; }

#!/bin/sh
# RICEOS 전체 빌드: UEFI 로더 + 리눅스 UI + 호스트 테스트 + 배포 폴더(dist/)
# 필요: clang, lld(lld-link), gcc, python3
set -e
cd "$(dirname "$0")"
[ -f RICEOS_FONT.BIN ] || { echo "RICEOS_FONT.BIN 이 없습니다"; exit 1; }
[ -f startup.pcm ] || { echo "startup.pcm 이 없습니다"; exit 1; }

echo "== 1/4 UEFI 로더 =="
./build_clang.sh
rm -f *.o

echo "== 2/4 리눅스 UI =="
./linux/build.sh

echo "== 3/4 테스트 =="
python3 tests/gen_images.py
gcc -Wall -o /tmp/riceos_test_drivers tests/test_drivers.c fs_exfat.c fs_ntfs.c fs.c
/tmp/riceos_test_drivers tests/exfat.img tests/ntfs.img | tail -1
rm -f tests/exfat.img tests/ntfs.img

echo "== 4/4 배포 폴더 =="
rm -rf dist
mkdir -p dist/USB/EFI/BOOT dist/linux
cp BOOTX64.EFI dist/USB/EFI/BOOT/BOOTX64.EFI
cp linux/riceos-ui linux/make_image.sh linux/README.md dist/linux/
cp RICEOS_FONT.BIN SUIT-LICENSE.txt dist/
echo "빌드 완료: dist/"

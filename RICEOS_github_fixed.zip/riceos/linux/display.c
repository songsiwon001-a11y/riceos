/* RICEOS 모니터 출력 (DRM/KMS)
 * 흐름: /dev/dri/cardN 열기 → 커넥터(HDMI/DP/VGA...) 찾기 → 출력마다 CRTC와 선호 모드 배정
 *       → 출력마다 덤 버퍼 만들기 → 출력마다 SETCRTC (각자 자기 주사율로 켜짐)
 * 화면 그리기: display_present가 기준 화면을 각 모니터 버퍼에 복사한다 (크기가 다르면 확대/축소).
 */
#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <errno.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <sys/mman.h>
#include <drm/drm.h>
#include <drm/drm_mode.h>
#include "display.h"

#define MAXOUT  8
#define MAXCARD 8
#define CONN_CONNECTED 1   /* 커널 connector_status: 1 = connected (UAPI에는 이름이 없음) */

static int dfd = -1;                  /* DRM 장치 파일 */
static display_out_t outs[MAXOUT];
static int nout;
static uint64_t last_sig, cur_sig;    /* 연결 상태 지문: 바뀌면 다시 설정 */

struct res {
    uint32_t *crtcs, *conns, *encs;
    uint32_t ncrtc, nconn, nenc;
};

static int xioctl(int fd, unsigned long req, void *arg)
{
    int r;
    do r = ioctl(fd, req, arg); while (r < 0 && errno == EINTR);
    return r;
}

static const char *type_label(uint32_t t)
{
    switch (t) {
    case DRM_MODE_CONNECTOR_VGA:        return "VGA";
    case DRM_MODE_CONNECTOR_DVII:
    case DRM_MODE_CONNECTOR_DVID:
    case DRM_MODE_CONNECTOR_DVIA:       return "DVI";
    case DRM_MODE_CONNECTOR_HDMIA:
    case DRM_MODE_CONNECTOR_HDMIB:      return "HDMI";
    case DRM_MODE_CONNECTOR_DisplayPort:return "DP";
    case DRM_MODE_CONNECTOR_eDP:        return "eDP";
    case DRM_MODE_CONNECTOR_LVDS:       return "LVDS";
    default:                            return "OUT";
    }
}

/* 출력 하나를 끈다: 주사 끄기 → 프레임버퍼 해제 → 매핑 해제 → 덤 버퍼 삭제 */
static void drop_out(display_out_t *o)
{
    if (dfd >= 0 && o->crtc_id) {
        struct drm_mode_crtc cr = {0};
        cr.crtc_id = o->crtc_id;          /* fb 0, 연결 없음 = 끄기 */
        xioctl(dfd, DRM_IOCTL_MODE_SETCRTC, &cr);
    }
    if (dfd >= 0 && o->fb_id) {
        uint32_t id = o->fb_id;
        xioctl(dfd, DRM_IOCTL_MODE_RMFB, &id);
    }
    if (o->map) munmap(o->map, o->size);
    if (dfd >= 0 && o->handle) {
        struct drm_mode_destroy_dumb dd = {0};
        dd.handle = o->handle;
        xioctl(dfd, DRM_IOCTL_MODE_DESTROY_DUMB, &dd);
    }
    memset(o, 0, sizeof *o);
}

static void free_outputs(void)
{
    for (int i = 0; i < nout; i++) drop_out(&outs[i]);
    nout = 0;
}

static int get_res(struct res *r)
{
    struct drm_mode_card_res cr = {0};
    if (xioctl(dfd, DRM_IOCTL_MODE_GETRESOURCES, &cr) < 0) return -1;
    r->ncrtc = cr.count_crtcs;
    r->nconn = cr.count_connectors;
    r->nenc  = cr.count_encoders;
    r->crtcs = calloc(r->ncrtc + 1, sizeof(uint32_t));
    r->conns = calloc(r->nconn + 1, sizeof(uint32_t));
    r->encs  = calloc(r->nenc + 1, sizeof(uint32_t));
    if (!r->crtcs || !r->conns || !r->encs) return -1;

    cr = (struct drm_mode_card_res){0};
    cr.crtc_id_ptr      = (uintptr_t)r->crtcs;
    cr.connector_id_ptr = (uintptr_t)r->conns;
    cr.encoder_id_ptr   = (uintptr_t)r->encs;
    cr.count_crtcs      = r->ncrtc;
    cr.count_connectors = r->nconn;
    cr.count_encoders   = r->nenc;
    return xioctl(dfd, DRM_IOCTL_MODE_GETRESOURCES, &cr);
}

static void res_free(struct res *r)
{
    free(r->crtcs); free(r->conns); free(r->encs);
}

/* 이 커넥터에 연결할 수 있는 빈 CRTC를 찾는다 (현재 인코더 먼저, 그다음 목록) */
static uint32_t find_crtc(uint32_t enc_cur, const uint32_t *encs, uint32_t nenc,
                          const struct res *r, const char *used, uint32_t *idx)
{
    for (uint32_t k = 0; k <= nenc; k++) {
        uint32_t eid = k == 0 ? enc_cur : encs[k - 1];
        if (!eid) continue;
        struct drm_mode_get_encoder e = {0};
        e.encoder_id = eid;
        if (xioctl(dfd, DRM_IOCTL_MODE_GETENCODER, &e) < 0) continue;
        for (uint32_t j = 0; j < r->ncrtc; j++)
            if (!used[j] && (e.possible_crtcs & (1u << j))) {
                *idx = j;
                return r->crtcs[j];
            }
    }
    return 0;
}

/* 연결된 모니터 하나를 설정한다. c에는 1차 조회 결과(개수)가 들어 있다. */
static void add_output(struct drm_mode_get_connector *c, const struct res *r, char *used)
{
    display_out_t *o = &outs[nout];
    struct drm_mode_modeinfo *modes = calloc(c->count_modes ? c->count_modes : 1, sizeof *modes);
    uint32_t *encs = calloc(c->count_encoders + 1, sizeof *encs);
    uint32_t idx = 0, crtc = 0;
    int ok = 0, mi = 0;

    if (!modes || !encs) goto done;
    c->modes_ptr    = (uintptr_t)modes;
    c->encoders_ptr = (uintptr_t)encs;
    c->count_props = 0; c->props_ptr = 0; c->prop_values_ptr = 0;
    if (xioctl(dfd, DRM_IOCTL_MODE_GETCONNECTOR, c) < 0 || c->count_modes == 0) goto done;

    /* 모니터가 알려 준 기본(선호) 모드를 쓴다. 없으면 첫 번째 모드 */
    for (uint32_t m = 0; m < c->count_modes; m++)
        if (modes[m].type & DRM_MODE_TYPE_PREFERRED) { mi = (int)m; break; }

    crtc = find_crtc(c->encoder_id, encs, c->count_encoders, r, used, &idx);
    if (!crtc) goto done;

    struct drm_mode_modeinfo *m = &modes[mi];
    o->connector_id = c->connector_id;
    o->crtc_id = crtc;
    o->mode = *m;
    o->width = m->hdisplay;
    o->height = m->vdisplay;
    o->refresh = m->vrefresh;
    snprintf(o->name, sizeof o->name, "%s-%u", type_label(c->connector_type), c->connector_type_id);

    struct drm_mode_create_dumb cd = {0};
    cd.width = o->width; cd.height = o->height; cd.bpp = 32;
    if (xioctl(dfd, DRM_IOCTL_MODE_CREATE_DUMB, &cd) < 0) goto fail;
    o->handle = cd.handle; o->pitch = cd.pitch; o->size = cd.size;

    struct drm_mode_map_dumb md = {0};
    md.handle = cd.handle;
    if (xioctl(dfd, DRM_IOCTL_MODE_MAP_DUMB, &md) < 0) goto fail;
    o->map = mmap(0, cd.size, PROT_READ | PROT_WRITE, MAP_SHARED, dfd, md.offset);
    if (o->map == MAP_FAILED) { o->map = 0; goto fail; }

    struct drm_mode_fb_cmd fc = {0};
    fc.width = o->width; fc.height = o->height; fc.pitch = o->pitch;
    fc.bpp = 32; fc.depth = 24; fc.handle = cd.handle;
    if (xioctl(dfd, DRM_IOCTL_MODE_ADDFB, &fc) < 0) goto fail;
    o->fb_id = fc.fb_id;

    /* 이 출력만의 모드 설정: 이 CRTC가 이 모니터의 주사율로 돈다 */
    uint32_t cid = c->connector_id;
    struct drm_mode_crtc cr = {0};
    cr.set_connectors_ptr = (uintptr_t)&cid;
    cr.count_connectors = 1;
    cr.crtc_id = crtc;
    cr.fb_id = o->fb_id;
    cr.mode_valid = 1;
    cr.mode = *m;
    if (xioctl(dfd, DRM_IOCTL_MODE_SETCRTC, &cr) < 0) goto fail;

    used[idx] = 1;
    ok = 1;
    goto done;

fail:
done:
    free(modes);
    free(encs);
    if (ok) nout++;
    else drop_out(o);
}

/* 연결 상태를 훑는다. setup이 0이면 지문(cur_sig)만 계산하고, 1이면 출력을 만든다. */
static int scan(int setup)
{
    struct res r = {0};
    uint64_t sig = 1469598103934665603ull;
    char *used;

    if (get_res(&r) < 0) { res_free(&r); cur_sig = 0; return -1; }
    used = calloc(r.ncrtc + 1, 1);
    if (!used) { res_free(&r); return -1; }

    for (uint32_t i = 0; i < r.nconn; i++) {
        struct drm_mode_get_connector c = {0};
        c.connector_id = r.conns[i];
        if (xioctl(dfd, DRM_IOCTL_MODE_GETCONNECTOR, &c) < 0) continue;
        int on = c.connection == CONN_CONNECTED;
        sig = sig * 1000003ull + c.connector_id * 2u + (on ? 1u : 0u);
        if (!setup || !on || nout >= MAXOUT) continue;
        add_output(&c, &r, used);
    }
    cur_sig = sig;
    free(used);
    res_free(&r);
    return nout;
}

int display_init(void)
{
    for (int i = 0; i < MAXCARD && nout == 0; i++) {
        char path[32];
        snprintf(path, sizeof path, "/dev/dri/card%d", i);
        int fd = open(path, O_RDWR | O_CLOEXEC);
        if (fd < 0) continue;
        dfd = fd;
        if (xioctl(dfd, DRM_IOCTL_SET_MASTER, 0) < 0) {   /* 다른 프로그램이 화면을 잡고 있으면 건너뜀 */
            close(dfd); dfd = -1;
            continue;
        }
        scan(1);
        if (nout == 0) {
            xioctl(dfd, DRM_IOCTL_DROP_MASTER, 0);
            close(dfd); dfd = -1;
            continue;
        }
        last_sig = cur_sig;
    }
    return nout > 0 ? 0 : -1;
}

void display_close(void)
{
    if (dfd < 0) return;
    free_outputs();
    xioctl(dfd, DRM_IOCTL_DROP_MASTER, 0);
    close(dfd);
    dfd = -1;
}

int display_poll(void)
{
    if (dfd < 0) return 0;
    scan(0);
    if (cur_sig == last_sig) return 0;
    free_outputs();
    scan(1);
    last_sig = cur_sig;
    return 1;
}

void display_size(uint32_t *w, uint32_t *h)
{
    uint64_t best = 0;
    *w = 1024; *h = 768;
    for (int i = 0; i < nout; i++) {
        uint64_t area = (uint64_t)outs[i].width * outs[i].height;
        if (area > best) { best = area; *w = outs[i].width; *h = outs[i].height; }
    }
}

void display_present(const uint32_t *src, uint32_t sw, uint32_t sh)
{
    for (int i = 0; i < nout; i++) {
        display_out_t *o = &outs[i];
        uint32_t stride = o->pitch / 4;
        if (o->width == sw && o->height == sh) {
            for (uint32_t y = 0; y < o->height; y++)
                memcpy(o->map + (size_t)y * stride, src + (size_t)y * sw, (size_t)sw * 4);
            continue;
        }
        /* 크기가 다른 모니터: 최근접 이웃으로 전체 화면을 맞춘다 */
        for (uint32_t y = 0; y < o->height; y++) {
            uint32_t sy = (uint32_t)((uint64_t)y * sh / o->height);
            const uint32_t *s = src + (size_t)sy * sw;
            uint32_t *d = o->map + (size_t)y * stride;
            for (uint32_t x = 0; x < o->width; x++)
                d[x] = s[(uint64_t)x * sw / o->width];
        }
    }
}

int display_count(void) { return nout; }

void display_list(display_out_fn out)
{
    char line[160];
    if (nout == 0) { out("연결된 모니터가 없습니다 (DRM)\n"); return; }
    for (int i = 0; i < nout; i++) {
        display_out_t *o = &outs[i];
        snprintf(line, sizeof line, "  %s  %ux%u @ %uHz%s\n",
                 o->name, o->width, o->height, o->refresh, i == 0 ? "  (기준)" : "");
        out(line);
    }
}

# RICEOS (리눅스 기반)

Debian 12 위에서 전체 화면 RICEOS 바탕화면(`riceos-ui`)이 뜨는 USB 이미지를 만듭니다.
UEFI 응용 프로그램(`BOOTX64.EFI`)은 부트 화면 실험용이고, 실제 OS는 이쪽입니다.

## 구성
- `main_linux.c` : /dev/fb0 화면 출력, 키보드(evdev) 입력, 명령 모드(터미널에서 wifi/driver 등 실행)
- `term.c` : 가상 터미널(pty)에 실제 bash를 연결하고 VT100/xterm 제어 코드를 해석 (색, 커서, 전체 화면 프로그램)
- `backend.c` : 장치·파티션·PCI·랜 정보를 /sys, /proc에서 읽음, 명령 해석(run/file/mount/쉘)
- `job.c` : 외부 프로그램을 비동기로 실행 (입출력 연결, Ctrl+C, 종료 상태)
- `elfinfo.c` : ELF 형식 확인 (비트 수, CPU, 링크 방식)
- `../gfx.c`, `../ui.c` : UEFI 버전과 같은 그리기·UI 코드 재사용
- `make_image.sh` : debootstrap으로 Debian + GRUB + RICEOS UI 이미지 생성

## 만드는 방법 (Windows: WSL2의 Ubuntu / 리눅스 공통)
```
sudo apt install debootstrap parted dosfstools e2fsprogs util-linux gcc
cd riceos/linux
./build.sh                # riceos-ui 빌드
sudo ./make_image.sh 6G   # riceos.img 생성 (인터넷 필요, 수 분 소요)
```

## 리눅스 실행 파일 실행 (새 기능)
- `run 경로 [인자]` : ELF 실행 파일을 실행합니다. 실행 전에 형식(32/64비트, CPU 종류, 동적/정적 링크)을 확인하고, 이 컴퓨터의 CPU와 맞지 않거나 실행 권한이 없으면 이유를 알려줍니다.
- `file 경로` : ELF 파일 정보만 봅니다.
- `mount 번호` : 파티션을 읽기/쓰기로 `/mnt/riceosN`에 붙입니다 (실행 허용). USB 메모리에 있는 프로그램을 쓸 때 사용합니다.
- 실행 중에는 명령 창이 멈추지 않습니다. 출력은 실시간으로 나오고, 입력 줄은 프로그램 표준 입력으로 전달됩니다.
- Ctrl+C: 실행 중인 프로그램 중단 (두 번 누르면 강제 종료). ESC는 시작 메뉴입니다.
- 권한: `chmod +x 경로` 로 실행 권한을 준 뒤 실행합니다. FAT/exFAT는 권한 개념이 없어 기본적으로 실행 가능합니다.
- 그 밖의 명령은 `/bin/sh -c`로 실행되므로 파이프(`|`)와 `;`도 사용할 수 있습니다. `cd`는 명령마다 초기화됩니다.

### 한계
- 같은 CPU 구조(x86_64)의 프로그램만 실행됩니다. ARM 등 다른 구조의 바이너리는 `file`로 확인만 됩니다.
- 프로그램은 파이프로 연결되어 있어 터미널(TTY)이 아닙니다. 색 출력이나 전체 화면 프로그램(vi, top 등)은 제대로 동작하지 않습니다.
- X11/Wayland 그래픽 프로그램은 실행되지 않습니다 (RICEOS가 /dev/fb0을 직접 씁니다).
- 동적 링크 프로그램은 필요한 라이브러리가 이미지에 있어야 합니다 (`ldd 경로`로 확인).

## 다른 운영체제 파일
Windows(.exe), macOS, Android(.apk) 등 다른 OS의 실행 파일은 실행하지 않고 "이것은 Windows 전용 파일입니다." 처럼 알려줍니다. MS-DOS(16비트 MZ) 파일도 같은 방식으로 표시합니다.

## Debian 설치 이미지 받기
`./fetch_debian.sh [폴더]` 는 Debian 12 netinst ISO를 받아 SHA512로 검증합니다 (약 700MB).

## 무선 인터넷 (Wi-Fi)
- `wifi list` : 주변 무선 네트워크를 검색합니다 (신호 세기 dBm, 이름).
- `wifi connect 장치 이름 [암호]` : 무선 네트워크에 연결합니다. 장치 이름은 `net` 명령으로 확인합니다 (예: wlan0).
- `wifi status` : 연결 상태와 IP 주소를 봅니다.
- 주소는 DHCP로 자동 받습니다. 연결 설정은 `/etc/wpa_supplicant/`에 저장되며 권한은 600입니다.
- 지원 범위: WPA2/WPA3 개인용(암호), 암호 없는 네트워크. 기업용(802.1X)은 지원하지 않습니다.
- 한계: 이름과 암호에 공백을 쓸 수 없습니다. 입력한 암호는 명령 창에 그대로 보입니다. 무선랜 칩이 펌웨어를 지원해야 하며(Intel, Atheros, Broadcom, Realtek 대부분 포함), 임시 USB 부팅(UEFI 모드)에서는 무선을 쓸 수 없습니다.

## 드라이버와 펌웨어 (Debian apt)
- `driver status` : 장치별 드라이버 연결 상태를 보여줍니다. 드라이버가 없는 장치는 표시됩니다.
- `driver install` : 인터넷에서 펌웨어와 드라이버를 받아 설치합니다. 포함: 무선랜·CPU·AMD 그래픽·사운드(SOF) 펌웨어, Mesa(OpenGL/Vulkan, VA-API 도구), ALSA, BlueZ(블루투스).
- `driver nvidia` : NVIDIA 독점 드라이버(non-free)를 설치합니다. 커널 헤더가 필요하고 모듈 빌드에 시간이 걸립니다.
- 설치 후에는 재부팅해야 드라이버가 적용됩니다.
- 설치 원본은 Debian 12 저장소(`deb.debian.org`)입니다. 이미지의 `/etc/apt/sources.list`에 contrib, non-free, non-free-firmware 구성요소가 들어 있습니다.
- 한계: 인터넷 연결이 필요합니다. NVIDIA 드라이버는 Nouveau(오픈소스)와 충돌할 수 있습니다. 이 기능은 실제 기기에서 테스트하지 않았습니다.

## USB 무선랜 드라이버 (Realtek, DKMS)
많은 TP-Link USB 동글(Archer T2U Plus, T3U, T4U V3 등)은 Realtek 칩을 씁니다. 커널에 기본 드라이버가 없으면 `driver usb-wifi 칩이름`으로 GitHub 원본을 받아 DKMS로 빌드합니다.
- `driver usb-wifi` : 지원 칩 목록
- `driver usb-wifi 88x2bu` : RTL8812BU/8822BU (T3U, T4U V3 등)
- `driver usb-wifi 8812au` / `8821au` / `8821cu` : 해당 칩
- 칩은 `driver status`의 USB 항목(VID:PID)으로 확인하고, 제품 설명서나 검색으로 칩 이름을 맞춥니다.
- 설치 후 재부팅하고 동글을 다시 꽂습니다. 설치 스크립트가 질문하면 명령 창에 답을 입력합니다.
- 주의: 커널 업데이트 때마다 DKMS가 다시 빌드합니다 (linux-headers 필요). 원본 저장소는 morrownr의 GitHub 프로젝트입니다.

## Google Chrome (실행 방법)
- 이미지에는 Chrome과 X 디스플레이 서버(Xorg, fbdev), 창 관리자(Openbox), 한글 폰트(Noto CJK)가 들어갑니다.
- 바탕화면 메뉴의 **Chrome 실행** 또는 터미널에서 `riceos-chrome`을 입력하면:
  1. RICEOS 바탕화면이 잠시 멈추고 X 화면이 뜹니다.
  2. Chrome이 `riceos` 사용자(비밀번호 `riceos`)로 전체 화면에서 열립니다. 샌드박스를 유지하려고 root가 아닌 계정으로 실행합니다.
  3. Chrome을 닫으면 X가 내려가고 RICEOS 바탕화면이 다시 뜹니다.
- 로그: `/var/log/riceos-x.log`
- 설치용 .deb: `linux/chrome/google-chrome-stable_current_amd64.deb` (올바른 .deb일 때만 설치됩니다)
- 한계: 세션 전환 방식이라 Chrome 실행 중에는 RICEOS 바탕화면과 터미널을 쓸 수 없습니다. 그래픽 드라이버는 fbdev 방식이므로 일부 GPU에서는 화면이 제대로 나오지 않을 수 있습니다.

## 마우스, 전체 화면, 사운드
- **마우스**: 상대 이동(USB 마우스)과 절대 좌표(태블릿, 가상 머신 포인터)를 모두 지원합니다. 왼쪽 클릭으로 시작 단추, 메뉴 항목, 전체 화면 단추(□)를 누를 수 있습니다.
- **전체 화면**: 창 제목 표시줄의 □ 단추 또는 F11 키로 전환합니다. 전체 화면에서도 터미널 글자 칸 수는 96칸으로 고정입니다.
- **닫기(X)** 단추는 바탕화면을 끄지 않습니다. 끄려면 시작 메뉴의 "시스템 종료"를 쓰세요.
- **사운드**: ALSA를 씁니다 (여러 프로그램이 dmix로 함께 소리를 냅니다). 부팅 때 자동으로 음소거를 풀고 볼륨을 70%로 맞춥니다.
  - `riceos sound` : 현재 볼륨 보기
  - `riceos sound up` / `down` / `mute` / `unmute` : 볼륨 조절
  - `riceos sound test` : 440Hz 테스트 음 재생 (5초 이내)
- Chrome도 같은 ALSA 장치로 소리를 냅니다 (`riceos` 사용자가 audio 그룹에 속합니다).
- 한계: 사운드 카드 드라이버가 없으면 `driver install`로 펌웨어를 설치해야 할 수 있습니다. HDMI 출력이나 블루투스 스피커는 설정이 따로 필요할 수 있습니다. PulseAudio나 PipeWire는 쓰지 않습니다.

## 마우스 커서 모양
- 화살표: 기본
- I 모양: 터미널 글 영역 위 (글 입력 위치를 알려 줌)
- 손 모양: 누를 수 있는 곳 (시작 단추, 메뉴 항목, □ 단추)

## USB에 쓰기
1. `riceos.img`를 Windows로 가져옵니다 (WSL: `\\wsl$\Ubuntu\...`).
2. Rufus에서 USB를 고르고 부팅 선택에 `riceos.img`를 지정해 시작합니다 (DD 이미지 모드).
   **USB 전체가 지워집니다.**
3. PC를 재부팅하고 부팅 메뉴에서 `UEFI: USB 이름`을 고릅니다.

## 사용
- 부팅하면 RICEOS 바탕화면이 뜨고 창 안에 **실제 리눅스 bash 터미널**이 열립니다. `uname -a`, `ip a`, `vim` 등 리눅스 명령을 그대로 씁니다.
- RICEOS 명령은 터미널에서 바로 입력합니다: `devices`, `volumes`, `hw`, `net`, `wifi ...`, `driver ...`, `run 경로`, `riceos ls 번호`, `riceos mount 번호`, `riceos file 경로`.
- 터미널 키: 방향키, Home/End, Delete, Tab, Ctrl+C(중단), Ctrl+D 등 일반 리눅스 키 그대로. PgUp/PgDn으로 지난 출력을 봅니다.
- ESC: 시작 메뉴 (vim 같은 전체 화면 프로그램이 켜져 있으면 ESC는 그 프로그램으로 갑니다).
- ESC: 시작 메뉴 (시스템 종료)
- 비상용: Ctrl+Alt+F2 → `root` / `riceos` (꼭 바꾸세요: `passwd`)

## 배경화면과 효과음
- **배경화면** (시작 메뉴 "배경화면 바꾸기" 또는 터미널 명령)
  - `riceos wallpaper status` : 현재 배경화면
  - `riceos wallpaper next` : 기본 테마(기본, 밤, 민트)와 `/usr/share/riceos/wallpapers`의 그림을 순서대로 바꿉니다
  - `riceos wallpaper set 경로` : PNG 또는 BMP 그림을 지정합니다 (공백 없는 경로, 화면 크기에 맞춰 가운데 기준으로 채움)
  - `riceos wallpaper default` : 처음 배경으로 되돌립니다
- **효과음** (시작 메뉴 "효과음 켜기/끄기" 또는 터미널 명령)
  - `riceos sfx status|on|off|toggle` : 효과음 상태 확인과 켜기/끄기
  - `riceos sfx test` : 클릭음을 한 번 재생합니다
  - 소리: 시작음(부팅 때 한 번), 클릭, 메뉴 열기, 종료음. 음원 파일 없이 코드로 만들며 `aplay`(alsa-utils)로 재생합니다. 볼륨은 `riceos sound`로 조절합니다.
- **설정 파일**: `/etc/riceos/ui.conf` (`wallpaper=`, `sfx=`). 파일을 고치면 화면이 1초 안에 반영됩니다.
- **빌드 요구**: gcc, make, 그리고 최초 빌드 때 인터넷(curl 또는 wget, tar, xz).
  - 라이브러리 선택 순서: (1) `third_party/` 소스가 있으면 그것을 컴파일 → (2) `RICEOS_SYSTEM_LIBS=1` 이면 시스템 라이브러리 → (3) 그 밖에는 최초 1회 인터넷에서 받아 빌드 (`deps/fetch_build.sh`)
  - 주소와 SHA256 고정 값: `deps/versions.conf` (비어 있으면 받은 파일의 해시를 출력하고 계속)
  - 다시 받기: `sh deps/fetch_build.sh --force`
- **한계**: JPEG는 지원하지 않습니다 (PNG, BMP만). 그림 경로에 공백이 있으면 `set`을 쓸 수 없습니다. 효과음은 여러 소리가 겹칠 수 있고, 장치가 없으면 조용히 넘어갑니다.

## 알려진 한계
- 이미지 생성 스크립트는 작성 환경에서 실행해 보지 못했습니다. 첫 실행에서 오류가 나면 메시지를 알려주세요.
- 키보드는 영문 자판 입력만 지원합니다 (한글 입력 없음). 한글 출력은 표시됩니다.
- 화면 출력은 /dev/fb0(32비트)를 쓰므로 그래픽 드라이버가 fbdev를 제공해야 합니다 (Debian 기본 커널은 대부분 제공).

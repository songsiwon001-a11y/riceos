/* RICEOS 리눅스 셸: 전체 화면 바탕화면 (/dev/fb0) + 키보드(evdev)
 * 사용: riceos-ui            (실제 화면)
 *       riceos-ui --preview out.ppm   (메모리에 한 장 그려 저장, 테스트용)
 */
#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <dirent.h>
#include <poll.h>
#include <time.h>
#include <signal.h>
#include <sys/ioctl.h>
#include <sys/mman.h>
#include <sys/reboot.h>
#include <linux/fb.h>
#include <linux/input.h>
#include <linux/kd.h>
#include "../gfx.h"
#include "../ui.h"
#include "../device.h"
#include "display.h"
#include "media.h"
#include "job.h"
#include "term.h"

#define MAXKBD 16
static int kfd[MAXKBD];
static char kpath[MAXKBD][64];
static int nk;
static int shift, caps, ctrl;
static char map_n[128], map_s[128];

/* ---------- 키 매핑 (미국식 QWERTY) ---------- */
static void put(const char *n, const char *s, int from)
{
    for (int i = 0; n[i]; i++) { map_n[from + i] = n[i]; map_s[from + i] = s[i]; }
}
static void init_map(void)
{
    put("1234567890-=", "!@#$%^&*()_+", 2);
    put("qwertyuiop[]", "QWERTYUIOP{}", 16);
    put("asdfghjkl;'`", "ASDFGHJKL:\"~", 30);
    put("\\", "|", 43);
    put("zxcvbnm,./", "ZXCVBNM<>?", 44);
    put(" ", " ", 57);
}

/* evdev 키 코드 -> ui.c가 쓰는 (scan, uni). 처리했으면 1
 * scan: 특수 키 (0x01 위, 0x02 아래, 0x10 왼쪽, 0x11 오른쪽, 0x12 Home, 0x13 End,
 *        0x14 Delete, 0x15 PgUp, 0x16 PgDn, 0x17 ESC)
 * uni : 글자, Enter는 '\r', Backspace는 0x08, Tab은 0x09, Ctrl+문자는 1~26 */
int translate_key(int code, int down, UINT16 *scan, UINT16 *uni)
{
    if (code == KEY_LEFTSHIFT || code == KEY_RIGHTSHIFT) { shift = down; return 0; }
    if (code == KEY_CAPSLOCK) { if (down) caps = !caps; return 0; }
    if (code == KEY_LEFTCTRL || code == KEY_RIGHTCTRL) { ctrl = down; return 0; }
    if (!down) return 0;
    *scan = 0; *uni = 0;
    switch (code) {
    case KEY_ESC:      *scan = 0x17; break;
    case KEY_UP:       *scan = 0x01; break;
    case KEY_DOWN:     *scan = 0x02; break;
    case KEY_LEFT:     *scan = 0x10; break;
    case KEY_RIGHT:    *scan = 0x11; break;
    case KEY_HOME:     *scan = 0x12; break;
    case KEY_END:      *scan = 0x13; break;
    case KEY_DELETE:   *scan = 0x14; break;
    case KEY_PAGEUP:   *scan = 0x15; break;
    case KEY_PAGEDOWN: *scan = 0x16; break;
    case KEY_ENTER:
    case KEY_KPENTER:  *uni = '\r'; break;
    case KEY_F11:      *scan = 0x18; break;   /* 전체 화면 */
    case KEY_BACKSPACE: *uni = 0x08; break;
    case KEY_TAB:      *uni = 0x09; break;
    default:
        if (code <= 0 || code >= 128 || !map_n[code]) return 0;
        if (ctrl) {
            char c = map_n[code];
            if (c < 'a' || c > 'z') return 0;
            *uni = (UINT16)(c - 'a' + 1);          /* Ctrl+C = 0x03 */
            break;
        } else {
            char c = map_n[code];
            int letter = (c >= 'a' && c <= 'z');
            int up = letter ? (shift ^ caps) : shift;
            *uni = (UINT16)(up ? map_s[code] : c);
        }
        break;
    }
    return 1;
}

/* ---------- 입력 장치 ---------- */
static int is_keyboard(int fd)
{
    unsigned char bits[KEY_MAX / 8 + 1];
    memset(bits, 0, sizeof bits);
    if (ioctl(fd, EVIOCGBIT(EV_KEY, sizeof bits), bits) < 0) return 0;
    return (bits[KEY_A / 8] >> (KEY_A % 8) & 1) && (bits[KEY_ENTER / 8] >> (KEY_ENTER % 8) & 1);
}

static void scan_keyboards(void)
{
    DIR *d = opendir("/dev/input");
    struct dirent *e;
    if (!d) return;
    while ((e = readdir(d)) && nk < MAXKBD) {
        char p[64];
        int have = 0, fd;
        if (strncmp(e->d_name, "event", 5)) continue;
        snprintf(p, sizeof p, "/dev/input/%s", e->d_name);
        for (int i = 0; i < nk; i++) if (!strcmp(kpath[i], p)) have = 1;
        if (have) continue;
        fd = open(p, O_RDONLY | O_NONBLOCK | O_CLOEXEC);
        if (fd < 0) continue;
        if (!is_keyboard(fd)) { close(fd); continue; }
        kfd[nk] = fd;
        snprintf(kpath[nk], sizeof kpath[nk], "%s", p);
        nk++;
    }
    closedir(d);
}

/* ---------- 마우스 (포인터 장치: 버튼 BTN_LEFT, 상대 또는 절대 좌표) ---------- */
#define MAXPTR 8
typedef struct { int fd; int abs; int minx, maxx, miny, maxy; int ax, ay; char path[64]; } ptr_t;
static ptr_t ptrs[MAXPTR];
static int nptr;

static int has_bit(const unsigned char *bits, int b) { return (bits[b / 8] >> (b % 8)) & 1; }

static void scan_pointers(void)
{
    DIR *d = opendir("/dev/input");
    struct dirent *e;
    if (!d) return;
    while ((e = readdir(d)) && nptr < MAXPTR) {
        char p[64];
        unsigned char kb[KEY_MAX / 8 + 1], rb[REL_MAX / 8 + 1], ab[ABS_MAX / 8 + 1];
        int fd, have = 0, is_abs;
        if (strncmp(e->d_name, "event", 5)) continue;
        snprintf(p, sizeof p, "/dev/input/%s", e->d_name);
        for (int i = 0; i < nptr; i++) if (!strcmp(ptrs[i].path, p)) have = 1;
        if (have) continue;
        fd = open(p, O_RDONLY | O_NONBLOCK | O_CLOEXEC);
        if (fd < 0) continue;
        memset(kb, 0, sizeof kb); memset(rb, 0, sizeof rb); memset(ab, 0, sizeof ab);
        if (is_keyboard(fd) || ioctl(fd, EVIOCGBIT(EV_KEY, sizeof kb), kb) < 0 || !has_bit(kb, BTN_LEFT)) {
            close(fd); continue;
        }
        if (ioctl(fd, EVIOCGBIT(EV_REL, sizeof rb), rb) >= 0 && has_bit(rb, REL_X) && has_bit(rb, REL_Y)) {
            is_abs = 0;
        } else if (ioctl(fd, EVIOCGBIT(EV_ABS, sizeof ab), ab) >= 0 && has_bit(ab, ABS_X) && has_bit(ab, ABS_Y)) {
            is_abs = 1;
        } else {
            close(fd); continue;
        }
        memset(&ptrs[nptr], 0, sizeof ptrs[nptr]);
        ptrs[nptr].fd = fd;
        ptrs[nptr].abs = is_abs;
        snprintf(ptrs[nptr].path, sizeof ptrs[nptr].path, "%s", p);
        if (is_abs) {
            struct input_absinfo ix, iy;
            if (ioctl(fd, EVIOCGABS(ABS_X), &ix) == 0 && ioctl(fd, EVIOCGABS(ABS_Y), &iy) == 0) {
                ptrs[nptr].minx = ix.minimum; ptrs[nptr].maxx = ix.maximum;
                ptrs[nptr].miny = iy.minimum; ptrs[nptr].maxy = iy.maximum;
            }
        }
        nptr++;
    }
    closedir(d);
}

static void pointer_events(ptr_t *p, int *quit)
{
    struct input_event ev;
    ssize_t k;
    while ((k = read(p->fd, &ev, sizeof ev)) == (ssize_t)sizeof ev) {
        if (ev.type == EV_REL) {
            if (ev.code == REL_X) ui_pointer_move((int)ev.value, 0);
            else if (ev.code == REL_Y) ui_pointer_move(0, (int)ev.value);
        } else if (ev.type == EV_ABS) {
            if (ev.code == ABS_X) p->ax = ev.value;
            else if (ev.code == ABS_Y) p->ay = ev.value;
            ui_pointer_abs(p->ax, p->ay, p->minx, p->maxx, p->miny, p->maxy);
        } else if (ev.type == EV_KEY && ev.code == BTN_LEFT && ev.value == 1) {
            if (ui_click()) *quit = 1;
        }
    }
    if (k < 0 && errno != EAGAIN) p->fd = -1;   /* 장치가 분리됨 */
}

/* 눌린 키와 마우스 이벤트를 처리. 종료 요청이면 1 */
static int pump_keys(int timeout_ms, int *got)
{
    struct pollfd pf[MAXKBD + MAXPTR];
    int quit = 0;
    for (int i = 0; i < nk; i++) { pf[i].fd = kfd[i]; pf[i].events = POLLIN; pf[i].revents = 0; }
    for (int j = 0; j < nptr; j++) { pf[nk + j].fd = ptrs[j].fd; pf[nk + j].events = POLLIN; pf[nk + j].revents = 0; }
    *got = 0;
    if (poll(pf, nk + nptr, timeout_ms) <= 0) return 0;
    for (int i = 0; i < nk; i++) {
        struct input_event ev;
        if (!(pf[i].revents & (POLLIN | POLLERR | POLLHUP))) continue;
        for (;;) {
            ssize_t k = read(kfd[i], &ev, sizeof ev);
            UINT16 sc, un;
            if (k != (ssize_t)sizeof ev) {
                if (k < 0 && errno != EAGAIN) { close(kfd[i]); kfd[i] = -1; }
                break;
            }
            if (ev.type != EV_KEY || ev.value > 2) continue;
            if (translate_key(ev.code, ev.value != 0, &sc, &un)) {
                *got = 1;
                if (ui_handle_key(sc, un)) quit = 1;
            }
        }
    }
    for (int j = 0; j < nptr; j++) {
        if (pf[nk + j].revents & (POLLIN | POLLERR | POLLHUP)) { pointer_events(&ptrs[j], &quit); *got = 1; }
    }
    /* 끊긴 장치 정리 */
    for (int i = 0; i < nk; ) {
        if (kfd[i] >= 0) { i++; continue; }
        for (int j = i; j + 1 < nk; j++) { kfd[j] = kfd[j + 1]; memcpy(kpath[j], kpath[j + 1], 64); }
        nk--;
    }
    for (int j = 0; j < nptr; ) {
        if (ptrs[j].fd >= 0) { j++; continue; }
        for (int k2 = j; k2 + 1 < nptr; k2++) ptrs[k2] = ptrs[k2 + 1];
        nptr--;
    }
    return quit;
}

static void wait_key(void)
{
    int got = 0;
    while (!got) {
        scan_keyboards();
        UINT16 sc, un;
        struct pollfd pf[MAXKBD];
        (void)sc; (void)un;
        for (int i = 0; i < nk; i++) { pf[i].fd = kfd[i]; pf[i].events = POLLIN; }
        if (poll(pf, nk, 500) > 0) {
            for (int i = 0; i < nk; i++) {
                struct input_event ev;
                while (read(kfd[i], &ev, sizeof ev) == (ssize_t)sizeof ev)
                    if (ev.type == EV_KEY && ev.value == 1) got = 1;
            }
        }
    }
}

/* ---------- 시계 ---------- */
static void update_clock(void)
{
    time_t t = time(0);
    struct tm tm;
    char hm[16], ymd[16];
    localtime_r(&t, &tm);
    strftime(hm, sizeof hm, "%H:%M", &tm);
    strftime(ymd, sizeof ymd, "%Y-%m-%d", &tm);
    ui_set_clock(hm, ymd);
}

/* ---------- 미리보기 (테스트) ---------- */
static int preview(const char *path)
{
    const char *typed = "uname -s\r";
    UINT32 W = 1024, H = 768;
    UINT32 *buf = calloc((size_t)W * H, 4);
    gfx_t g = { buf, W, W, H, 1 };
    FILE *f;
    ui_init(&g, wait_key);
    ui_set_clock("14:32", "2026-11-22");
    for (const char *p = typed; *p; p++) ui_handle_key(0, (UINT16)*p);
    ui_print("devices\n");
    device_list(ui_print);
    ui_render();
    f = fopen(path, "wb");
    if (!f) return 1;
    fprintf(f, "P6\n%u %u\n255\n", W, H);
    for (UINT32 i = 0; i < W * H; i++) {
        UINT32 v = buf[i];             /* bgr=1: 0x00RRGGBB */
        fputc((v >> 16) & 0xFF, f); fputc((v >> 8) & 0xFF, f); fputc(v & 0xFF, f);
    }
    fclose(f);
    return 0;
}

/* ---------- 명령 모드: 터미널 안에서 'wifi', 'driver', 'riceos ls 2' 등으로 실행 ---------- */
int linux_command(const char *line, void (*out)(const char *));
static void cli_out(const char *s) { fputs(s, stdout); fflush(stdout); }

static const char *cli_names[] = { "wifi", "driver", "devices", "volumes", "hw", "net", "run", "riceos", 0 };
static const char *riceos_cmds[] = { "devices", "volumes", "ls", "hw", "net", "file", "mount", "wifi", "driver", "run", "sound", "wallpaper", "sfx", 0 };

static int in_list(const char *s, const char **list)
{
    for (int i = 0; list[i]; i++) if (!strcmp(s, list[i])) return 1;
    return 0;
}

static int cli_main(int argc, char **argv, const char *name)
{
    char line[512] = "";
    int is_riceos = !strcmp(name, "riceos");
    if (is_riceos) {
        if (argc < 2 || !in_list(argv[1], riceos_cmds)) {
            cli_out("사용법: riceos 명령 [인자]\n");
            cli_out("  devices, volumes, ls 번호, mount 번호, file 경로, hw, net,\n");
            cli_out("  wifi list|connect|status, driver status|install|nvidia|usb-wifi, run 경로\n");
            cli_out("  sound [status|up|down|mute|unmute|test]\n");
            cli_out("  wallpaper [status|next|set 그림파일|default]  (PNG/BMP, 공백 없는 경로)\n");
            cli_out("  sfx [on|off|toggle|test]\n");
            return 0;
        }
    } else {
        snprintf(line, sizeof line, "%s", name);
    }
    for (int i = 1; i < argc; i++) {
        if (line[0]) strncat(line, " ", sizeof line - strlen(line) - 1);
        strncat(line, argv[i], sizeof line - strlen(line) - 1);
    }
    job_set_inherit(1);     /* 터미널과 입출력을 그대로 잇는다 (Ctrl+C 동작) */
    linux_command(line, cli_out);
    job_set_inherit(0);
    return 0;
}

/* systemctl stop 등 SIGTERM: Chrome 세션 전환용. 전원은 끄지 않고 깨끗이 끝낸다 */
static volatile sig_atomic_t stop_req;
static void on_term(int sig) { (void)sig; stop_req = 1; }

/* 화면 크기와 픽셀 배치 (main에서 설정) */
static UINT32 SW, SH;
static int SBGR;
static ui_conf_t conf;

/* 화면이 요청한 효과음을 실제 소리로 */
static void on_ui_sound(int kind)
{
    switch (kind) {
    case UI_SND_CLICK: sfx_play(SFX_CLICK); break;
    case UI_SND_MENU:  sfx_play(SFX_MENU);  break;
    case UI_SND_ERROR: sfx_play(SFX_ERROR); break;
    default: break;
    }
}

/* /etc/riceos/ui.conf 를 읽어 배경화면과 효과음 설정을 화면에 적용한다 */
static void apply_config(void)
{
    UINT32 top = 0x2F7BC4, bot = 0xC9E8FA, gt = 0x8DC26A, gb = 0x4E8A3A;
    UINT32 *img = 0;

    conf_load(&conf);
    sfx_enable(conf.sfx);
    if (!wp_theme(conf.wallpaper, &top, &bot, &gt, &gb)) {
        img = wp_load_image(conf.wallpaper, SW, SH, SBGR);
        if (!img) {
            char msg[320];
            snprintf(msg, sizeof msg, "배경화면을 열지 못해 기본 배경을 씁니다: %s\n", conf.wallpaper);
            ui_print(msg);
            wp_theme("default", &top, &bot, &gt, &gb);
        }
    }
    ui_set_theme(top, bot, gt, gb);
    free(ui_set_wallpaper(img, SW, SH));
}

int main(int argc, char **argv)
{
    int fb = -1, kd = -1, tick = 0, use_drm = 0;
    struct fb_var_screeninfo vi;
    struct fb_fix_screeninfo fi;
    UINT32 *map = 0, *back;
    UINT32 W = 0, H = 0;
    gfx_t g;
    const char *base = strrchr(argv[0], '/');
    base = base ? base + 1 : argv[0];

    for (int i = 0; cli_names[i]; i++)
        if (!strcmp(base, cli_names[i])) return cli_main(argc, argv, base);

    init_map();
    if (argc >= 3 && !strcmp(argv[1], "--preview")) return preview(argv[2]);

    /* 1순위: DRM으로 연결된 모든 모니터를 각자의 해상도와 주사율로 켠다.
     * 연결된 모니터를 찾지 못하면 기존처럼 /dev/fb0 한 화면을 쓴다. */
    use_drm = display_init() == 0;
    if (use_drm) {
        display_size(&W, &H);
    } else {
        fb = open("/dev/fb0", O_RDWR | O_CLOEXEC);
        if (fb < 0) { perror("/dev/fb0"); return 1; }
        if (ioctl(fb, FBIOGET_VSCREENINFO, &vi) || ioctl(fb, FBIOGET_FSCREENINFO, &fi)) { perror("fb ioctl"); return 1; }
        if (vi.bits_per_pixel != 32) { fprintf(stderr, "32비트 화면만 지원합니다 (현재 %u)\n", vi.bits_per_pixel); return 1; }
        map = mmap(0, fi.smem_len, PROT_READ | PROT_WRITE, MAP_SHARED, fb, 0);
        if (map == MAP_FAILED) { perror("mmap"); return 1; }
        W = vi.xres; H = vi.yres;
    }
    back = calloc((size_t)W * H, 4);

    g.px = back; g.stride = W; g.w = W; g.h = H;
    /* DRM XRGB8888은 빨강이 16비트 위치: 기존 fb0 32비트와 같은 배치 */
    g.bgr = use_drm ? 1 : (vi.red.offset == 16);
    SW = W; SH = H; SBGR = g.bgr;

    kd = open("/dev/tty0", O_RDWR | O_CLOEXEC);
    if (kd >= 0) ioctl(kd, KDSETMODE, KD_GRAPHICS);   /* 콘솔 글자가 화면을 덮지 않게 */
    signal(SIGPIPE, SIG_IGN);

    device_init(0);
    ui_init(&g, wait_key);
    ui_set_sound(on_ui_sound);
    sfx_init();
    apply_config();
    sfx_play_boot_once();
    update_clock();
    scan_keyboards();
    scan_pointers();
    signal(SIGTERM, on_term);

    for (;;) {
        int got, quit;
        quit = pump_keys(100, &got);
        if (term_poll()) ui_mark_dirty();   /* 셸 출력 */
        if (quit || stop_req) break;
        if (++tick >= 10) {
            tick = 0;
            scan_keyboards();
            scan_pointers();
            device_poll(ui_print);
            update_clock();
            if (use_drm && display_poll()) {          /* 모니터를 꽂거나 뺐을 때 다시 설정 */
                ui_print("모니터 변경을 감지해 다시 설정했습니다\n");
                ui_mark_dirty();
            }
            if (conf_changed()) apply_config();      /* riceos wallpaper / sfx 로 바뀐 설정 반영 */
        }
        if (ui_dirty() || got) {
            ui_render();
            if (use_drm) {
                display_present(back, W, H);
            } else {
                for (UINT32 y = 0; y < g.h; y++)
                    memcpy((char *)map + (size_t)y * fi.line_length, back + (size_t)y * g.stride, (size_t)g.w * 4);
            }
        }
    }
    term_stop();
    job_stop();
    if (kd >= 0) ioctl(kd, KDSETMODE, KD_TEXT);
    if (!stop_req) {                /* 전원 끌 때만 종료음 (세션 전환에서는 울리지 않음) */
        sfx_play(SFX_SHUTDOWN);
        usleep(1000000);
    }
    display_close();                /* Xorg(Chrome 세션)가 화면을 쓸 수 있게 DRM 권한을 놓는다 */
    if (stop_req) return 0;          /* 세션 전환: 전원은 끄지 않는다 */
    sync();
    reboot(RB_POWER_OFF);
    return 0;
}

#!/bin/bash
# RICEOS 디스크 이미지 만들기 (Debian 12 bookworm 최소 설치 + RICEOS UI)
# 실행 환경: Debian/Ubuntu 리눅스 또는 Windows의 WSL2 (root 권한, 인터넷 필요)
# 결과: riceos.img  (GPT: EFI 512MB FAT32 + 나머지 ext4)
# 사용: sudo ./make_image.sh [크기, 기본 6G]
set -euo pipefail

SIZE="${1:-6G}"
IMG="$(pwd)/riceos.img"
MNT="$(mktemp -d /tmp/riceos-root.XXXXXX)"
HERE="$(cd "$(dirname "$0")" && pwd)"
MIRROR="http://deb.debian.org/debian"

[ "$(id -u)" = 0 ] || { echo "root 권한이 필요합니다: sudo $0"; exit 1; }
for t in debootstrap parted losetup mkfs.vfat mkfs.ext4 blkid chroot; do
  command -v "$t" >/dev/null || { echo "필요한 도구가 없습니다: $t"
    echo "설치: apt install debootstrap parted dosfstools e2fsprogs util-linux"; exit 1; }
done
[ -x "$HERE/riceos-ui" ] || { echo "먼저 linux/build.sh 로 riceos-ui 를 빌드하세요"; exit 1; }

LOOP1=""; LOOP2=""
cleanup() {
  set +e
  for m in dev/pts dev proc sys boot/efi; do umount "$MNT/$m" 2>/dev/null; done
  umount "$MNT" 2>/dev/null
  [ -n "$LOOP1" ] && losetup -d "$LOOP1" 2>/dev/null
  [ -n "$LOOP2" ] && losetup -d "$LOOP2" 2>/dev/null
  rmdir "$MNT" 2>/dev/null
}
trap cleanup EXIT

echo "[1/7] 빈 이미지와 파티션 만들기 ($SIZE)"
rm -f "$IMG"
truncate -s "$SIZE" "$IMG"
parted -s "$IMG" mklabel gpt \
  mkpart ESP fat32 1MiB 513MiB set 1 esp on \
  mkpart riceos-root ext4 513MiB 100%
TOTAL=$(stat -c %s "$IMG")
# 파티션 노드(loopNp1)가 없는 환경(WSL2 등)을 위해 오프셋으로 각각 연결
LOOP1=$(losetup --find --show -o $((1*1024*1024)) --sizelimit $((512*1024*1024)) "$IMG")
LOOP2=$(losetup --find --show -o $((513*1024*1024)) --sizelimit $((TOTAL - 513*1024*1024 - 1024*1024)) "$IMG")

echo "[2/7] 파일 시스템 만들기"
mkfs.vfat -F32 -n RICEOS-EFI "$LOOP1" >/dev/null
mkfs.ext4 -q -L riceos-root "$LOOP2"
mount "$LOOP2" "$MNT"
mkdir -p "$MNT/boot/efi"
mount "$LOOP1" "$MNT/boot/efi"

echo "[3/7] Debian 기본 시스템 설치 (몇 분 걸립니다)"
debootstrap --arch=amd64 --components=main,contrib,non-free,non-free-firmware \
  --include=linux-image-amd64,grub-efi-amd64,shim-signed,grub-efi-amd64-signed,systemd-sysv,udev,kmod,locales,tzdata,fonts-nanum,exfatprogs,ntfs-3g,dosfstools,e2fsprogs,parted,pciutils,usbutils,iproute2,iputils-ping,less,nano,procps,rfkill,wpasupplicant,iw,firmware-linux,firmware-linux-nonfree,firmware-misc-nonfree,firmware-realtek,firmware-iwlwifi,firmware-atheros,firmware-brcm80211,firmware-amd-graphics,firmware-sof-signed,intel-microcode,amd64-microcode,libgl1-mesa-dri,mesa-vulkan-drivers,vulkan-tools,vainfo,alsa-utils,xserver-xorg-core,xserver-xorg-input-libinput,xinit,xauth,x11-xserver-utils,openbox,fonts-noto-cjk \
  bookworm "$MNT" "$MIRROR"

echo "[4/7] 기본 설정"
ROOT_UUID=$(blkid -s UUID -o value "$LOOP2")
EFI_UUID=$(blkid -s UUID -o value "$LOOP1")
cat > "$MNT/etc/fstab" <<FSTAB
UUID=$ROOT_UUID / ext4 defaults,noatime 0 1
UUID=$EFI_UUID /boot/efi vfat umask=0077 0 2
FSTAB
echo riceos > "$MNT/etc/hostname"
echo "Asia/Seoul" > "$MNT/etc/timezone"
ln -sf /usr/share/zoneinfo/Asia/Seoul "$MNT/etc/localtime"
echo "ko_KR.UTF-8 UTF-8" > "$MNT/etc/locale.gen"
echo "LANG=ko_KR.UTF-8" > "$MNT/etc/default/locale"
mkdir -p "$MNT/etc/systemd/network"
cat > "$MNT/etc/systemd/network/20-wired.network" <<NET
[Match]
Name=en*
[Network]
DHCP=yes
NET

# 무선 인터넷: 무선 장치는 DHCP로 주소를 받는다 (wpa_supplicant가 연결한 뒤 networkd가 처리)
cat > "$MNT/etc/systemd/network/30-wireless.network" <<NET
[Match]
Name=wl*
[Network]
DHCP=yes
NET

# apt 저장소: 펌웨어와 non-free 드라이버를 나중에 인터넷에서 받을 수 있도록 설정
cat > "$MNT/etc/apt/sources.list" <<APT
deb http://deb.debian.org/debian bookworm main contrib non-free non-free-firmware
deb http://deb.debian.org/debian bookworm-updates main contrib non-free non-free-firmware
deb http://security.debian.org/debian-security bookworm-security main contrib non-free non-free-firmware
APT

echo "[5/7] RICEOS UI 설치와 자동 실행 설정"
install -m 755 "$HERE/riceos-ui" "$MNT/usr/local/bin/riceos-ui"
# 명령 이름: 터미널에서 'wifi', 'driver' 등을 치면 같은 프로그램이 해당 기능을 실행한다
for n in wifi driver devices volumes hw net run riceos; do
  ln -sf riceos-ui "$MNT/usr/local/bin/$n"
done
# 부팅 시 소리 켜기: 많은 마더보드가 음소거 상태로 시작한다
cat > "$MNT/etc/systemd/system/riceos-sound.service" <<'UNIT'
[Unit]
Description=RICEOS 기본 소리 설정
After=alsa-restore.service sound.target
Wants=alsa-restore.service

[Service]
Type=oneshot
RemainAfterExit=yes
ExecStart=/bin/sh -c 'amixer -q sset Master unmute 70% 2>/dev/null || amixer -q sset PCM unmute 70% 2>/dev/null; exit 0'

[Install]
WantedBy=multi-user.target
UNIT

cat > "$MNT/etc/systemd/system/riceos-ui.service" <<UNIT
[Unit]
Description=RICEOS UI (전체 화면 바탕화면)
After=systemd-user-sessions.service systemd-udev-settle.service
Conflicts=getty@tty1.service
After=getty@tty1.service

[Service]
Environment=TZ=Asia/Seoul
ExecStart=/usr/local/bin/riceos-ui
Restart=always
RestartSec=1
StandardInput=null
StandardOutput=journal
StandardError=journal

[Install]
WantedBy=multi-user.target
UNIT

# Chrome 실행용 세션: 일반 사용자(riceos)로 Chrome을 띄운다 (root로 실행하면 샌드박스를 끌 수밖에 없다)
cat > "$MNT/usr/local/bin/riceos-chrome" <<'SH'
#!/bin/sh
# RICEOS: Chrome을 X 화면에서 실행한다.
# RICEOS 바탕화면은 잠시 멈추고, Chrome을 닫으면 다시 돌아온다.
if systemctl is-active --quiet riceos-x.service; then
  echo "Chrome 세션이 이미 실행 중입니다."
  exit 0
fi
if ! command -v google-chrome >/dev/null 2>&1; then
  echo "Google Chrome이 설치되어 있지 않습니다."
  exit 1
fi
echo "Chrome을 실행합니다. 화면이 바뀌며, Chrome을 닫으면 RICEOS 바탕화면으로 돌아옵니다."
systemd-run --unit=riceos-x --collect --description="RICEOS Chrome 세션" \
  /bin/sh -c 'systemctl stop riceos-ui.service; xinit /usr/local/bin/riceos-chrome-session -- :1 vt8 -nolisten tcp >/var/log/riceos-x.log 2>&1; systemctl start riceos-ui.service'
SH
chmod 755 "$MNT/usr/local/bin/riceos-chrome"

cat > "$MNT/usr/local/bin/riceos-chrome-session" <<'SH'
#!/bin/sh
# X 세션 안에서 xinit이 실행한다. 창 관리자와 Chrome을 riceos 사용자로 띄운다.
# Chrome이 끝나면 이 스크립트가 끝나고, xinit이 X 서버를 내린다.
xhost +SI:localuser:riceos >/dev/null 2>&1

# 모든 연결된 모니터를 켠다. 각 모니터는 자기 해상도에서 가장 높은 주사율로 돌고,
# 첫 번째 모니터를 기준(주 모니터)으로 나머지를 오른쪽에 가로로 배치한다.
# (주사율은 모니터마다 달라도 된다)
riceos_layout() {
  prev=""
  xrandr -q | awk '
    / connected/ { out=$1; want=1; next }
    want && /^ +[0-9]+x[0-9]+/ { rate=$2; gsub(/[*+]/, "", rate); print out, $1, rate; want=0 }
  ' | while read out res rate; do
    if [ -z "$prev" ]; then pos="--pos 0x0 --primary"; else pos="--right-of $prev"; fi
    xrandr --output "$out" --mode "$res" --rate "$rate" $pos
    prev="$out"
  done
}
riceos_layout
runuser -u riceos -- env DISPLAY="$DISPLAY" HOME=/home/riceos openbox >/dev/null 2>&1 &
runuser -u riceos -- env DISPLAY="$DISPLAY" HOME=/home/riceos \
  google-chrome --start-maximized --no-first-run --disable-dev-shm-usage \
  --user-data-dir=/home/riceos/.config/google-chrome-riceos
pkill -u riceos openbox >/dev/null 2>&1
exit 0
SH
chmod 755 "$MNT/usr/local/bin/riceos-chrome-session"

# 배경화면 그림 폴더: linux/wallpapers/ 에 넣은 PNG/BMP 파일이 'riceos wallpaper next' 순환에 들어간다
mkdir -p "$MNT/usr/share/riceos/wallpapers"
if [ -d "$HERE/wallpapers" ]; then
  cp "$HERE"/wallpapers/*.png "$HERE"/wallpapers/*.bmp "$MNT/usr/share/riceos/wallpapers/" 2>/dev/null || true
fi

echo "[6/7] 부트로더(GRUB)와 서비스 활성화"
mount --bind /dev "$MNT/dev"
mount --bind /dev/pts "$MNT/dev/pts"
mount -t proc proc "$MNT/proc"
mount -t sysfs sys "$MNT/sys"

# Google Chrome: linux/chrome/ 폴더에 올바른 .deb 가 있으면 설치 (없으면 건너뜀)
CHROME_DEB="$HERE/chrome/google-chrome-stable_current_amd64.deb"
if [ -f "$CHROME_DEB" ]; then
  if dpkg-deb -f "$CHROME_DEB" Package 2>/dev/null | grep -qx 'google-chrome-stable'; then
    install -m 644 "$CHROME_DEB" "$MNT/tmp/chrome.deb"
    echo "Google Chrome 패키지를 설치합니다"
  else
    echo "경고: $CHROME_DEB 는 올바른 .deb 파일이 아니므로 Chrome을 건너뜁니다 (HTML 등)"
  fi
else
  echo "참고: linux/chrome/ 에 Chrome .deb 가 없어서 Chrome 없이 만듭니다"
fi

echo "bluez 설치 (서비스 자동 시작은 막음)"
cp /etc/resolv.conf "$MNT/etc/resolv.conf"
printf '#!/bin/sh\nexit 101\n' > "$MNT/usr/sbin/policy-rc.d"
chmod +x "$MNT/usr/sbin/policy-rc.d"
chroot "$MNT" apt-get update -qq
chroot "$MNT" env DEBIAN_FRONTEND=noninteractive apt-get install -y -qq bluez
rm -f "$MNT/usr/sbin/policy-rc.d"

# grub-probe 가 루트 장치를 못 찾는 문제 방지: mtab 연결 + 루트 UUID 직접 지정
ln -sf /proc/self/mounts "$MNT/etc/mtab"
echo "GRUB_DEVICE_UUID=$ROOT_UUID" >> "$MNT/etc/default/grub"

chroot "$MNT" /bin/bash -e <<'CHROOT'
locale-gen
id riceos >/dev/null 2>&1 || useradd -m -s /bin/bash -G audio,video,input riceos
echo "riceos:riceos" | chpasswd
if [ -f /tmp/chrome.deb ]; then
  apt-get update
  apt-get install -y /tmp/chrome.deb
  rm -f /tmp/chrome.deb
fi
echo "root:riceos" | chpasswd
sed -i 's/^GRUB_TIMEOUT=.*/GRUB_TIMEOUT=0/' /etc/default/grub
sed -i 's/^GRUB_CMDLINE_LINUX_DEFAULT=.*/GRUB_CMDLINE_LINUX_DEFAULT="quiet loglevel=3 vt.global_cursor_default=0"/' /etc/default/grub
grep -q GRUB_TIMEOUT_STYLE /etc/default/grub || echo 'GRUB_TIMEOUT_STYLE=hidden' >> /etc/default/grub
# --removable: EFI/BOOT/BOOTX64.EFI 로 설치 (어느 PC에서든 USB로 부팅)
grub-install --target=x86_64-efi --efi-directory=/boot/efi --removable --no-nvram
systemctl enable riceos-ui.service systemd-networkd.service systemd-resolved.service riceos-sound.service
systemctl enable alsa-restore.service 2>/dev/null || true
systemctl mask getty@tty1.service
ln -sf /run/systemd/resolve/stub-resolv.conf /etc/resolv.conf
apt-get clean
CHROOT

# update-grub 대신 grub.cfg 직접 작성 (chroot 안 grub-probe 가 loop 장치를 찾지 못함)
mkdir -p "$MNT/boot/grub"
cat > "$MNT/boot/grub/grub.cfg" <<GRUBCFG
set timeout=0
set default=0
insmod part_gpt
insmod ext2
search --no-floppy --fs-uuid --set=root $ROOT_UUID
menuentry "RICEOS" {
    linux /vmlinuz root=UUID=$ROOT_UUID ro quiet loglevel=3 vt.global_cursor_default=0
    initrd /initrd.img
}
GRUBCFG
test -e "$MNT/vmlinuz" && test -e "$MNT/initrd.img" || { echo "커널 또는 initrd 심볼릭 링크가 없습니다"; exit 1; }

echo "[7/7] 정리"
sync
echo
echo "완료: $IMG"
echo "USB에 쓰기: Rufus에서 이 .img 를 선택 (DD 이미지 모드) — USB 전체가 지워집니다."
echo "비상용 콘솔: 부팅 후 Ctrl+Alt+F2 → root / riceos"

#!/bin/sh
# 리눅스용 RICEOS UI 빌드 (정적 링크). 결과: riceos-ui
#
# 라이브러리 선택 순서:
#   1) third_party/zlib, third_party/libpng 의 소스가 있으면 그것을 직접 컴파일 (내장 빌드, 기본)
#   2) RICEOS_SYSTEM_LIBS=1 이면 시스템 라이브러리 (libpng-dev, zlib1g-dev)
#   3) 그 밖에는 deps/fetch_build.sh 로 인터넷에서 받아 빌드 (최초 1회, 네트워크 필요)
set -e
cd "$(dirname "$0")"
ROOT="$PWD"
ZSRC="$ROOT/third_party/zlib"
PSRC="$ROOT/third_party/libpng"
DEPS="$ROOT/deps"

ZLIB_CS="adler32 crc32 deflate infback inffast inflate inftrees trees zutil compress uncompr gzclose gzlib gzread gzwrite"
PNG_CS="png pngerror pngget pngmem pngpread pngread pngrio pngrtran pngrutil pngset pngtrans pngwio pngwrite pngwtran pngwutil"

if [ "${RICEOS_SYSTEM_LIBS:-0}" != 1 ] && [ -f "$ZSRC/zlib.h" ] && [ -f "$PSRC/png.h" ]; then
    MODE=vendored
    # libpng 설정 헤더: 사전 생성본이 있으면 pnglibconf.h 로 복사 (configure 없이 쓸 수 있게)
    if [ ! -f "$PSRC/pnglibconf.h" ]; then
        for c in "$PSRC/pnglibconf.h.prebuilt" "$PSRC/scripts/pnglibconf.h.prebuilt"; do
            [ -f "$c" ] && cp "$c" "$PSRC/pnglibconf.h" && break
        done
    fi
    MISS=""
    for f in $ZLIB_CS; do [ -f "$ZSRC/$f.c" ] || MISS="$MISS zlib/$f.c"; done
    for f in $PNG_CS; do [ -f "$PSRC/$f.c" ] || MISS="$MISS libpng/$f.c"; done
    [ -f "$PSRC/pnglibconf.h" ] || MISS="$MISS libpng/pnglibconf.h"
    if [ -n "$MISS" ]; then
        echo "third_party 소스가 부족합니다 (third_party/README.txt 참고):" >&2
        for m in $MISS; do echo "  - $m" >&2; done
        exit 1
    fi
    ZSRCS=""; for f in $ZLIB_CS; do ZSRCS="$ZSRCS $ZSRC/$f.c"; done
    PSRCS=""; for f in $PNG_CS; do PSRCS="$PSRCS $PSRC/$f.c"; done
    INC="-I$ZSRC -I$PSRC"
    LIBSRCS="$ZSRCS $PSRCS"
    LIBS="-lm"
    echo "내장 소스(third_party)로 zlib, libpng 을 함께 컴파일합니다"
elif [ "${RICEOS_SYSTEM_LIBS:-0}" = 1 ]; then
    MODE=system
    INC=""; LIBSRCS=""; LIBS="-lpng16 -lz -lm"
    echo "시스템 라이브러리를 사용합니다 (libpng-dev, zlib1g-dev)"
else
    # 소스도 시스템 라이브러리도 없으면 처음 빌드할 때 인터넷에서 받아 빌드한다 (최초 1회)
    MODE=fetch
    if [ ! -f "$DEPS/prefix/lib/libpng16.a" ] || [ ! -f "$DEPS/prefix/lib/libz.a" ]; then
        echo "zlib, libpng 을 인터넷에서 받아 빌드합니다 (최초 1회)"
        sh "$DEPS/fetch_build.sh" || { echo "라이브러리 준비 실패. 오프라인이면 third_party/README.txt 를 참고하세요." >&2; exit 1; }
    fi
    INC="-I$DEPS/prefix/include"; LIBSRCS=""; LIBS="-L$DEPS/prefix/lib -lpng16 -lz -lm"
    echo "받은 라이브러리(deps/prefix)를 사용합니다"
fi

# 모든 소스(내장 라이브러리 포함)를 같은 옵션으로 컴파일한다.
gcc -O2 -Wall -Wextra -Wno-format-truncation -DRICEOS_LINUX -I. -I.. $INC -include errno.h -static \
    -o riceos-ui main_linux.c display.c media.c ../gfx.c ../ui.c backend.c job.c elfinfo.c term.c font_linux.S \
    $LIBSRCS $LIBS
echo "built linux/riceos-ui ($MODE)"

#!/usr/bin/env python3
"""RICEOS UI - 화면 요소만 담당한다.

네트워크, 소리, 모니터, 프린터, 장치 정보 같은 실제 일은 모두 리눅스 도구
(nmcli, wpctl, xrandr, lpstat, lspci ...)가 하고, 이 프로그램은 그 결과를 보여 주고
버튼을 누르면 해당 도구를 호출할 뿐이다.

사용법:
  riceos-ui            설정(제어판) 열기
  riceos-ui --menu     앱 목록 열기
  riceos-ui --login    로그인 화면을 먼저 띄운 뒤 앱 목록 열기 (부팅 때 쓴다)
  riceos-ui --quick    빠른 설정 창 (무선, 소리)
  riceos-ui --install  하드디스크 설치 화면 (USB 임시 모드에서)

언어: 한국어(ko), English(en), 日本語(ja), 中文(zh), Français(fr), Español(es).
고르는 순서: 환경 변수 RICEOS_LANG > ~/.config/riceos/ui.json > LANG > 한국어.
"""
import json
import os
import re
import shlex
import subprocess
import sys
import threading


# ---------------------------------------------------------------------------
# 언어 (번역 사전). 새 문장을 넣을 때는 여섯 언어를 모두 채운다 (tests 에서 검사한다).
# 바뀌는 값은 {이름} 으로 적고 t("키", 이름=값) 으로 채운다.
# ---------------------------------------------------------------------------

LANGS = ("ko", "en", "ja", "zh", "fr", "es")
LANG_NAMES = {"ko": "한국어", "en": "English", "ja": "日本語",
              "zh": "中文(简体)", "fr": "Français", "es": "Español"}

STRINGS = {
    # 공통
    "no_program": {"ko": "{name} 프로그램이 없습니다", "en": "Program not found: {name}",
                   "ja": "{name} プログラムがありません", "zh": "没有 {name} 程序",
                   "fr": "Programme introuvable : {name}", "es": "No se encontró el programa {name}"},
    "timeout": {"ko": "시간이 너무 오래 걸려 중단했습니다", "en": "Timed out and stopped",
                "ja": "時間がかかりすぎたため中断しました", "zh": "耗时过长，已中止",
                "fr": "Trop long, arrêté", "es": "Tardó demasiado y se detuvo"},
    "not_installed": {"ko": "{name} 프로그램이 설치되어 있지 않습니다",
                      "en": "{name} is not installed", "ja": "{name} はインストールされていません",
                      "zh": "未安装 {name} 程序", "fr": "{name} n'est pas installé",
                      "es": "{name} no está instalado"},
    "start_fail": {"ko": "실행하지 못했습니다: {err}", "en": "Could not start it: {err}",
                   "ja": "起動できませんでした: {err}", "zh": "无法启动：{err}",
                   "fr": "Impossible de le lancer : {err}", "es": "No se pudo iniciar: {err}"},
    "page_fail": {"ko": "{title} 화면을 열지 못했습니다: {err}",
                  "en": "Could not open the {title} page: {err}",
                  "ja": "{title} 画面を開けませんでした: {err}", "zh": "无法打开 {title} 页面：{err}",
                  "fr": "Impossible d'ouvrir la page {title} : {err}",
                  "es": "No se pudo abrir la página {title}: {err}"},
    "refresh": {"ko": "새로고침", "en": "Refresh", "ja": "更新", "zh": "刷新",
                "fr": "Actualiser", "es": "Actualizar"},
    "close": {"ko": "닫기", "en": "Close", "ja": "閉じる", "zh": "关闭", "fr": "Fermer", "es": "Cerrar"},
    "loading": {"ko": "불러오는 중...", "en": "Loading...", "ja": "読み込み中...", "zh": "正在加载...",
                "fr": "Chargement...", "es": "Cargando..."},
    "checking": {"ko": "확인하는 중...", "en": "Checking...", "ja": "確認しています...",
                 "zh": "正在验证...", "fr": "Vérification...", "es": "Comprobando..."},
    # 페이지 이름
    "nav_apps": {"ko": "앱", "en": "Apps", "ja": "アプリ", "zh": "应用",
                 "fr": "Applications", "es": "Aplicaciones"},
    "nav_network": {"ko": "네트워크", "en": "Network", "ja": "ネットワーク", "zh": "网络",
                    "fr": "Réseau", "es": "Red"},
    "nav_sound": {"ko": "소리", "en": "Sound", "ja": "サウンド", "zh": "声音",
                  "fr": "Son", "es": "Sonido"},
    "disp_identify": {"ko": '모니터 식별 (이름 띄우기)', "en": 'Identify monitors (show names)', "ja": 'モニターを識別（名前を表示）', "zh": '识别显示器（显示名称）', "fr": 'Identifier les écrans (afficher les noms)', "es": 'Identificar monitores (mostrar nombres)'},
    "disp_monitor_label": {"ko": '{n}번 · {name}', "en": '#{n} · {name}', "ja": '{n} · {name}', "zh": '{n} · {name}', "fr": '{n} · {name}', "es": '{n} · {name}'},
    "disp_mode": {"ko": '화면 방식', "en": 'Display mode', "ja": '表示方式', "zh": '显示模式', "fr": "Mode d'affichage", "es": 'Modo de pantalla'},
    "disp_extend": {"ko": '확장 (모니터를 이어서 사용)', "en": 'Extend (use as one desktop)', "ja": '拡張（デスクトップを広げる）', "zh": '扩展（延伸桌面）', "fr": 'Étendre (un seul bureau)', "es": 'Extender (un solo escritorio)'},
    "disp_clone": {"ko": '복제 (같은 화면 보여 주기)', "en": 'Clone (show the same screen)', "ja": '複製（同じ画面を表示）', "zh": '复制（显示相同画面）', "fr": 'Dupliquer (même image)', "es": 'Duplicar (misma imagen)'},
    "disp_resolution": {"ko": '해상도', "en": 'Resolution', "ja": '解像度', "zh": '分辨率', "fr": 'Résolution', "es": 'Resolución'},
    "disp_rate": {"ko": '주사율', "en": 'Refresh rate', "ja": 'リフレッシュレート', "zh": '刷新率', "fr": 'Fréquence', "es": 'Frecuencia'},
    "disp_position": {"ko": '배치', "en": 'Position', "ja": '配置', "zh": '位置', "fr": 'Position', "es": 'Posición'},
    "disp_anchor": {"ko": '기준 모니터', "en": 'Relative to', "ja": '基準モニター', "zh": '参照显示器', "fr": 'Par rapport à', "es": 'Respecto a'},
    "disp_side_left": {"ko": '왼쪽에', "en": 'Left of', "ja": '左側', "zh": '左侧', "fr": 'À gauche de', "es": 'A la izquierda de'},
    "disp_side_right": {"ko": '오른쪽에', "en": 'Right of', "ja": '右側', "zh": '右侧', "fr": 'À droite de', "es": 'A la derecha de'},
    "disp_side_above": {"ko": '위에', "en": 'Above', "ja": '上', "zh": '上方', "fr": 'Au-dessus de', "es": 'Encima de'},
    "disp_side_below": {"ko": '아래에', "en": 'Below', "ja": '下', "zh": '下方', "fr": 'En dessous de', "es": 'Debajo de'},
    "disp_apply": {"ko": '적용', "en": 'Apply', "ja": '適用', "zh": '应用', "fr": 'Appliquer', "es": 'Aplicar'},
    "disp_applying": {"ko": '적용하는 중...', "en": 'Applying...', "ja": '適用中...', "zh": '正在应用...', "fr": 'Application en cours...', "es": 'Aplicando...'},
    "disp_applied": {"ko": '화면 설정을 적용했습니다. 다음 실행에도 이 설정을 씁니다.', "en": 'Display settings applied. They will be used next time too.', "ja": '画面設定を適用しました。次回も同じ設定を使います。', "zh": '已应用显示设置。下次启动也会使用。', "fr": "Paramètres d'affichage appliqués. Ils seront utilisés aussi au prochain démarrage.", "es": 'Ajustes de pantalla aplicados. Se usarán también la próxima vez.'},
    "disp_apply_fail": {"ko": '화면 설정에 실패했습니다', "en": 'Could not apply display settings', "ja": '画面設定に失敗しました', "zh": '应用显示设置失败', "fr": "Échec de l'application des paramètres d'affichage", "es": 'No se pudieron aplicar los ajustes de pantalla'},
    "nav_display": {"ko": "디스플레이", "en": "Display", "ja": "ディスプレイ", "zh": "显示",
                    "fr": "Affichage", "es": "Pantalla"},
    "nav_printer": {"ko": "프린터", "en": "Printers", "ja": "プリンター", "zh": "打印机",
                    "fr": "Imprimantes", "es": "Impresoras"},
    "nav_personal": {"ko": "개인 설정", "en": "Personalization", "ja": "個人設定", "zh": "个性化",
                     "fr": "Personnalisation", "es": "Personalización"},
    "nav_system": {"ko": "시스템 정보", "en": "System information", "ja": "システム情報",
                   "zh": "系统信息", "fr": "Informations système", "es": "Información del sistema"},
    "app_title": {"ko": "RICEOS", "en": "RICEOS", "ja": "RICEOS", "zh": "RICEOS",
                  "fr": "RICEOS", "es": "RICEOS"},
    # 네트워크
    "net_checking": {"ko": "네트워크를 확인하는 중...", "en": "Checking the network...",
                     "ja": "ネットワークを確認しています...", "zh": "正在检查网络...",
                     "fr": "Vérification du réseau...", "es": "Comprobando la red..."},
    "wifi_on": {"ko": "무선 사용", "en": "Wi-Fi", "ja": "無線LAN", "zh": "无线网络",
                "fr": "Wi-Fi", "es": "Wi-Fi"},
    "wifi_list_fail": {"ko": "무선 목록을 가져오지 못했습니다",
                       "en": "Could not get the Wi-Fi list",
                       "ja": "無線LANの一覧を取得できませんでした", "zh": "无法获取无线网络列表",
                       "fr": "Impossible d'obtenir la liste Wi-Fi",
                       "es": "No se pudo obtener la lista de Wi-Fi"},
    "wifi_none": {"ko": "주변에서 무선 네트워크를 찾지 못했습니다",
                  "en": "No Wi-Fi networks found nearby", "ja": "近くに無線LANが見つかりません",
                  "zh": "附近没有找到无线网络", "fr": "Aucun réseau Wi-Fi à proximité",
                  "es": "No se encontraron redes Wi-Fi cercanas"},
    "signal": {"ko": "신호", "en": "Signal", "ja": "信号", "zh": "信号", "fr": "Signal", "es": "Señal"},
    "open": {"ko": "열림", "en": "Open", "ja": "開放", "zh": "开放", "fr": "Ouvert", "es": "Abierta"},
    "net_none": {"ko": "네트워크 장치를 찾지 못했습니다", "en": "No network devices found",
                 "ja": "ネットワーク機器が見つかりません", "zh": "没有找到网络设备",
                 "fr": "Aucun périphérique réseau trouvé",
                 "es": "No se encontraron dispositivos de red"},
    "kind_wifi": {"ko": "무선", "en": "Wireless", "ja": "無線", "zh": "无线", "fr": "Sans fil",
                  "es": "Inalámbrica"},
    "kind_wired": {"ko": "유선", "en": "Wired", "ja": "有線", "zh": "有线", "fr": "Filaire",
                   "es": "Cableada"},
    "connect_title": {"ko": "{ssid} 연결", "en": "Connect to {ssid}", "ja": "{ssid} に接続",
                      "zh": "连接到 {ssid}", "fr": "Connexion à {ssid}", "es": "Conectar a {ssid}"},
    "ask_password": {"ko": "{ssid} 의 비밀번호", "en": "Password for {ssid}",
                     "ja": "{ssid} のパスワード", "zh": "{ssid} 的密码",
                     "fr": "Mot de passe pour {ssid}", "es": "Contraseña de {ssid}"},
    "connect": {"ko": "연결", "en": "Connect", "ja": "接続", "zh": "连接", "fr": "Connecter",
                "es": "Conectar"},
    "connecting": {"ko": "{ssid} 에 연결하는 중...", "en": "Connecting to {ssid}...",
                   "ja": "{ssid} に接続しています...", "zh": "正在连接 {ssid}...",
                   "fr": "Connexion à {ssid}...", "es": "Conectando a {ssid}..."},
    "connected": {"ko": "연결했습니다", "en": "Connected", "ja": "接続しました", "zh": "已连接",
                  "fr": "Connecté", "es": "Conectado"},
    "wifi_err_perm": {"ko": "이 기기에서 와이파이를 설정할 권한이 없습니다", "en": "No permission to change Wi-Fi settings on this device", "ja": "このデバイスで Wi-Fi を設定する権限がありません", "zh": "没有在此设备上更改无线网络设置的权限", "fr": "Autorisation insuffisante pour modifier le Wi-Fi sur cet appareil", "es": "No tiene permiso para cambiar la configuración Wi-Fi de este equipo"},
    "wifi_err_auth": {"ko": '비밀번호가 맞지 않거나 인증에 실패했습니다', "en": 'Wrong password or authentication failed', "ja": 'パスワードが違うか、認証に失敗しました', "zh": '密码错误或认证失败', "fr": "Mot de passe incorrect ou échec de l'authentification", "es": 'Contraseña incorrecta o fallo de autenticación'},
    "wifi_err_timeout": {"ko": '연결 시간이 초과되었습니다', "en": 'Connection timed out', "ja": '接続がタイムアウトしました', "zh": '连接超时', "fr": 'Délai de connexion dépassé', "es": 'Tiempo de conexión agotado'},
    "wifi_err_notfound": {"ko": '네트워크를 찾을 수 없습니다. 다시 검색해 주세요', "en": 'Network not found. Please scan again', "ja": 'ネットワークが見つかりません。再検索してください', "zh": '未找到网络，请重新搜索', "fr": 'Réseau introuvable. Relancez la recherche', "es": 'Red no encontrada. Vuelva a buscar'},
    "wifi_err_device": {"ko": '와이파이 장치를 사용할 수 없습니다', "en": 'Wi-Fi device is not available', "ja": 'Wi-Fi デバイスを使用できません', "zh": '无线网卡不可用', "fr": 'Périphérique Wi-Fi indisponible', "es": 'El dispositivo Wi-Fi no está disponible'},
    "wifi_err_generic": {"ko": '연결에 실패했습니다', "en": 'Connection failed', "ja": '接続に失敗しました', "zh": '连接失败', "fr": 'Échec de la connexion', "es": 'Error de conexión'},
    "connect_fail": {"ko": "연결하지 못했습니다", "en": "Could not connect",
                     "ja": "接続できませんでした", "zh": "连接失败", "fr": "Connexion impossible",
                     "es": "No se pudo conectar"},
    # 소리
    "sound_no_server": {"ko": "소리 서버(PipeWire)에 연결하지 못했습니다",
                        "en": "Could not reach the sound server (PipeWire)",
                        "ja": "サウンドサーバー（PipeWire）に接続できません",
                        "zh": "无法连接声音服务 (PipeWire)",
                        "fr": "Impossible de joindre le serveur audio (PipeWire)",
                        "es": "No se pudo conectar con el servidor de sonido (PipeWire)"},
    "mute": {"ko": "음소거", "en": "Mute", "ja": "ミュート", "zh": "静音", "fr": "Muet",
             "es": "Silenciar"},
    "adv_sound": {"ko": "고급 소리 설정 열기 (pavucontrol)",
                  "en": "Advanced sound settings (pavucontrol)",
                  "ja": "詳細なサウンド設定 (pavucontrol)", "zh": "高级声音设置 (pavucontrol)",
                  "fr": "Réglages audio avancés (pavucontrol)",
                  "es": "Ajustes avanzados de sonido (pavucontrol)"},
    "vol_line": {"ko": "소리: {v}%{muted}", "en": "Sound: {v}%{muted}", "ja": "サウンド: {v}%{muted}",
                 "zh": "声音：{v}%{muted}", "fr": "Son : {v}%{muted}", "es": "Sonido: {v}%{muted}"},
    "muted_tag": {"ko": " (음소거)", "en": " (muted)", "ja": " (ミュート)", "zh": " (静音)",
                  "fr": " (muet)", "es": " (silenciado)"},
    "vol_checking": {"ko": "소리: 확인하는 중...", "en": "Sound: checking...",
                     "ja": "サウンド: 確認中...", "zh": "声音：正在检查...",
                     "fr": "Son : vérification...", "es": "Sonido: comprobando..."},
    # 디스플레이
    "monitor_none": {"ko": "연결된 모니터를 찾지 못했습니다", "en": "No monitor found",
                     "ja": "モニターが見つかりません", "zh": "没有找到显示器",
                     "fr": "Aucun écran détecté", "es": "No se encontró ningún monitor"},
    "primary_tag": {"ko": " (주 모니터)", "en": " (primary)", "ja": " (メイン)", "zh": " (主显示器)",
                    "fr": " (principal)", "es": " (principal)"},
    "off": {"ko": "꺼짐", "en": "Off", "ja": "オフ", "zh": "关闭", "fr": "Éteint", "es": "Apagado"},
    "printer_none": {"ko": "등록된 프린터가 없습니다", "en": "No printers registered",
                     "ja": "登録されたプリンターはありません", "zh": "没有已添加的打印机",
                     "fr": "Aucune imprimante enregistrée", "es": "No hay impresoras registradas"},
    # 개인 설정
    "theme_btn": {"ko": "테마, 글꼴, 아이콘 (lxappearance)",
                  "en": "Theme, fonts, icons (lxappearance)",
                  "ja": "テーマ、フォント、アイコン (lxappearance)",
                  "zh": "主题、字体、图标 (lxappearance)",
                  "fr": "Thème, polices, icônes (lxappearance)",
                  "es": "Tema, fuentes, iconos (lxappearance)"},
    "wallpaper_btn": {"ko": "바탕화면 배경과 아이콘 (pcmanfm)",
                      "en": "Desktop background and icons (pcmanfm)",
                      "ja": "デスクトップの背景とアイコン (pcmanfm)",
                      "zh": "桌面背景和图标 (pcmanfm)",
                      "fr": "Fond d'écran et icônes du bureau (pcmanfm)",
                      "es": "Fondo de escritorio e iconos (pcmanfm)"},
    "files_btn": {"ko": "파일 관리자 열기", "en": "Open file manager", "ja": "ファイルマネージャーを開く",
                  "zh": "打开文件管理器", "fr": "Ouvrir le gestionnaire de fichiers",
                  "es": "Abrir el gestor de archivos"},
    "lang_label": {"ko": "언어", "en": "Language", "ja": "言語", "zh": "语言", "fr": "Langue",
                   "es": "Idioma"},
    "lang_save": {"ko": "언어 저장", "en": "Save language", "ja": "言語を保存", "zh": "保存语言",
                  "fr": "Enregistrer la langue", "es": "Guardar idioma"},
    "lang_saved": {"ko": "언어를 저장했습니다. 다시 열면 적용됩니다",
                   "en": "Language saved. It applies when you reopen.",
                   "ja": "言語を保存しました。次回起動時に反映されます。",
                   "zh": "语言已保存，重新打开后生效。",
                   "fr": "Langue enregistrée. Elle s'appliquera à la prochaine ouverture.",
                   "es": "Idioma guardado. Se aplicará al volver a abrir."},
    "lang_save_fail": {"ko": "언어를 저장하지 못했습니다",
                       "en": "Could not save the language",
                       "ja": "言語を保存できませんでした", "zh": "无法保存语言",
                       "fr": "Impossible d'enregistrer la langue",
                       "es": "No se pudo guardar el idioma"},
    "pw_section": {"ko": "로그인 비밀번호 바꾸기", "en": "Change sign-in password",
                   "ja": "ログインパスワードを変更", "zh": "更改登录密码",
                   "fr": "Changer le mot de passe de connexion",
                   "es": "Cambiar la contraseña de inicio de sesión"},
    "cur_pw": {"ko": "현재 비밀번호", "en": "Current password", "ja": "現在のパスワード",
               "zh": "当前密码", "fr": "Mot de passe actuel", "es": "Contraseña actual"},
    "new_pw": {"ko": "새 비밀번호", "en": "New password", "ja": "新しいパスワード", "zh": "新密码",
               "fr": "Nouveau mot de passe", "es": "Nueva contraseña"},
    "new_pw2": {"ko": "새 비밀번호 확인", "en": "Confirm new password", "ja": "新しいパスワード（確認）",
                "zh": "确认新密码", "fr": "Confirmer le nouveau mot de passe",
                "es": "Confirmar la nueva contraseña"},
    "pw_change_btn": {"ko": "비밀번호 바꾸기", "en": "Change password", "ja": "パスワードを変更",
                      "zh": "更改密码", "fr": "Changer le mot de passe", "es": "Cambiar contraseña"},
    "pw_empty": {"ko": "새 비밀번호를 입력하세요 (줄바꿈은 쓸 수 없습니다)",
                 "en": "Enter a new password (line breaks are not allowed)",
                 "ja": "新しいパスワードを入力してください（改行は使えません）",
                 "zh": "请输入新密码（不能包含换行）",
                 "fr": "Saisissez un nouveau mot de passe (pas de saut de ligne)",
                 "es": "Introduzca una nueva contraseña (no se permiten saltos de línea)"},
    "pw_new_mismatch": {"ko": "새 비밀번호가 서로 다릅니다", "en": "The new passwords do not match",
                        "ja": "新しいパスワードが一致しません", "zh": "两次输入的新密码不一致",
                        "fr": "Les nouveaux mots de passe ne correspondent pas",
                        "es": "Las nuevas contraseñas no coinciden"},
    "pw_changing": {"ko": "비밀번호를 바꾸는 중...", "en": "Changing password...",
                    "ja": "パスワードを変更しています...", "zh": "正在更改密码...",
                    "fr": "Modification du mot de passe...", "es": "Cambiando la contraseña..."},
    "pw_cur_wrong": {"ko": "현재 비밀번호가 맞지 않습니다", "en": "The current password is incorrect",
                     "ja": "現在のパスワードが正しくありません", "zh": "当前密码不正确",
                     "fr": "Mot de passe actuel incorrect",
                     "es": "La contraseña actual no es correcta"},
    "pw_changed": {"ko": "비밀번호를 바꿨습니다", "en": "Password changed",
                   "ja": "パスワードを変更しました", "zh": "密码已更改",
                   "fr": "Mot de passe modifié", "es": "Contraseña cambiada"},
    "pw_change_fail": {"ko": "비밀번호를 바꾸지 못했습니다", "en": "Could not change the password",
                       "ja": "パスワードを変更できませんでした", "zh": "无法更改密码",
                       "fr": "Impossible de changer le mot de passe",
                       "es": "No se pudo cambiar la contraseña"},
    # 앱 목록
    "app_start_fail": {"ko": "실행하지 못했습니다: {err}", "en": "Could not start the app: {err}",
                       "ja": "起動できませんでした: {err}", "zh": "无法启动：{err}",
                       "fr": "Impossible de lancer l'application : {err}",
                       "es": "No se pudo iniciar la aplicación: {err}"},
    # 로그인
    "gate_setup_title": {"ko": "처음 설정", "en": "First-time setup", "ja": "初回設定",
                         "zh": "首次设置", "fr": "Première configuration",
                         "es": "Configuración inicial"},
    "gate_setup_hint": {"ko": "RICEOS 로그인 비밀번호를 정하세요. 이 비밀번호는 아이디 riceos 의 콘솔 로그인과 sudo 에도 쓰입니다.",
                        "en": "Choose the RICEOS sign-in password. It is also used for console login and sudo for the user riceos.",
                        "ja": "RICEOS のログインパスワードを設定してください。このパスワードは riceos ユーザーのコンソールログインと sudo にも使われます。",
                        "zh": "请设置 RICEOS 登录密码。该密码也用于 riceos 用户的控制台登录和 sudo。",
                        "fr": "Choisissez le mot de passe de connexion RICEOS. Il sert aussi à la connexion console et à sudo pour l'utilisateur riceos.",
                        "es": "Elija la contraseña de inicio de sesión de RICEOS. También se usa para el inicio de sesión en consola y sudo del usuario riceos."},
    "user_riceos": {"ko": "아이디: riceos", "en": "User: riceos", "ja": "ユーザー名: riceos",
                    "zh": "用户名：riceos", "fr": "Identifiant : riceos", "es": "Usuario: riceos"},
    "password": {"ko": "비밀번호", "en": "Password", "ja": "パスワード", "zh": "密码",
                 "fr": "Mot de passe", "es": "Contraseña"},
    "password_new": {"ko": "새 비밀번호", "en": "New password", "ja": "新しいパスワード",
                     "zh": "新密码", "fr": "Nouveau mot de passe", "es": "Nueva contraseña"},
    "password_confirm": {"ko": "비밀번호 확인", "en": "Confirm password", "ja": "パスワード（確認）",
                         "zh": "确认密码", "fr": "Confirmer le mot de passe",
                         "es": "Confirmar contraseña"},
    "setup_go": {"ko": "설정하고 들어가기", "en": "Set up and continue", "ja": "設定して進む",
                 "zh": "设置并进入", "fr": "Configurer et entrer", "es": "Configurar y entrar"},
    "login_go": {"ko": "로그인", "en": "Sign in", "ja": "ログイン", "zh": "登录",
                 "fr": "Se connecter", "es": "Iniciar sesión"},
    "pw_mismatch": {"ko": "두 비밀번호가 다릅니다", "en": "The two passwords do not match",
                    "ja": "2つのパスワードが一致しません", "zh": "两次输入的密码不一致",
                    "fr": "Les deux mots de passe ne correspondent pas",
                    "es": "Las dos contraseñas no coinciden"},
    "setup_fail": {"ko": "설정하지 못했습니다", "en": "Could not set the password",
                   "ja": "設定できませんでした", "zh": "无法设置", "fr": "Impossible de définir le mot de passe",
                   "es": "No se pudo establecer la contraseña"},
    "login_wrong": {"ko": "비밀번호가 맞지 않습니다", "en": "Incorrect password",
                    "ja": "パスワードが正しくありません", "zh": "密码不正确",
                    "fr": "Mot de passe incorrect", "es": "Contraseña incorrecta"},
    "login_check_fail": {"ko": "로그인을 확인하지 못했습니다", "en": "Could not verify the login",
                         "ja": "ログインを確認できませんでした", "zh": "无法验证登录",
                         "fr": "Impossible de vérifier la connexion",
                         "es": "No se pudo verificar el inicio de sesión"},
    # 빠른 설정
    "quick_title": {"ko": "빠른 설정", "en": "Quick settings", "ja": "クイック設定", "zh": "快速设置",
                    "fr": "Réglages rapides", "es": "Ajustes rápidos"},
    "quick_net": {"ko": "네트워크 설정", "en": "Network settings", "ja": "ネットワーク設定",
                  "zh": "网络设置", "fr": "Réglages réseau", "es": "Ajustes de red"},
    "quick_sound": {"ko": "소리 설정", "en": "Sound settings", "ja": "サウンド設定",
                    "zh": "声音设置", "fr": "Réglages du son", "es": "Ajustes de sonido"},
    "quick_apps": {"ko": "앱 목록", "en": "App list", "ja": "アプリ一覧", "zh": "应用列表",
                   "fr": "Liste des applications", "es": "Lista de aplicaciones"},
    "sound_unavailable": {"ko": "소리 서버에 연결하지 못했습니다",
                          "en": "Could not reach the sound server",
                          "ja": "サウンドサーバーに接続できません", "zh": "无法连接声音服务",
                          "fr": "Impossible de joindre le serveur audio",
                          "es": "No se pudo conectar con el servidor de sonido"},
    # 시스템 정보 (riceos-sysinfo 가 같은 언어로 항목 이름을 쓴다)
    "sysinfo_fail": {"ko": "시스템 정보를 읽지 못했습니다", "en": "Could not read system information",
                     "ja": "システム情報を読み取れませんでした", "zh": "无法读取系统信息",
                     "fr": "Impossible de lire les informations système",
                     "es": "No se pudo leer la información del sistema"},
    "nav_install": {"ko": "설치", "en": "Install", "ja": "インストール", "zh": "安装", "fr": "Installer", "es": "Instalar"},
    "live_banner": {"ko": "임시 모드입니다. 여기서 바꾼 내용은 재부팅하면 사라집니다. 저장하려면 '설치'를 하세요.", "en": "Temporary mode. Changes made here are lost when you reboot. Use Install to keep them.", "ja": "一時モードです。ここでの変更は再起動すると消えます。保存するにはインストールしてください。", "zh": "临时模式。这里的更改在重启后会消失。要保存，请使用“安装”。", "fr": "Mode temporaire. Les modifications sont perdues au redémarrage. Utilisez « Installer » pour les conserver.", "es": "Modo temporal. Los cambios se pierden al reiniciar. Use «Instalar» para conservarlos."},
    "install_not_live": {"ko": "이 시스템은 이미 하드디스크에 설치되어 있습니다. 설치 프로그램은 USB 임시 모드에서만 쓸 수 있습니다.", "en": "This system is already installed on a disk. The installer runs only in USB temporary mode.", "ja": "このシステムはすでにディスクにインストールされています。インストーラーは USB の一時モードでのみ使えます。", "zh": "此系统已安装在硬盘上。安装程序只能在 USB 临时模式下使用。", "fr": "Ce système est déjà installé sur un disque. L'installateur ne fonctionne qu'en mode temporaire USB.", "es": "Este sistema ya está instalado en un disco. El instalador solo funciona en el modo temporal USB."},
    "install_pw": {"ko": '설치 확인용 riceos 비밀번호 (로그인 비밀번호와 같음)', "en": 'riceos password to confirm the install (same as login)', "ja": 'インストール確認用の riceos パスワード（ログインと同じ）', "zh": '确认安装的 riceos 密码（与登录密码相同）', "fr": "Mot de passe riceos pour confirmer l'installation (identique à la connexion)", "es": 'Contraseña de riceos para confirmar la instalación (la misma del inicio de sesión)'},
    "install_wrong_pw": {"ko": '비밀번호가 맞지 않습니다. 설치를 시작하지 않았습니다', "en": 'Wrong password. The install was not started', "ja": 'パスワードが違います。インストールは開始していません', "zh": '密码错误，未开始安装', "fr": "Mot de passe incorrect. L'installation n'a pas été lancée", "es": 'Contraseña incorrecta. La instalación no se ha iniciado'},
    "install_warn": {"ko": "선택한 디스크의 모든 자료가 지워지고 RICEOS가 설치됩니다.", "en": "All data on the selected disk will be erased and RICEOS will be installed.", "ja": "選んだディスクのデータはすべて消去され、RICEOS がインストールされます。", "zh": "选定磁盘上的所有数据都将被删除，并安装 RICEOS。", "fr": "Toutes les données du disque sélectionné seront effacées et RICEOS sera installé.", "es": "Se borrarán todos los datos del disco seleccionado y se instalará RICEOS."},
    "install_pick": {"ko": "설치할 디스크", "en": "Disk to install on", "ja": "インストール先のディスク", "zh": "安装到的磁盘", "fr": "Disque d'installation", "es": "Disco de instalación"},
    "install_type_name": {"ko": "확인을 위해 디스크 이름 {name} 을(를) 입력하세요", "en": "Type the disk name {name} to confirm", "ja": "確認のためディスク名 {name} を入力してください", "zh": "请输入磁盘名 {name} 以确认", "fr": "Saisissez le nom du disque {name} pour confirmer", "es": "Escriba el nombre del disco {name} para confirmar"},
    "install_go": {"ko": "디스크 지우고 설치", "en": "Erase disk and install", "ja": "ディスクを消去してインストール", "zh": "清空磁盘并安装", "fr": "Effacer le disque et installer", "es": "Borrar disco e instalar"},
    "install_running": {"ko": "설치하는 중... (끄지 마세요)", "en": "Installing... (do not turn off the computer)", "ja": "インストール中...（電源を切らないでください）", "zh": "正在安装...（请勿关机）", "fr": "Installation en cours... (ne l'éteignez pas)", "es": "Instalando... (no apague el equipo)"},
    "install_done": {"ko": "설치가 끝났습니다. USB를 빼고 다시 시작하세요.", "en": "Installation complete. Remove the USB drive and restart.", "ja": "インストールが完了しました。USB を抜いて再起動してください。", "zh": "安装完成。请拔出 USB 并重新启动。", "fr": "Installation terminée. Retirez la clé USB et redémarrez.", "es": "Instalación completada. Retire la memoria USB y reinicie."},
    "install_failed": {"ko": "설치하지 못했습니다", "en": "Installation failed", "ja": "インストールに失敗しました", "zh": "安装失败", "fr": "L'installation a échoué", "es": "La instalación falló"},
    "install_list_fail": {"ko": "디스크 목록을 가져오지 못했습니다", "en": "Could not list the disks", "ja": "ディスクの一覧を取得できませんでした", "zh": "无法获取磁盘列表", "fr": "Impossible de lister les disques", "es": "No se pudo listar los discos"},
    "install_no_disks": {"ko": "설치할 수 있는 디스크가 없습니다", "en": "No disks available for installation", "ja": "インストールできるディスクがありません", "zh": "没有可用于安装的磁盘", "fr": "Aucun disque disponible pour l'installation", "es": "No hay discos disponibles para instalar"},
    "step_partition": {"ko": "디스크 나누는 중 (파티션)", "en": "Creating partitions", "ja": "パーティションを作成中", "zh": "正在创建分区", "fr": "Création des partitions", "es": "Creando particiones"},
    "step_format": {"ko": "포맷하는 중", "en": "Formatting", "ja": "フォーマット中", "zh": "正在格式化", "fr": "Formatage", "es": "Formateando"},
    "step_copy": {"ko": "시스템 파일을 복사하는 중 (몇 분 걸립니다)", "en": "Copying system files (this takes a few minutes)", "ja": "システムファイルをコピー中（数分かかります）", "zh": "正在复制系统文件（需要几分钟）", "fr": "Copie des fichiers système (quelques minutes)", "es": "Copiando archivos del sistema (unos minutos)"},
    "step_config": {"ko": "설정하는 중", "en": "Configuring", "ja": "設定中", "zh": "正在配置", "fr": "Configuration", "es": "Configurando"},
    "step_bootloader": {"ko": "부트로더 설치 중", "en": "Installing the bootloader", "ja": "ブートローダーをインストール中", "zh": "正在安装引导程序", "fr": "Installation du chargeur de démarrage", "es": "Instalando el cargador de arranque"},
    "step_finish": {"ko": "마무리하는 중", "en": "Finishing", "ja": "仕上げ中", "zh": "正在收尾", "fr": "Finalisation", "es": "Finalizando"},
    "err_BAD_DISK": {"ko": "디스크 이름이 올바르지 않습니다", "en": "Invalid disk name", "ja": "ディスク名が正しくありません", "zh": "磁盘名称无效", "fr": "Nom de disque invalide", "es": "Nombre de disco no válido"},
    "err_CONFIRM_MISMATCH": {"ko": "입력한 디스크 이름이 맞지 않습니다", "en": "The disk name you typed does not match", "ja": "入力したディスク名が一致しません", "zh": "输入的磁盘名不一致", "fr": "Le nom saisi ne correspond pas", "es": "El nombre introducido no coincide"},
    "err_NO_DISK": {"ko": "디스크를 찾지 못했습니다", "en": "Disk not found", "ja": "ディスクが見つかりません", "zh": "找不到磁盘", "fr": "Disque introuvable", "es": "No se encontró el disco"},
    "err_NOT_ROOT": {"ko": "관리자 권한이 필요합니다", "en": "Administrator rights are required", "ja": "管理者権限が必要です", "zh": "需要管理员权限", "fr": "Droits administrateur requis", "es": "Se requieren derechos de administrador"},
    "err_NOT_LIVE": {"ko": "USB 임시 모드에서만 설치할 수 있습니다", "en": "Installation is only possible in USB temporary mode", "ja": "インストールは USB の一時モードでのみ可能です", "zh": "只能在 USB 临时模式下安装", "fr": "L'installation n'est possible qu'en mode temporaire USB", "es": "La instalación solo es posible en el modo temporal USB"},
    "err_IS_MEDIUM": {"ko": "지금 부팅한 USB에는 설치할 수 없습니다", "en": "Cannot install to the USB drive you booted from", "ja": "起動中の USB には設定できません", "zh": "无法安装到当前启动的 USB", "fr": "Impossible d'installer sur la clé USB de démarrage", "es": "No se puede instalar en la memoria USB de arranque"},
    "err_NO_SOURCE": {"ko": "설치 자료(filesystem.squashfs)를 찾지 못했습니다", "en": "Installation source (filesystem.squashfs) not found", "ja": "インストール元 (filesystem.squashfs) が見つかりません", "zh": "找不到安装源 (filesystem.squashfs)", "fr": "Source d'installation introuvable (filesystem.squashfs)", "es": "No se encontró el origen de instalación (filesystem.squashfs)"},
    "err_PARTITION": {"ko": "파티션을 만들지 못했습니다", "en": "Could not create partitions", "ja": "パーティションを作成できませんでした", "zh": "无法创建分区", "fr": "Impossible de créer les partitions", "es": "No se pudieron crear las particiones"},
    "err_FORMAT": {"ko": "포맷하지 못했습니다", "en": "Could not format the disk", "ja": "フォーマットできませんでした", "zh": "无法格式化", "fr": "Impossible de formater", "es": "No se pudo formatear"},
    "err_MOUNT": {"ko": "디스크를 연결하지 못했습니다", "en": "Could not mount the disk", "ja": "ディスクをマウントできませんでした", "zh": "无法挂载磁盘", "fr": "Impossible de monter le disque", "es": "No se pudo montar el disco"},
    "err_COPY": {"ko": "시스템 파일을 복사하지 못했습니다", "en": "Could not copy the system files", "ja": "システムファイルをコピーできませんでした", "zh": "无法复制系统文件", "fr": "Impossible de copier les fichiers système", "es": "No se pudieron copiar los archivos del sistema"},
    "err_NO_KERNEL": {"ko": "커널 파일이 없습니다", "en": "Kernel files are missing", "ja": "カーネルファイルがありません", "zh": "缺少内核文件", "fr": "Fichiers du noyau manquants", "es": "Faltan los archivos del kernel"},
    "err_BOOTLOADER": {"ko": "부트로더를 설치하지 못했습니다", "en": "Could not install the bootloader", "ja": "ブートローダーをインストールできませんでした", "zh": "无法安装引导程序", "fr": "Impossible d'installer le chargeur de démarrage", "es": "No se pudo instalar el cargador de arranque"},
}

_LANG = "ko"


def _pick_lang():
    """사용할 언어 코드를 고른다. 모르는 값은 무시하고 다음 방법을 쓴다."""
    env = os.environ.get("RICEOS_LANG", "").strip().lower()
    if env in LANGS:
        return env
    try:
        home = os.environ.get("HOME", "")
        with open(os.path.join(home, ".config", "riceos", "ui.json"), encoding="utf-8") as f:
            saved = json.load(f).get("lang", "")
        if saved in LANGS:
            return saved
    except (OSError, ValueError, AttributeError):
        pass
    for var in ("LC_ALL", "LC_MESSAGES", "LANG", "LANGUAGE"):
        value = os.environ.get(var, "").lower()
        prefix = value[:2]
        if prefix in LANGS:
            return prefix
    return "ko"


def set_lang(code):
    global _LANG
    if code in LANGS:
        _LANG = code


def t(key, **values):
    """현재 언어의 문장을 돌려준다. 없는 언어면 한국어, 없는 키면 키 이름을 쓴다."""
    table = STRINGS.get(key)
    if table is None:
        return key
    text = table.get(_LANG) or table.get("ko") or key
    return text.format(**values) if values else text


def save_lang(code):
    """언어 선택을 ~/.config/riceos/ui.json 에 저장한다. 성공하면 True."""
    if code not in LANGS:
        return False
    try:
        d = os.path.join(os.environ.get("HOME", ""), ".config", "riceos")
        os.makedirs(d, exist_ok=True)
        path = os.path.join(d, "ui.json")
        with open(path, "w", encoding="utf-8") as f:
            json.dump({"lang": code}, f, ensure_ascii=False)
        return True
    except OSError:
        return False


# ---------------------------------------------------------------------------
# 시스템 도구 호출과 결과 해석 (화면과 무관한 부분)
# ---------------------------------------------------------------------------

def run(cmd, timeout=20, stdin_text=None):
    """명령을 실행하고 (종료 코드, 출력 글자)를 돌려준다. 실패해도 예외를 던지지 않는다.
    출력은 UTF-8 로 읽는다. 깨진 바이트는 '?' 대신 치환 문자로 바꿔 화면이 죽지 않게 한다.
    stdin_text 는 표준 입력으로 보낸다 (비밀번호처럼 명령줄에 남기면 안 되는 값에 쓴다)."""
    try:
        p = subprocess.run(cmd, input=stdin_text, stdout=subprocess.PIPE,
                           stderr=subprocess.STDOUT, encoding="utf-8", errors="replace",
                           timeout=timeout)
        return p.returncode, p.stdout.strip()
    except FileNotFoundError:
        return 127, t("no_program", name=cmd[0])
    except subprocess.TimeoutExpired:
        return 124, t("timeout")
    except Exception as e:  # noqa: BLE001 - 화면이 죽지 않게 모두 글자로 바꾼다
        return 1, str(e)


def launch(cmd):
    """다른 프로그램을 따로 띄운다. 실패하면 이유를 글자로 돌려준다 (성공하면 None)."""
    try:
        subprocess.Popen(cmd, start_new_session=True,
                         stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        return None
    except FileNotFoundError:
        return t("not_installed", name=cmd[0])
    except Exception as e:  # noqa: BLE001
        return str(e)


def split_terse(line):
    """nmcli -t 출력 한 줄을 ':' 로 나눈다. 값 안의 '\\:' 는 ':' 글자로 본다."""
    parts, cur, i = [], [], 0
    while i < len(line):
        c = line[i]
        if c == "\\" and i + 1 < len(line):
            cur.append(line[i + 1])
            i += 2
            continue
        if c == ":":
            parts.append("".join(cur))
            cur = []
        else:
            cur.append(c)
        i += 1
    parts.append("".join(cur))
    return parts


def wifi_error_text(out):
    """nmcli 의 영어 오류 문장을 화면용 번역 문장으로 바꾼다. 영어 원문은 화면에 보이지 않는다."""
    low = (out or "").lower()
    if "not authorized" in low or "permission" in low:
        key = "wifi_err_perm"
    elif any(w in low for w in ("secret", "auth", "password", "802-1x")):
        key = "wifi_err_auth"
    elif "timed out" in low or "timeout" in low:
        key = "wifi_err_timeout"
    elif "no network with ssid" in low or "not found" in low:
        key = "wifi_err_notfound"
    elif "not available" in low or "unavailable" in low:
        key = "wifi_err_device"
    else:
        key = "wifi_err_generic"
    if out:
        sys.stderr.write("[wifi] %s\n" % out.strip())
    return t(key)


def parse_wifi(out):
    """nmcli -t -f IN-USE,SIGNAL,SECURITY,SSID device wifi list 결과를 해석한다."""
    nets, seen = [], set()
    for line in out.splitlines():
        f = split_terse(line)
        if len(f) < 4 or not f[3]:
            continue
        ssid = f[3]
        if ssid in seen:
            continue
        seen.add(ssid)
        try:
            sig = int(f[1])
        except ValueError:
            sig = 0
        # nmcli 는 암호화가 없는 네트워크의 보안 값을 '--' 로 준다
        security = f[2] if f[2] not in ("", "--") else "open"
        nets.append({"in_use": f[0].strip() == "*", "signal": sig,
                     "security": security, "ssid": ssid})
    nets.sort(key=lambda n: (not n["in_use"], -n["signal"]))
    return nets


def parse_devices(out):
    """nmcli -t -f DEVICE,TYPE,STATE,CONNECTION device status 결과를 줄 글자로 만든다."""
    rows = []
    for line in out.splitlines():
        f = split_terse(line)
        if len(f) >= 3 and f[1] in ("wifi", "ethernet"):
            kind = t("kind_wifi") if f[1] == "wifi" else t("kind_wired")
            rows.append("%s %s: %s %s" % (kind, f[0], f[2], f[3] if len(f) > 3 and f[3] != "--" else ""))
    return "\n".join(r.strip() for r in rows) if rows else t("net_none")


def parse_volume(out):
    """wpctl get-volume 결과 'Volume: 0.40 [MUTED]' 를 (0~100 정수, 음소거 여부)로 바꾼다."""
    m = re.search(r"Volume:\s*([0-9.]+)", out)
    if not m:
        return None
    return int(round(float(m.group(1)) * 100)), "[MUTED]" in out


def parse_xrandr(out):
    """xrandr --query 에서 연결된 모니터를 (이름, 주 모니터 여부, 해상도, 주사율) 목록으로 돌려준다.
    해상도를 모르면 mode 는 빈 문자열이다 (화면에서 '꺼짐'으로 보여 준다)."""
    mons, cur = [], None
    for line in out.splitlines():
        m = re.match(r"^(\S+) connected( primary)?\s*(\d+x\d+)?", line)
        if m:
            cur = {"name": m.group(1), "primary": bool(m.group(2)),
                   "mode": m.group(3) or "", "rate": ""}
            mons.append(cur)
            continue
        if re.match(r"^\S+ disconnected", line):
            cur = None
            continue
        if cur is not None and cur["rate"] == "":
            mm = re.match(r"^\s+(\d+x\d+)\s+(.*)$", line)
            if mm and mm.group(1) == cur["mode"]:
                r = re.search(r"([0-9.]+)\*", mm.group(2))
                if r:
                    cur["rate"] = r.group(1) + " Hz"
    return mons


def parse_xrandr_full(out):
    """xrandr --query 를 모니터 목록으로 바꾼다.
    각 모니터: name, primary, modes=[(해상도, [주사율...])], cur_res, cur_rate, pref_res, pref_rate."""
    mons, cur = [], None
    for line in out.splitlines():
        m = re.match(r"^(\S+) connected( primary)?\s*(\d+x\d+)?", line)
        if m:
            g = re.search(r"(\d+)x(\d+)\+(-?\d+)\+(-?\d+)", line)
            cur = {"name": m.group(1), "primary": bool(m.group(2)), "modes": [],
                   "cur_res": m.group(3) or "", "cur_rate": "",
                   "pref_res": "", "pref_rate": "",
                   "geo": tuple(int(v) for v in g.groups()) if g else None}
            mons.append(cur)
            continue
        if re.match(r"^\S+ disconnected", line) or line.startswith("Screen"):
            cur = None
            continue
        mm = re.match(r"^\s+(\d+x\d+)\s+(.*)$", line)
        if cur is None or not mm:
            continue
        res, rates = mm.group(1), []
        for tok in mm.group(2).split():
            r = re.match(r"^([0-9.]+)([*+]*)$", tok)
            if not r:
                continue
            rates.append(r.group(1))
            if "*" in r.group(2) and not cur["cur_rate"]:
                cur["cur_res"], cur["cur_rate"] = res, r.group(1)
            if "+" in r.group(2) and not cur["pref_rate"]:
                cur["pref_res"], cur["pref_rate"] = res, r.group(1)
        cur["modes"].append((res, rates))
    return mons


def _wh(res):
    w, h = res.split("x")
    return int(w), int(h)


def plan_positions(settings):
    """settings: [{name, res, anchor, side}] 순서대로. 첫 모니터는 (0,0).
    anchor 모니터 기준으로 side(left/right/above/below) 에 붙인다. 기준을 못 찾으면 앞 모니터 오른쪽.
    음수 좌표는 모두 0 이상으로 옮긴다."""
    size = {}
    pos = {}
    for i, s_ in enumerate(settings):
        size[s_["name"]] = _wh(s_["res"])
        if i == 0:
            pos[s_["name"]] = (0, 0)
            continue
        anchor = s_.get("anchor")
        if anchor not in pos:
            prev = settings[i - 1]["name"]
            pos[s_["name"]] = (pos[prev][0] + size[prev][0], pos[prev][1])
            continue
        ax, ay = pos[anchor]
        aw, ah = size[anchor]
        w, h = size[s_["name"]]
        side = s_.get("side", "right")
        if side == "left":
            pos[s_["name"]] = (ax - w, ay)
        elif side == "above":
            pos[s_["name"]] = (ax, ay - h)
        elif side == "below":
            pos[s_["name"]] = (ax, ay + ah)
        else:
            pos[s_["name"]] = (ax + aw, ay)
    mx = min(p[0] for p in pos.values())
    my = min(p[1] for p in pos.values())
    return {k: (x - mx, y - my) for k, (x, y) in pos.items()}


def build_xrandr_args(settings, mode):
    """mode: 'extend'(확장) 또는 'clone'(복제). 결과는 xrandr 인자 목록이다."""
    args = []
    if mode == "clone":
        main_name = settings[0]["name"]
        for i, s in enumerate(settings):
            a = ["--output", s["name"], "--mode", s["res"], "--rate", s["rate"]]
            if i == 0:
                a += ["--primary", "--pos", "0x0"]
            else:
                a += ["--same-as", main_name]
            args += a
        return args
    positions = plan_positions(settings)
    for i, s in enumerate(settings):
        x, y = positions[s["name"]]
        a = ["--output", s["name"], "--mode", s["res"], "--rate", s["rate"],
             "--pos", "%dx%d" % (x, y)]
        if i == 0:
            a += ["--primary"]
        args += a
    return args


def rates_for(mon, res):
    for r, rates in mon["modes"]:
        if r == res:
            return rates
    return []


def system_info():
    """시스템 정보는 riceos-sysinfo (리눅스 도구 모음)가 모으고, 여기서는 결과를 보여 주기만 한다.
    riceos-sysinfo 에는 현재 언어를 RICEOS_LANG 으로 넘긴다."""
    rc, out = _sysinfo_run()
    return out if rc == 0 else t("sysinfo_fail")


def _sysinfo_run():
    env = dict(os.environ, RICEOS_LANG=_LANG)
    try:
        p = subprocess.run(["riceos-sysinfo"], env=env, stdout=subprocess.PIPE,
                           stderr=subprocess.STDOUT, encoding="utf-8", errors="replace",
                           timeout=30)
        return p.returncode, p.stdout.strip()
    except (OSError, subprocess.SubprocessError):
        return 1, ""


AUTH = ["sudo", "-n", "/usr/local/sbin/riceos-auth"]  # 로그인 비밀번호 저장과 확인은 root 헬퍼가 한다
INSTALL_BIN = "/usr/local/sbin/riceos-install"        # 하드디스크 설치 (목록은 누구나, 설치는 sudo 로)


def is_live():
    """USB 임시 모드로 부팅했는지 (커널 명령줄에 boot=live)."""
    try:
        with open("/proc/cmdline", encoding="utf-8", errors="replace") as f:
            return "boot=live" in f.read().split()
    except OSError:
        return False


def human_size(n):
    try:
        n = float(n)
    except (TypeError, ValueError):
        return "?"
    for unit in ("B", "KB", "MB", "GB"):
        if n < 1000 or unit == "GB":
            return ("%.0f %s" % (n, unit)) if unit in ("B",) else ("%.1f %s" % (n, unit))
        n /= 1000.0
    return "%.1f TB" % n


def auth_state():
    """('none', '') 설정 전, ('set', '') 설정 있음, ('error', 이유) 확인할 수 없음."""
    rc, out = run(AUTH + ["status"])
    if rc == 0:
        return "set", ""
    if rc == 1:
        return "none", ""
    return "error", out


def auth_check(pw):
    """맞으면 (True, ''), 틀리면 (False, '')."""
    rc, out = run(AUTH + ["check"], stdin_text=pw + "\n")
    return rc == 0, ("" if rc in (0, 1) else out)


def auth_set(pw):
    """새 비밀번호를 저장한다. 성공하면 (True, 이유)."""
    rc, out = run(AUTH + ["set"], stdin_text=pw + "\n")
    return rc == 0, out


# ---- GUI ----
# 아래부터는 GTK 4 로 화면만 그린다.

import gi  # noqa: E402

gi.require_version("Gtk", "4.0")
from gi.repository import Gio, GLib, Gtk, Pango  # noqa: E402


def run_stream(cmd, on_line, on_end, stdin_text=None):
    """명령을 실행하면서 출력 한 줄마다 on_line(줄)을, 끝나면 on_end(종료 코드)를 화면 쪽에서 부른다.
    stdin_text 가 있으면 표준 입력으로 넘긴다 (sudo -S 의 비밀번호)."""
    def work():
        try:
            p = subprocess.Popen(cmd, stdin=subprocess.PIPE if stdin_text is not None else None,
                                 stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                                 encoding="utf-8", errors="replace")
            if stdin_text is not None:
                try:
                    p.stdin.write(stdin_text + "\n")
                    p.stdin.close()
                except OSError:
                    pass
            for line in p.stdout:
                GLib.idle_add(on_line, line.strip())
            rc = p.wait()
        except OSError as e:
            GLib.idle_add(on_line, "ERROR %s" % e)
            rc = 1
        GLib.idle_add(on_end, rc)
    threading.Thread(target=work, daemon=True).start()


def run_bg(cmd, done, timeout=20):
    """명령을 따로 실행하고 끝나면 화면 쪽에서 done(코드, 출력)을 부른다 (화면이 멈추지 않는다)."""
    def work():
        rc, out = run(cmd, timeout)
        GLib.idle_add(done, rc, out)
    threading.Thread(target=work, daemon=True).start()


def clear(box):
    child = box.get_first_child()
    while child is not None:
        nxt = child.get_next_sibling()
        box.remove(child)
        child = nxt


def title_label(text):
    lab = Gtk.Label(label=text, xalign=0)
    lab.add_css_class("title-2")
    return lab


def page_box():
    box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
    for side in ("top", "bottom", "start", "end"):
        getattr(box, "set_margin_" + side)(16)
    return box


class NetworkPage(Gtk.Box):
    def __init__(self, notify):
        super().__init__(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        self.notify = notify
        for side in ("top", "bottom", "start", "end"):
            getattr(self, "set_margin_" + side)(16)
        self.append(title_label(t("nav_network")))
        self.status = Gtk.Label(label="", xalign=0)
        self.append(self.status)

        row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        row.append(Gtk.Label(label=t("wifi_on")))
        self.radio = Gtk.Switch()
        self.radio.connect("state-set", self.on_radio)
        row.append(self.radio)
        refresh = Gtk.Button(label=t("refresh"))
        refresh.connect("clicked", lambda _b: self.refresh())
        row.append(refresh)
        self.append(row)

        self.listbox = Gtk.ListBox()
        self.listbox.set_selection_mode(Gtk.SelectionMode.NONE)
        self.listbox.connect("row-activated", self.on_row)
        scroll = Gtk.ScrolledWindow()
        scroll.set_vexpand(True)
        scroll.set_child(self.listbox)
        self.append(scroll)
        self.loading = False
        self.refresh()

    def refresh(self):
        self.notify(t("net_checking"))
        run_bg(["nmcli", "-t", "-f", "DEVICE,TYPE,STATE,CONNECTION", "device", "status"],
               self.on_devices)
        run_bg(["nmcli", "radio", "wifi"], self.on_radio_state)
        run_bg(["nmcli", "-t", "-f", "IN-USE,SIGNAL,SECURITY,SSID", "device", "wifi", "list",
                "--rescan", "auto"], self.on_wifi, timeout=30)

    def on_devices(self, rc, out):
        self.status.set_text(parse_devices(out) if rc == 0 else out)

    def on_radio_state(self, rc, out):
        self.loading = True
        self.radio.set_active(rc == 0 and out.strip() == "enabled")
        self.loading = False

    def on_wifi(self, rc, out):
        clear(self.listbox)
        if rc != 0:
            self.listbox.append(Gtk.Label(label=out or t("wifi_list_fail"), xalign=0))
            self.notify("")
            return
        nets = parse_wifi(out)
        if not nets:
            self.listbox.append(Gtk.Label(label=t("wifi_none"), xalign=0))
        for n in nets:
            security = t("open") if n["security"] == "open" else n["security"]
            text = "%s%s    %s %d%%    %s" % ("● " if n["in_use"] else "", n["ssid"],
                                             t("signal"), n["signal"], security)
            lab = Gtk.Label(label=text, xalign=0)
            lab.set_margin_top(6)
            lab.set_margin_bottom(6)
            row = Gtk.ListBoxRow()
            row.set_child(lab)
            row.ssid = n["ssid"]
            row.secured = n["security"] != "open"
            self.listbox.append(row)
        self.notify("")

    def on_radio(self, _switch, state):
        if self.loading:
            return False
        run_bg(["nmcli", "radio", "wifi", "on" if state else "off"],
               lambda rc, out: self.refresh())
        return False

    def on_row(self, _lb, row):
        ssid = getattr(row, "ssid", None)
        if ssid is None:
            return
        if getattr(row, "secured", True):
            self.ask_password(ssid)
        else:
            self.connect_to(ssid, "")

    def ask_password(self, ssid):
        win = Gtk.Window(title=t("connect_title", ssid=ssid), modal=True)
        win.set_transient_for(self.get_root())
        win.set_default_size(360, -1)
        box = page_box()
        box.append(Gtk.Label(label=t("ask_password", ssid=ssid), xalign=0))
        entry = Gtk.PasswordEntry()
        entry.set_show_peek_icon(True)
        box.append(entry)
        btn = Gtk.Button(label=t("connect"))

        def go(*_a):
            pw = entry.get_text()
            win.close()
            self.connect_to(ssid, pw)
        btn.connect("clicked", go)
        entry.connect("activate", go)
        box.append(btn)
        win.set_child(box)
        win.present()

    def connect_to(self, ssid, pw):
        cmd = ["nmcli", "device", "wifi", "connect", ssid]
        if pw:
            cmd += ["password", pw]
        self.notify(t("connecting", ssid=ssid))

        def done(rc, out):
            if rc == 0:
                self.notify("%s: %s" % (t("connected"), out))
            else:
                self.notify("%s: %s" % (t("connect_fail"), wifi_error_text(out)))
            self.refresh()
        run_bg(cmd, done, timeout=60)


class SoundPage(Gtk.Box):
    def __init__(self, notify):
        super().__init__(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        self.notify = notify
        for side in ("top", "bottom", "start", "end"):
            getattr(self, "set_margin_" + side)(16)
        self.append(title_label(t("nav_sound")))
        self.info = Gtk.Label(label="", xalign=0)
        self.append(self.info)
        self.scale = Gtk.Scale.new_with_range(Gtk.Orientation.HORIZONTAL, 0, 100, 1)
        self.scale.set_hexpand(True)
        self.scale.set_draw_value(True)
        self.scale.connect("value-changed", self.on_scale)
        self.append(self.scale)
        self.mute = Gtk.ToggleButton(label=t("mute"))
        self.mute.connect("toggled", self.on_mute)
        self.append(self.mute)
        adv = Gtk.Button(label=t("adv_sound"))
        adv.connect("clicked", lambda _b: self.notify(launch(["pavucontrol"]) or ""))
        self.append(adv)
        self.loading = False
        self.pending = None
        self.refresh()

    def refresh(self):
        run_bg(["wpctl", "get-volume", "@DEFAULT_AUDIO_SINK@"], self.on_volume)

    def on_volume(self, rc, out):
        v = parse_volume(out) if rc == 0 else None
        self.loading = True
        if v is None:
            self.info.set_text("%s: %s" % (t("sound_no_server"), out))
            self.scale.set_sensitive(False)
        else:
            self.info.set_text("")
            self.scale.set_sensitive(True)
            self.scale.set_value(v[0])
            self.mute.set_active(v[1])
        self.loading = False

    def on_scale(self, scale):
        if self.loading:
            return
        self.pending = int(scale.get_value())
        GLib.timeout_add(150, self.apply_volume)  # 끌어서 바꾸는 동안 명령이 쏟아지지 않게 모아서 보낸다

    def apply_volume(self):
        if self.pending is not None:
            val, self.pending = self.pending, None
            run_bg(["wpctl", "set-volume", "@DEFAULT_AUDIO_SINK@", "%.2f" % (val / 100.0)],
                   lambda rc, out: None)
        return False

    def on_mute(self, btn):
        if self.loading:
            return
        run_bg(["wpctl", "set-mute", "@DEFAULT_AUDIO_SINK@", "1" if btn.get_active() else "0"],
               lambda rc, out: None)


class DisplayPage(Gtk.Box):
    """모니터마다 해상도와 주사율을 고르고, 복제/확장과 왼쪽·오른쪽 배치를 정한다.
    적용하면 xrandr 를 실행하고, 같은 설정을 ~/.screenlayout/riceos.sh 에 남겨 다음 세션에도 쓴다."""

    SIDES = [("right", "disp_side_right"), ("left", "disp_side_left"),
             ("below", "disp_side_below"), ("above", "disp_side_above")]

    def __init__(self, notify):
        super().__init__(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        self.notify = notify
        self.mons = []
        self.rows = []
        for side in ("top", "bottom", "start", "end"):
            getattr(self, "set_margin_" + side)(16)
        self.append(title_label(t("nav_display")))
        mode_line = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        mode_line.append(Gtk.Label(label=t("disp_mode"), xalign=0))
        self.mode = Gtk.ComboBoxText()
        self.mode.append("extend", t("disp_extend"))
        self.mode.append("clone", t("disp_clone"))
        self.mode.set_active_id("extend")
        self.mode.connect("changed", lambda _c: self.update_sensitivity())
        mode_line.append(self.mode)
        self.append(mode_line)
        self.mon_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=12)
        scroll = Gtk.ScrolledWindow()
        scroll.set_vexpand(True)
        scroll.set_child(self.mon_box)
        self.append(scroll)
        self.status = Gtk.Label(label="", xalign=0)
        self.status.set_selectable(True)
        self.append(self.status)
        buttons = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        refresh = Gtk.Button(label=t("refresh"))
        refresh.connect("clicked", lambda _b: self.refresh())
        identify_btn = Gtk.Button(label=t("disp_identify"))
        identify_btn.connect("clicked", lambda _b: self.identify())
        apply_btn = Gtk.Button(label=t("disp_apply"))
        apply_btn.connect("clicked", lambda _b: self.apply())
        buttons.append(refresh)
        buttons.append(identify_btn)
        buttons.append(apply_btn)
        self.append(buttons)
        self.refresh()

    def refresh(self):
        run_bg(["xrandr", "--query"], self.on_result)

    def on_result(self, rc, out):
        clear(self.mon_box)
        self.rows = []
        if rc != 0:
            self.mon_box.append(Gtk.Label(label=out or t("monitor_none"), xalign=0))
            return
        self.mons = parse_xrandr_full(out)
        if not self.mons:
            self.mon_box.append(Gtk.Label(label=t("monitor_none"), xalign=0))
            return
        for i, m in enumerate(self.mons):
            box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
            head = m["name"] + (t("primary_tag") if i == 0 else "")
            box.append(Gtk.Label(label=head, xalign=0))
            res_c = Gtk.ComboBoxText()
            for res, _rates in m["modes"]:
                res_c.append(res, res)
            rate_c = Gtk.ComboBoxText()
            res_c.set_active_id(m["pref_res"] or m["cur_res"] or (m["modes"][0][0] if m["modes"] else ""))
            line = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
            line.append(Gtk.Label(label=t("disp_resolution"), xalign=0))
            line.append(res_c)
            line.append(Gtk.Label(label=t("disp_rate"), xalign=0))
            line.append(rate_c)
            box.append(line)
            row = {"mon": m, "res": res_c, "rate": rate_c, "anchor": None, "side": None, "box": box}
            res_c.connect("changed", lambda _c, r=row: self.fill_rates(r))
            self.fill_rates(row)
            if i > 0:
                pos_line = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
                pos_line.append(Gtk.Label(label=t("disp_position"), xalign=0))
                anchor = Gtk.ComboBoxText()
                for other in self.mons[:i]:
                    anchor.append(other["name"], other["name"])
                anchor.set_active_id(self.mons[i - 1]["name"])
                side = Gtk.ComboBoxText()
                for sid, key in self.SIDES:
                    side.append(sid, t(key))
                side.set_active_id("right")
                pos_line.append(anchor)
                pos_line.append(side)
                box.append(pos_line)
                row["anchor"], row["side"] = anchor, side
            self.mon_box.append(box)
            self.rows.append(row)
        self.update_sensitivity()
        self.status.set_text("")

    def name_for_geometry(self, x, y, w, h, index):
        """GDK 모니터(위치, 크기)를 xrandr 이름(HDMI-1 등)과 맞춘다. 못 찾으면 번호만."""
        for m in self.mons:
            g = m.get("geo")
            if g and g == (w, h, x, y):
                return m["name"]
        return "#%d" % (index + 1)

    def identify(self):
        """연결된 모니터마다 번호와 이름을 4초 동안 크게 띄운다."""
        from gi.repository import Gdk
        display = Gdk.Display.get_default()
        if display is None:
            return
        self.id_wins = []
        monitors = display.get_monitors()
        for i in range(monitors.get_n_items()):
            gm = monitors.get_item(i)
            geo = gm.get_geometry()
            name = self.name_for_geometry(geo.x, geo.y, geo.width, geo.height, i)
            text = t("disp_monitor_label", n=i + 1, name=name)
            win = Gtk.Window(title="RICEOS")
            win.set_decorated(False)
            lab = Gtk.Label(label="")
            lab.set_markup('<span size="60000" weight="bold">%s</span>' % GLib.markup_escape_text(text))
            lab.set_margin_top(40)
            lab.set_margin_bottom(40)
            lab.set_margin_start(40)
            lab.set_margin_end(40)
            win.set_child(lab)
            if hasattr(win, "fullscreen_on_monitor"):
                win.fullscreen_on_monitor(gm)
            else:
                win.fullscreen()
            win.present()
            self.id_wins.append(win)
        GLib.timeout_add_seconds(4, self.close_identify)

    def close_identify(self):
        for w in getattr(self, "id_wins", []):
            w.close()
        self.id_wins = []
        return False

    def fill_rates(self, row):
        rate_c = row["rate"]
        rate_c.remove_all()
        res = row["res"].get_active_id() or ""
        rates = rates_for(row["mon"], res)
        for r in rates:
            rate_c.append(r, r + " Hz")
        want = row["mon"]["pref_rate"] if row["mon"]["pref_res"] == res else ""
        if want not in rates:
            want = rates[0] if rates else ""
        rate_c.set_active_id(want)

    def update_sensitivity(self):
        clone = self.mode.get_active_id() == "clone"
        for i, row in enumerate(self.rows):
            if row["anchor"] is not None:
                row["anchor"].set_sensitive(not clone)
                row["side"].set_sensitive(not clone)

    def collect(self):
        """화면에서 고른 값을 설정 목록으로 만든다. 모니터가 없으면 빈 목록."""
        settings = []
        for i, row in enumerate(self.rows):
            res = row["res"].get_active_id() or ""
            rate = row["rate"].get_active_id() or ""
            if not res or not rate:
                return None
            s = {"name": row["mon"]["name"], "res": res, "rate": rate}
            if row["anchor"] is not None:
                s["anchor"] = row["anchor"].get_active_id()
                s["side"] = row["side"].get_active_id() or "right"
            settings.append(s)
        return settings

    def apply(self):
        settings = self.collect()
        if not settings:
            self.status.set_text(t("disp_apply_fail"))
            return
        mode = self.mode.get_active_id() or "extend"
        args = build_xrandr_args(settings, mode)
        self.status.set_text(t("disp_applying"))

        def done(rc, out):
            if rc != 0:
                self.status.set_text("%s: %s" % (t("disp_apply_fail"), out))
                return
            self.status.set_text(t("disp_applied"))
            save_layout(args)
            self.refresh()
        run_bg(["xrandr"] + args, done, timeout=30)


def save_layout(args):
    """적용한 xrandr 명령을 ~/.screenlayout/riceos.sh 에 남긴다. 세션 시작 때 이 파일을 먼저 쓴다."""
    try:
        folder = os.path.expanduser("~/.screenlayout")
        os.makedirs(folder, exist_ok=True)
        path = os.path.join(folder, "riceos.sh")
        line = "xrandr " + " ".join(shlex.quote(a) for a in args)
        with open(path, "w", encoding="utf-8") as f:
            f.write("#!/bin/sh\n# RICEOS 디스플레이 설정 (화면에서 저장)\n" + line + "\n")
        os.chmod(path, 0o755)
    except OSError:
        pass


class PrinterPage(Gtk.Box):
    def __init__(self, notify):
        super().__init__(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        self.notify = notify
        for side in ("top", "bottom", "start", "end"):
            getattr(self, "set_margin_" + side)(16)
        self.append(title_label(t("nav_printer")))
        self.info = Gtk.Label(label="", xalign=0)
        self.info.set_selectable(True)
        self.append(self.info)
        add = Gtk.Button(label=t("printer_manage"))
        add.connect("clicked", lambda _b: self.notify(launch(["system-config-printer"]) or ""))
        self.append(add)
        run_bg(["lpstat", "-p", "-d"], self.on_result)

    def on_result(self, rc, out):
        self.info.set_text(out if out else t("printer_none"))


class PersonalPage(Gtk.Box):
    def __init__(self, notify):
        super().__init__(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        self.notify = notify
        for side in ("top", "bottom", "start", "end"):
            getattr(self, "set_margin_" + side)(16)
        self.append(title_label(t("nav_personal")))
        for key, cmd in (("theme_btn", ["lxappearance"]),
                         ("wallpaper_btn", ["pcmanfm", "--desktop-pref"]),
                         ("files_btn", ["pcmanfm"])):
            b = Gtk.Button(label=t(key))
            b.connect("clicked", lambda _b, c=cmd: self.notify(launch(c) or ""))
            self.append(b)

        self.append(title_label(t("lang_label")))
        self.lang_box = Gtk.ComboBoxText()
        for code in LANGS:
            self.lang_box.append(code, LANG_NAMES[code])
        self.lang_box.set_active_id(_LANG)
        self.append(self.lang_box)
        save_lang_btn = Gtk.Button(label=t("lang_save"))
        save_lang_btn.connect("clicked", lambda _b: self.save_language())
        self.append(save_lang_btn)

        self.append(title_label(t("pw_section")))
        self.cur = self.pw_row(t("cur_pw"))
        self.new = self.pw_row(t("new_pw"))
        self.new2 = self.pw_row(t("new_pw2"))
        save = Gtk.Button(label=t("pw_change_btn"))
        save.connect("clicked", lambda _b: self.change_password())
        self.append(save)

    def save_language(self):
        code = self.lang_box.get_active_id() or _LANG
        if save_lang(code):
            self.notify(t("lang_saved"))
        else:
            self.notify(t("lang_save_fail"))

    def pw_row(self, text):
        self.append(Gtk.Label(label=text, xalign=0))
        entry = Gtk.PasswordEntry()
        self.append(entry)
        return entry

    def change_password(self):
        cur, new, new2 = self.cur.get_text(), self.new.get_text(), self.new2.get_text()
        if not new or "\n" in new:
            self.notify(t("pw_empty"))
            return
        if new != new2:
            self.notify(t("pw_new_mismatch"))
            return
        self.notify(t("pw_changing"))

        def work():
            ok_cur, _ = auth_check(cur)
            if not ok_cur:
                return False, t("pw_cur_wrong")
            ok, _ = auth_set(new)
            return ok, (t("pw_changed") if ok else t("pw_change_fail"))

        def finish(ok, msg):
            self.notify(msg)
            if ok:
                for e in (self.cur, self.new, self.new2):
                    e.set_text("")
            return False
        threading.Thread(target=lambda: GLib.idle_add(finish, *work()), daemon=True).start()


class InstallPage(Gtk.Box):
    """하드디스크 설치. USB 임시 모드에서만 설치를 시작할 수 있다. 디스크 이름을 직접 입력해야 지운다."""

    def __init__(self, notify):
        super().__init__(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        self.notify = notify
        for side in ("top", "bottom", "start", "end"):
            getattr(self, "set_margin_" + side)(16)
        self.append(title_label(t("nav_install")))
        self.busy = False
        self.last_error = ""
        self.last_done = False
        if not is_live():
            self.append(Gtk.Label(label=t("install_not_live"), xalign=0, wrap=True))
            return
        self.append(Gtk.Label(label=t("install_warn"), xalign=0, wrap=True))
        self.append(Gtk.Label(label=t("install_pick"), xalign=0))
        row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        self.disk_box = Gtk.ComboBoxText()
        self.disk_box.connect("changed", lambda _c: self.on_pick())
        row.append(self.disk_box)
        refresh = Gtk.Button(label=t("refresh"))
        refresh.connect("clicked", lambda _b: self.load_disks())
        row.append(refresh)
        self.append(row)
        self.confirm_label = Gtk.Label(label="", xalign=0, wrap=True)
        self.append(self.confirm_label)
        self.entry = Gtk.Entry()
        self.entry.connect("changed", lambda _e: self.update_button())
        self.append(self.entry)
        self.append(Gtk.Label(label=t("install_pw"), xalign=0))
        self.pw = Gtk.PasswordEntry()
        self.pw.set_show_peek_icon(True)
        self.pw.connect("changed", lambda _e: self.update_button())
        self.append(self.pw)
        self.go = Gtk.Button(label=t("install_go"))
        self.go.add_css_class("destructive-action")
        self.go.connect("clicked", lambda _b: self.start_install())
        self.append(self.go)
        self.progress = Gtk.Label(label="", xalign=0, wrap=True)
        self.append(self.progress)
        self.load_disks()

    def load_disks(self):
        self.disk_box.remove_all()
        run_bg([INSTALL_BIN, "list"], self.on_disks)

    def on_disks(self, rc, out):
        self.disk_box.remove_all()
        if rc != 0:
            self.progress.set_text(t("install_list_fail"))
            return
        count = 0
        for line in out.splitlines():
            parts = line.split("|")
            if len(parts) < 3 or not parts[0]:
                continue
            name = parts[0]
            self.disk_box.append(name, "%s  %s  %s" % (name, human_size(parts[1]), parts[2]))
            count += 1
        if count:
            self.disk_box.set_active(0)
            self.progress.set_text("")
        else:
            self.progress.set_text(t("install_no_disks"))
        self.on_pick()

    def selected(self):
        return self.disk_box.get_active_id() or ""

    def on_pick(self):
        name = self.selected()
        self.confirm_label.set_text(t("install_type_name", name=name) if name else "")
        self.entry.set_text("")
        self.update_button()

    def update_button(self):
        name = self.selected()
        self.go.set_sensitive(bool(name) and self.entry.get_text() == name
                              and bool(self.pw.get_text()) and not self.busy)

    def start_install(self):
        name = self.selected()
        if not name or self.entry.get_text() != name:
            return
        pw = self.pw.get_text()
        ok, _err = auth_check(pw)
        if not ok:
            self.progress.set_text(t("install_wrong_pw"))
            return
        self.busy = True
        self.last_error = ""
        self.last_done = False
        self.entry.set_sensitive(False)
        self.pw.set_sensitive(False)
        self.disk_box.set_sensitive(False)
        self.update_button()
        self.progress.set_text(t("install_running"))
        # sudo -S: 표준 입력의 비밀번호로 설치 명령을 연다 (설치는 항상 비밀번호를 묻는다)
        run_stream(["sudo", "-S", "-p", "", INSTALL_BIN, "install", name, name],
                   self.on_line, self.on_end, stdin_text=pw)

    def on_line(self, line):
        if line.startswith("STEP "):
            key = "step_" + line[5:].strip()
            self.progress.set_text(t(key) if key in STRINGS else line)
        elif line.startswith("ERROR "):
            self.last_error = line[6:].strip()
        elif line == "DONE":
            self.last_done = True

    def on_end(self, rc):
        self.busy = False
        self.entry.set_sensitive(True)
        self.pw.set_sensitive(True)
        self.pw.set_text("")
        self.disk_box.set_sensitive(True)
        if rc == 0 and self.last_done:
            self.progress.set_text(t("install_done"))
        else:
            key = "err_" + self.last_error
            self.progress.set_text(t(key) if key in STRINGS else t("install_failed"))
        self.update_button()


class SystemPage(Gtk.Box):
    def __init__(self, notify):
        super().__init__(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        for side in ("top", "bottom", "start", "end"):
            getattr(self, "set_margin_" + side)(16)
        self.append(title_label(t("nav_system")))
        self.label = Gtk.Label(label=t("loading"), xalign=0, yalign=0)
        self.label.set_selectable(True)
        self.label.add_css_class("monospace")
        scroll = Gtk.ScrolledWindow()
        scroll.set_vexpand(True)
        scroll.set_child(self.label)
        self.append(scroll)

        def work():
            text = system_info()
            GLib.idle_add(self.label.set_text, text)
        threading.Thread(target=work, daemon=True).start()


class AppsPage(Gtk.Box):
    def __init__(self, notify):
        super().__init__(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        self.notify = notify
        for side in ("top", "bottom", "start", "end"):
            getattr(self, "set_margin_" + side)(16)
        self.append(title_label(t("nav_apps")))
        self.search = Gtk.SearchEntry()
        self.search.connect("search-changed", lambda _e: self.flow.invalidate_filter())
        self.append(self.search)
        self.flow = Gtk.FlowBox()
        self.flow.set_selection_mode(Gtk.SelectionMode.NONE)
        self.flow.set_max_children_per_line(6)
        self.flow.set_filter_func(self.visible)
        self.flow.connect("child-activated", self.on_activate)
        scroll = Gtk.ScrolledWindow()
        scroll.set_vexpand(True)
        scroll.set_child(self.flow)
        self.append(scroll)
        apps = [a for a in Gio.AppInfo.get_all() if a.should_show()]
        apps.sort(key=lambda a: a.get_display_name().lower())
        for a in apps:
            box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
            icon = a.get_icon()
            img = Gtk.Image.new_from_gicon(icon) if icon else Gtk.Image.new_from_icon_name("application-x-executable")
            img.set_pixel_size(48)
            box.append(img)
            lab = Gtk.Label(label=a.get_display_name())
            lab.set_max_width_chars(14)
            lab.set_ellipsize(Pango.EllipsizeMode.END)  # 끝을 ... 으로 줄임
            box.append(lab)
            box.set_margin_top(6)
            box.set_margin_bottom(6)
            child = Gtk.FlowBoxChild()
            child.set_child(box)
            child.app = a
            self.flow.append(child)

    def visible(self, child):
        q = self.search.get_text().strip().lower()
        return not q or q in child.app.get_display_name().lower()

    def on_activate(self, _flow, child):
        try:
            child.app.launch([], None)
            self.notify("")
        except Exception as e:  # noqa: BLE001
            self.notify(t("app_start_fail", err=e))


class MainWindow(Gtk.ApplicationWindow):
    def __init__(self, app, start_page):
        super().__init__(application=app, title=t("app_title"))
        self.set_default_size(920, 620)
        outer = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        body = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL)
        self.stack = Gtk.Stack()
        self.stack.set_hexpand(True)
        side = Gtk.StackSidebar()
        side.set_stack(self.stack)
        side.set_size_request(180, -1)
        self.status = Gtk.Label(label="", xalign=0)
        self.status.set_margin_start(12)
        self.status.set_margin_bottom(6)

        def notify(text):
            self.status.set_text(text or "")

        for name, cls in (("apps", AppsPage),
                          ("network", NetworkPage),
                          ("sound", SoundPage),
                          ("display", DisplayPage),
                          ("printer", PrinterPage),
                          ("install", InstallPage),
                          ("personal", PersonalPage),
                          ("system", SystemPage)):
            title = t("nav_" + name)
            try:
                page = cls(notify)
            except Exception as e:  # noqa: BLE001 - 한 쪽이 실패해도 나머지는 열린다
                page = Gtk.Label(label=t("page_fail", title=title, err=e))
            self.stack.add_titled(page, name, title)
        self.stack.set_visible_child_name(start_page)
        body.append(side)
        body.append(self.stack)
        if is_live():
            banner = Gtk.Label(label=t("live_banner"), xalign=0, wrap=True)
            banner.set_margin_start(12)
            banner.set_margin_top(6)
            outer.append(banner)
        outer.append(body)
        outer.append(self.status)
        self.set_child(outer)


class GateWindow(Gtk.Window):
    """로그인 화면. 설정 전이면 비밀번호를 정하고, 설정 후에는 비밀번호를 확인한다."""

    def __init__(self, app, setup, on_done, error=""):
        super().__init__(application=app, title=t("app_title"))
        self.setup = setup
        self.on_done = on_done
        self.fullscreen()
        self.set_decorated(False)
        # X 단추로 닫지 못하게 한다 (로그인해야만 나갈 수 있다)
        self.connect("close-request", lambda *_a: True)

        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=12)
        box.set_halign(Gtk.Align.CENTER)
        box.set_valign(Gtk.Align.CENTER)
        box.set_size_request(360, -1)
        if setup:
            box.append(title_label(t("gate_setup_title")))
            box.append(Gtk.Label(label=t("gate_setup_hint"), xalign=0, wrap=True))
            box.append(Gtk.Label(label=t("password_new"), xalign=0))
        else:
            box.append(title_label(t("app_title")))
            box.append(Gtk.Label(label=t("user_riceos"), xalign=0))
            box.append(Gtk.Label(label=t("password"), xalign=0))
        self.entry = Gtk.PasswordEntry()
        box.append(self.entry)
        self.entry2 = None
        if setup:
            box.append(Gtk.Label(label=t("password_confirm"), xalign=0))
            self.entry2 = Gtk.PasswordEntry()
            box.append(self.entry2)
        self.msg = Gtk.Label(label=error, xalign=0, wrap=True)
        box.append(self.msg)
        self.btn = Gtk.Button(label=t("setup_go") if setup else t("login_go"))
        self.btn.connect("clicked", lambda _b: self.submit())
        self.entry.connect("activate", lambda _e: self.submit())
        box.append(self.btn)
        if error:
            # 로그인 확인을 쓸 수 없으면 들어갈 수 없다 (잠금을 우회하지 않는다)
            self.entry.set_sensitive(False)
            self.btn.set_sensitive(False)
        self.set_child(box)
        self.entry.grab_focus()

    def submit(self):
        pw = self.entry.get_text()
        if self.setup:
            if not pw or "\n" in pw:
                self.msg.set_text(t("pw_empty"))
                return
            if pw != self.entry2.get_text():
                self.msg.set_text(t("pw_mismatch"))
                return
        self.btn.set_sensitive(False)
        self.msg.set_text(t("checking"))

        def work():
            if self.setup:
                ok, _ = auth_set(pw)
                msg = "" if ok else t("setup_fail")
            else:
                ok, _ = auth_check(pw)
                msg = "" if ok else t("login_wrong")
            GLib.idle_add(self.finish, ok, msg)
        threading.Thread(target=work, daemon=True).start()

    def finish(self, ok, msg):
        if ok:
            self.on_done()
            self.destroy()
            return False
        self.btn.set_sensitive(True)
        self.msg.set_text(msg)
        self.entry.set_text("")
        if self.entry2 is not None:
            self.entry2.set_text("")
        self.entry.grab_focus()
        return False


class QuickWindow(Gtk.Window):
    """빠른 설정 창: 무선과 소리 상태를 3초마다 새로 읽고, 자주 쓰는 동작을 한 번에 연다."""

    def __init__(self, app):
        super().__init__(application=app, title=t("quick_title"))
        self.set_default_size(340, -1)
        self.loading = False
        self.alive = True
        self.connect("destroy", lambda *_a: setattr(self, "alive", False))
        box = page_box()
        box.append(title_label(t("quick_title")))
        row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        row.append(Gtk.Label(label=t("wifi_on")))
        self.wifi = Gtk.Switch()
        self.wifi.connect("state-set", self.on_wifi)
        row.append(self.wifi)
        box.append(row)
        self.vol = Gtk.Label(label=t("vol_checking"), xalign=0)
        box.append(self.vol)
        self.mute = Gtk.ToggleButton(label=t("mute"))
        self.mute.connect("toggled", self.on_mute)
        box.append(self.mute)
        for key, page in (("quick_net", "network"), ("quick_sound", "sound"),
                          ("quick_apps", "apps")):
            b = Gtk.Button(label=t(key))
            b.connect("clicked", lambda _b, p=page: app.open_main(p))
            box.append(b)
        close = Gtk.Button(label=t("close"))
        close.connect("clicked", lambda _b: self.close())
        box.append(close)
        self.set_child(box)
        self.refresh()
        GLib.timeout_add_seconds(3, self.tick)

    def tick(self):
        if not self.alive:
            return False
        self.refresh()
        return True

    def refresh(self):
        run_bg(["nmcli", "radio", "wifi"], self.on_wifi_state)
        run_bg(["wpctl", "get-volume", "@DEFAULT_AUDIO_SINK@"], self.on_volume)

    def on_wifi_state(self, rc, out):
        self.loading = True
        self.wifi.set_active(rc == 0 and out.strip() == "enabled")
        self.loading = False

    def on_wifi(self, _sw, state):
        if self.loading:
            return False
        run_bg(["nmcli", "radio", "wifi", "on" if state else "off"],
               lambda rc, out: self.refresh())
        return False

    def on_volume(self, rc, out):
        v = parse_volume(out) if rc == 0 else None
        self.loading = True
        if v is None:
            self.vol.set_text(t("sound_unavailable"))
        else:
            self.vol.set_text(t("vol_line", v=v[0], muted=t("muted_tag") if v[1] else ""))
            self.mute.set_active(v[1])
        self.loading = False

    def on_mute(self, btn):
        if self.loading:
            return
        run_bg(["wpctl", "set-mute", "@DEFAULT_AUDIO_SINK@", "1" if btn.get_active() else "0"],
               lambda rc, out: self.refresh())


class RiceosApp(Gtk.Application):
    """mode: login(잠금 화면 후 앱 목록), quick(빠른 설정), menu(앱 목록), network(기본 설정 창)"""

    def __init__(self, mode):
        super().__init__(application_id="org.riceos.ui",
                         flags=Gio.ApplicationFlags.NON_UNIQUE)
        self.mode = mode
        self.main_win = None
        self.gate = None

    def do_activate(self):
        if self.mode == "quick":
            QuickWindow(self).present()
        elif self.mode == "login":
            state, err = auth_state()
            if state == "error":
                self.gate = GateWindow(self, False, self.unlocked,
                                       error="%s: %s" % (t("login_check_fail"), err))
            else:
                self.gate = GateWindow(self, state == "none", lambda: self.open_main("apps"))
            self.gate.present()
        else:
            self.open_main("apps" if self.mode == "menu" else self.mode)

    def unlocked(self):
        self.open_main("apps")

    def open_main(self, page):
        if self.main_win is None:
            self.main_win = MainWindow(self, page)
        else:
            self.main_win.stack.set_visible_child_name(page)
        self.main_win.present()


def main():
    set_lang(_pick_lang())
    args = sys.argv[1:]
    if "--quick" in args:
        mode = "quick"
    elif "--login" in args:
        mode = "login"
    elif "--menu" in args:
        mode = "menu"
    elif "--install" in args:
        mode = "install"
    elif "--display" in args:
        mode = "display"
    else:
        mode = "network"
    return RiceosApp(mode).run([sys.argv[0]])


if __name__ == "__main__":
    sys.exit(main())

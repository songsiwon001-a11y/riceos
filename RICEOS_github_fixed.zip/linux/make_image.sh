#!/bin/bash
# RICEOS 디스크 이미지 만들기 (Debian 12 bookworm 최소 설치 + RICEOS UI)
# 실행 환경: Debian/Ubuntu 리눅스 또는 Windows의 WSL2 (root 권한, 인터넷 필요)
# 결과: riceos.img  (GPT: EFI 512MB FAT32 + 나머지 ext4)
# 사용: sudo ./make_image.sh [크기, 기본 6G]
set -euo pipefail

SIZE="${1:-6G}"
IMG="$(pwd)/riceos.img"
MNT="$(mktemp -d /tmp/riceos-root.XXXXXX)"
HERE="$(cd "$(dirname "$0")" && pwd)"
MIRROR="http://deb.debian.org/debian"
# 커널 명령줄: 콘솔 글자(도스 같은 부팅 메시지)를 숨기고 Plymouth 부팅 화면을 쓴다
KCMD="ro quiet splash loglevel=3 udev.log_level=3 rd.udev.log_level=3 systemd.show_status=false vt.global_cursor_default=0"

[ "$(id -u)" = 0 ] || { echo "root 권한이 필요합니다: sudo $0"; exit 1; }
for t in debootstrap parted losetup mkfs.vfat mkfs.ext4 blkid chroot; do
  command -v "$t" >/dev/null || { echo "필요한 도구가 없습니다: $t"
    echo "설치: apt install debootstrap parted dosfstools e2fsprogs util-linux"; exit 1; }
done
[ -x "$HERE/riceos-ui" ] || { echo "먼저 linux/build.sh 로 riceos-ui 를 빌드하세요"; exit 1; }

LOOP1=""; LOOP2=""
cleanup() {
  set +e
  for m in dev/pts dev proc sys boot/efi; do umount "$MNT/$m" 2>/dev/null; done
  umount "$MNT" 2>/dev/null
  [ -n "$LOOP1" ] && losetup -d "$LOOP1" 2>/dev/null
  [ -n "$LOOP2" ] && losetup -d "$LOOP2" 2>/dev/null
  rmdir "$MNT" 2>/dev/null
}
trap cleanup EXIT

echo "[1/7] 빈 이미지와 파티션 만들기 ($SIZE)"
rm -f "$IMG"
truncate -s "$SIZE" "$IMG"
parted -s "$IMG" mklabel gpt \
  mkpart ESP fat32 1MiB 513MiB set 1 esp on \
  mkpart riceos-root ext4 513MiB 100%
TOTAL=$(stat -c %s "$IMG")
# 파티션 노드(loopNp1)가 없는 환경(WSL2 등)을 위해 오프셋으로 각각 연결
LOOP1=$(losetup --find --show -o $((1*1024*1024)) --sizelimit $((512*1024*1024)) "$IMG")
LOOP2=$(losetup --find --show -o $((513*1024*1024)) --sizelimit $((TOTAL - 513*1024*1024 - 1024*1024)) "$IMG")

echo "[2/7] 파일 시스템 만들기"
mkfs.vfat -F32 -n RICEOS-EFI "$LOOP1" >/dev/null
mkfs.ext4 -q -L riceos-root "$LOOP2"
mount "$LOOP2" "$MNT"
mkdir -p "$MNT/boot/efi"
mount "$LOOP1" "$MNT/boot/efi"

echo "[3/7] Debian 기본 시스템 설치 (몇 분 걸립니다)"
debootstrap --arch=amd64 --components=main,contrib,non-free,non-free-firmware \
  --include=linux-image-amd64,grub-efi-amd64,shim-signed,grub-efi-amd64-signed,systemd-sysv,udev,kmod,locales,tzdata,fonts-nanum,exfatprogs,ntfs-3g,dosfstools,e2fsprogs,parted,pciutils,usbutils,iproute2,iputils-ping,less,nano,procps,rfkill,wpasupplicant,iw,firmware-linux,firmware-linux-nonfree,firmware-misc-nonfree,firmware-realtek,firmware-iwlwifi,firmware-atheros,firmware-brcm80211,firmware-amd-graphics,firmware-sof-signed,intel-microcode,amd64-microcode,libgl1-mesa-dri,mesa-vulkan-drivers,vulkan-tools,vainfo,alsa-utils,plymouth,curl,ca-certificates,xserver-xorg-core,xserver-xorg-input-libinput,xinit,xauth,x11-xserver-utils,openbox,fonts-noto-cjk \
  bookworm "$MNT" "$MIRROR"

echo "[4/7] 기본 설정"
ROOT_UUID=$(blkid -s UUID -o value "$LOOP2")
EFI_UUID=$(blkid -s UUID -o value "$LOOP1")
cat > "$MNT/etc/fstab" <<FSTAB
UUID=$ROOT_UUID / ext4 defaults,noatime 0 1
UUID=$EFI_UUID /boot/efi vfat umask=0077 0 2
FSTAB
echo riceos > "$MNT/etc/hostname"
echo "Asia/Seoul" > "$MNT/etc/timezone"
ln -sf /usr/share/zoneinfo/Asia/Seoul "$MNT/etc/localtime"
echo "ko_KR.UTF-8 UTF-8" > "$MNT/etc/locale.gen"
echo "LANG=ko_KR.UTF-8" > "$MNT/etc/default/locale"
mkdir -p "$MNT/etc/systemd/network"
cat > "$MNT/etc/systemd/network/20-wired.network" <<NET
[Match]
Name=en*
[Network]
DHCP=yes
NET

# 무선 인터넷: 무선 장치는 DHCP로 주소를 받는다 (wpa_supplicant가 연결한 뒤 networkd가 처리)
cat > "$MNT/etc/systemd/network/30-wireless.network" <<NET
[Match]
Name=wl*
[Network]
DHCP=yes
NET

# apt 저장소: 펌웨어와 non-free 드라이버를 나중에 인터넷에서 받을 수 있도록 설정
cat > "$MNT/etc/apt/sources.list" <<APT
deb http://deb.debian.org/debian bookworm main contrib non-free non-free-firmware
deb http://deb.debian.org/debian bookworm-updates main contrib non-free non-free-firmware
deb http://security.debian.org/debian-security bookworm-security main contrib non-free non-free-firmware
APT

echo "[5/7] RICEOS UI 설치와 자동 실행 설정"
install -m 755 "$HERE/riceos-ui" "$MNT/usr/local/bin/riceos-ui"
# 명령 이름: 터미널에서 'wifi', 'driver' 등을 치면 같은 프로그램이 해당 기능을 실행한다
for n in wifi driver devices volumes hw net run riceos; do
  ln -sf riceos-ui "$MNT/usr/local/bin/$n"
done
# 부팅 시 소리 켜기: 많은 마더보드가 음소거 상태로 시작한다
cat > "$MNT/etc/systemd/system/riceos-sound.service" <<'UNIT'
[Unit]
Description=RICEOS 기본 소리 설정
After=alsa-restore.service sound.target
Wants=alsa-restore.service

[Service]
Type=oneshot
RemainAfterExit=yes
ExecStart=/bin/sh -c 'for c in Master PCM Headphone Speaker; do amixer -q sset "$c" unmute 70% >/dev/null 2>&1; done; exit 0'

[Install]
WantedBy=multi-user.target
UNIT

cat > "$MNT/etc/systemd/system/riceos-ui.service" <<UNIT
[Unit]
Description=RICEOS UI (전체 화면 바탕화면)
After=systemd-user-sessions.service systemd-udev-settle.service riceos-sound.service
Wants=riceos-sound.service
Conflicts=getty@tty1.service
After=getty@tty1.service

[Service]
Environment=TZ=Asia/Seoul
ExecStart=/usr/local/bin/riceos-ui
Restart=always
RestartSec=1
StandardInput=null
StandardOutput=journal
StandardError=journal

[Install]
WantedBy=multi-user.target
UNIT

# 데스크톱 세션: 일반 사용자(riceos)로 창 관리자와 바탕화면을 X 화면에서 띄운다 (앱은 자동으로 켜지지 않는다)
cat > "$MNT/usr/local/bin/riceos-chrome" <<'SH'
#!/bin/sh
# RICEOS 데스크톱(X)을 연다. 나가면 RICEOS 화면으로 돌아온다. 앱은 자동으로 켜지지 않는다.
if systemctl is-active --quiet riceos-x.service; then
  echo "데스크톱이 이미 실행 중입니다."
  exit 0
fi
systemd-run --unit=riceos-x --collect --description="RICEOS 데스크톱" \
  /bin/sh -c 'systemctl stop riceos-ui.service; xinit /usr/local/bin/riceos-chrome-session -- :1 vt8 -nolisten tcp >/var/log/riceos-x.log 2>&1; systemctl start riceos-ui.service'
SH
chmod 755 "$MNT/usr/local/bin/riceos-chrome"

cat > "$MNT/usr/local/bin/riceos-chrome-session" <<'SH'
#!/bin/sh
# X 세션 안에서 xinit이 실행한다. 창 관리자와 바탕화면 아이콘 관리를 riceos 사용자로 띄운다.
# 창 관리자(Openbox)를 끝내면 이 스크립트가 끝나고, xinit이 X 서버를 내린다.
xhost +SI:localuser:riceos >/dev/null 2>&1

# 모든 연결된 모니터를 켠다. 각 모니터는 자기 해상도에서 가장 높은 주사율로 돌고,
# 첫 번째 모니터를 기준(주 모니터)으로 나머지를 오른쪽에 가로로 배치한다.
riceos_layout() {
  prev=""
  xrandr -q | awk '
    / connected/ { out=$1; want=1; next }
    want && /^ +[0-9]+x[0-9]+/ { rate=$2; gsub(/[*+]/, "", rate); print out, $1, rate; want=0 }
  ' | while read out res rate; do
    if [ -z "$prev" ]; then pos="--pos 0x0 --primary"; else pos="--right-of $prev"; fi
    xrandr --output "$out" --mode "$res" --rate "$rate" $pos
    prev="$out"
  done
}
riceos_layout
/usr/local/bin/riceos-sync-desktop
exec runuser -u riceos -- env DISPLAY="$DISPLAY" HOME=/home/riceos openbox --startup 'pcmanfm --desktop'
SH
chmod 755 "$MNT/usr/local/bin/riceos-chrome-session"

# 부팅 화면 (Plymouth): 제조사 로고(ACPI BGRT) 위에 바 형태 로딩바. 테마 파일은 linux/plymouth/ 에 있다
mkdir -p "$MNT/usr/share/plymouth/themes/riceos" "$MNT/etc/plymouth"
install -m 644 "$HERE"/plymouth/riceos/* "$MNT/usr/share/plymouth/themes/riceos/"
install -m 644 "$HERE/plymouth/plymouthd.conf" "$MNT/etc/plymouth/plymouthd.conf"

# 배경화면 그림 폴더: linux/wallpapers/ 에 넣은 PNG/BMP 파일이 'riceos wallpaper next' 순환에 들어간다
mkdir -p "$MNT/usr/share/riceos/wallpapers"
if [ -d "$HERE/wallpapers" ]; then
  cp "$HERE"/wallpapers/*.png "$HERE"/wallpapers/*.bmp "$MNT/usr/share/riceos/wallpapers/" 2>/dev/null || true
fi

echo "[6/7] 부트로더(GRUB)와 서비스 활성화"
mount --bind /dev "$MNT/dev"
mount --bind /dev/pts "$MNT/dev/pts"
mount -t proc proc "$MNT/proc"
mount -t sysfs sys "$MNT/sys"

echo "bluez 설치 (서비스 자동 시작은 막음)"
cp /etc/resolv.conf "$MNT/etc/resolv.conf"
printf '#!/bin/sh\nexit 101\n' > "$MNT/usr/sbin/policy-rc.d"
chmod +x "$MNT/usr/sbin/policy-rc.d"
# 로그인 비밀번호 바꾸기 (아이디는 Admin). 처음 비밀번호는 부팅 때 화면에서 정한다
cat > "$MNT/usr/local/bin/riceos-setpw" <<'SH'
#!/bin/sh
# RICEOS 로그인 비밀번호 바꾸기 (아이디 Admin). 사용법: sudo riceos-setpw
[ "$(id -u)" = 0 ] || { echo "root 권한으로 실행하세요: sudo riceos-setpw"; exit 1; }
printf '새 비밀번호: '; stty -echo; read -r PW1; stty echo; echo
printf '비밀번호 확인: '; stty -echo; read -r PW2; stty echo; echo
[ -n "$PW1" ] || { echo "비어 있으면 안 됩니다"; exit 1; }
[ "$PW1" = "$PW2" ] || { echo "두 비밀번호가 서로 다릅니다"; exit 1; }
SALT=$(head -c 8 /dev/urandom | od -An -tx1 | tr -d ' \n')
HASH=$(printf '%s%s' "$SALT" "$PW1" | sha256sum | cut -d' ' -f1)
mkdir -p /etc/riceos
(umask 077; printf '%s:%s\n' "$SALT" "$HASH" > /etc/riceos/login)
echo "비밀번호를 바꿨습니다. 다음 로그인부터 새 비밀번호를 씁니다."
SH
chmod +x "$MNT/usr/local/bin/riceos-setpw"

chroot "$MNT" apt-get update -qq
chroot "$MNT" env DEBIAN_FRONTEND=noninteractive apt-get install -y -qq bluez systemd-resolved chromium mpv zathura gthumb gdebi pavucontrol lxappearance cups system-config-printer printer-driver-gutenprint sudo man-db manpages bash-completion htop unzip zip p7zip-full git wget file tree udisks2 gvfs gvfs-backends xdg-utils xdg-user-dirs fonts-noto-color-emoji
rm -f "$MNT/usr/sbin/policy-rc.d"

# grub-probe 가 루트 장치를 못 찾는 문제 방지: mtab 연결 + 루트 UUID 직접 지정
ln -sf /proc/self/mounts "$MNT/etc/mtab"
echo "GRUB_DEVICE_UUID=$ROOT_UUID" >> "$MNT/etc/default/grub"

# 우클릭 메뉴에 설정 도구 항목 추가 (Openbox 루트 메뉴)
MENU="$MNT/etc/xdg/openbox/menu.xml"
if grep -q 'id="root-menu"' "$MENU" 2>/dev/null; then
  for item in \
    '디스플레이 설정|arandr' \
    '소리 설정|pavucontrol' \
    '개인 설정 (테마)|lxappearance' \
    '프린터 설정|system-config-printer' \
    '파일 관리자|pcmanfm' \
    '문서 보기|zathura' \
    '이미지 보기|gthumb' \
    '동영상 재생|mpv'; do
    label="${item%%|*}"; cmd="${item##*|}"
    sed -i "/<menu id=\"root-menu\"/a\\    <item label=\"$label\"><action name=\"Execute\"><command>$cmd</command></action></item>" "$MENU"
  done
else
  echo "참고: 우클릭 메뉴(root-menu)를 찾지 못해 설정 항목을 건너뜁니다"
fi

# 설치한 앱의 바로가기를 바탕화면에 자동으로 만든다 (apt 설치/삭제 뒤, 그리고 세션 시작 때)
cat > "$MNT/usr/local/bin/riceos-sync-desktop" <<'SYNC'
#!/bin/sh
D=/home/riceos/Desktop
mkdir -p "$D"
for f in /usr/share/applications/*.desktop; do
  [ -f "$f" ] || continue
  grep -qi '^NoDisplay=true' "$f" && continue
  ln -sf "$f" "$D/$(basename "$f")"
done
for l in "$D"/*.desktop; do [ -L "$l" ] && [ ! -e "$l" ] && rm -f "$l"; done
chown -R riceos:riceos "$D" 2>/dev/null || true
exit 0
SYNC
chmod 755 "$MNT/usr/local/bin/riceos-sync-desktop"
mkdir -p "$MNT/etc/apt/apt.conf.d"
cat > "$MNT/etc/apt/apt.conf.d/99riceos-desktop" <<'HOOK'
DPkg::Post-Invoke { "/usr/local/bin/riceos-sync-desktop || true"; };
HOOK

chroot "$MNT" /bin/bash -e <<'CHROOT'
locale-gen
id riceos >/dev/null 2>&1 || useradd -m -s /bin/bash -G audio,video,input,sudo,lpadmin riceos
echo "riceos:riceos" | chpasswd
echo "root:riceos" | chpasswd
sed -i 's/^GRUB_TIMEOUT=.*/GRUB_TIMEOUT=0/' /etc/default/grub
sed -i 's/^GRUB_CMDLINE_LINUX_DEFAULT=.*/GRUB_CMDLINE_LINUX_DEFAULT="quiet splash loglevel=3 udev.log_level=3 rd.udev.log_level=3 systemd.show_status=false vt.global_cursor_default=0"/' /etc/default/grub
grep -q GRUB_TIMEOUT_STYLE /etc/default/grub || echo 'GRUB_TIMEOUT_STYLE=hidden' >> /etc/default/grub
# --removable: EFI/BOOT/BOOTX64.EFI 로 설치 (어느 PC에서든 USB로 부팅)
grub-install --target=x86_64-efi --efi-directory=/boot/efi --removable --no-nvram
systemctl enable riceos-ui.service systemd-networkd.service systemd-resolved.service riceos-sound.service
systemctl enable alsa-restore.service 2>/dev/null || true
systemctl mask getty@tty1.service
ln -sf /run/systemd/resolve/stub-resolv.conf /etc/resolv.conf
# 부팅 화면 테마를 기본으로 정하고 initramfs에 넣는다 (부팅 초기부터 로고와 바가 보이게)
plymouth-set-default-theme riceos
update-initramfs -u -k all
apt-get clean
CHROOT

# update-grub 대신 grub.cfg 직접 작성 (chroot 안 grub-probe 가 loop 장치를 찾지 못함)
mkdir -p "$MNT/boot/grub"
cat > "$MNT/boot/grub/grub.cfg" <<GRUBCFG
set timeout=0
set default=0
insmod part_gpt
insmod ext2
# 글 모드(DOS 같은 텍스트 화면) 대신 그래픽 화면을 쓴다: 검은 바탕
insmod all_video
insmod gfxterm
insmod png
set gfxmode=auto
set gfxpayload=keep
terminal_output gfxterm
set color_normal=white/black
set color_highlight=white/black
search --no-floppy --fs-uuid --set=root $ROOT_UUID
menuentry "RICEOS" {
    linux /vmlinuz root=UUID=$ROOT_UUID $KCMD
    initrd /initrd.img
}
GRUBCFG
test -e "$MNT/vmlinuz" && test -e "$MNT/initrd.img" || { echo "커널 또는 initrd 심볼릭 링크가 없습니다"; exit 1; }

echo "[7/7] 정리"
sync
echo
echo "완료: $IMG"
echo "USB에 쓰기: Rufus에서 이 .img 를 선택 (DD 이미지 모드) — USB 전체가 지워집니다."
echo "비상용 콘솔: 부팅 후 Ctrl+Alt+F2 → root / riceos"

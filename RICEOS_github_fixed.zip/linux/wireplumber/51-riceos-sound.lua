-- RICEOS: 모니터 스피커(HDMI, DisplayPort)보다 본체 소리 장치를 기본으로 쓴다.
-- WirePlumber 0.4 (Debian 12): priority.session 이 높을수록 기본 출력으로 고른다.
-- 기본값은 대략 1000 이고, 모니터 출력은 100 으로 낮춘다.
-- 모니터만 연결되어 있으면 그래도 모니터 소리가 난다 (다른 장치가 없을 때의 대비).
table.insert(alsa_monitor.rules,
  {
    matches = {
      {
        { "node.name", "matches", "alsa_output.*hdmi*" },
      },
      {
        { "node.name", "matches", "alsa_output.*displayport*" },
      },
    },
    apply_properties = {
      ["priority.session"] = 100,
      ["priority.driver"] = 100,
    },
  })
